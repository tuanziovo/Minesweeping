# 扫雷 Android App（GitHub Actions 自动构建）

本项目已将单文件 `index.html` 拆分为模块化前端代码，并针对 Android WebView / Capacitor 进行了兼容性与性能优化。

## 目录结构

- `www/index.html`：主页面入口
- `www/css/style.css`：样式表
- `www/js/core.js`：核心状态、计时器、设置、音效与缩放平移
- `www/js/renderer.js`：Canvas 棋盘渲染、高清缩放层与波纹动画
- `www/js/game.js`：触控/鼠标输入、撤销、回放录制与翻开/插旗逻辑
- `www/js/solver.js`：布雷、3BV 计算、无猜求解器与提示系统
- `www/js/ui.js`：结算弹窗、手势与键盘快捷键绑定
- `www/js/replay.js`：对局回放播放器
- `www/js/home.js`：主页、战役、每日挑战、成就、战绩、主题引擎与返回导航
- `capacitor.config.json`：Capacitor 应用配置（应用名：`扫雷`，包名：`com.minesweeper.game`）
- `.github/workflows/build-apk.yml`：GitHub Actions 自动打包 APK 工作流

## 上传到 GitHub 自动构建 APK

1. 在 GitHub 上新建一个仓库。
2. 将本压缩包解压后的**所有文件**（注意包含 `.github` 隐藏目录）推送到仓库的 `main` 或 `master` 分支。
3. 打开 GitHub 仓库顶部的 **Actions** 标签页，等待 **Build Android APK** 运行完成（也可以点击 **Run workflow** 手动触发）。
4. 构建完成后，点击该次运行记录，在页面底部的 **Artifacts** 区域下载 `minesweeper-debug-apk`，解压即可得到 `app-debug.apk`。
