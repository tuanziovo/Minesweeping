# 扫雷 Android App（GitHub Actions 自动构建）

本项目已将单文件 `index.html` 拆分为模块化前端代码，并针对 Android WebView / Capacitor 进行了兼容性与性能优化。

## 目录结构

- `www/index.html`：主页面入口
- `www/css/style.css`：样式表
- `www/js/core.js`：核心状态、计时器、设置、音效与缩放平移
- `www/js/renderer.js`：Canvas 棋盘渲染、高清缩放层与波纹动画
- `www/js/game.js`：触控/鼠标输入、撤销、回放录制与翻开/插旗逻辑
- `www/js/solver.js`：布雷、3BV 计算、无猜求解器与提示系统
- `www/js/ui.js`：结算弹窗、手势与键盘快捷键绑定
- `www/js/replay.js`：对局回放播放器
- `www/js/home.js`：主页、战役、每日挑战、成就（24 个）、战绩（总览/统计/历史）、主题引擎与返回导航
- `www/js/native.js`：原生桥接（Capacitor 震动、状态栏同步、启动屏、屏幕常亮、系统分享），浏览器里自动降级
- `www/js/extras.js`：旗帜模式按钮、震动强度与常亮设置、断点续玩、分享战绩、备份导出/导入
- `capacitor.config.json`：Capacitor 应用配置（应用名：`扫雷`，包名：`com.minesweeper.game`）
- `.github/workflows/build-apk.yml`：GitHub Actions 自动打包 APK 工作流

## v1.1 新增

- **断点续玩**：对局中被系统杀掉或切走后，重新打开会在主页出现「继续当前游戏」（仅经典 / 无猜的预设与自定义棋盘；战役与每日挑战不保存）。
- **旗帜模式**：顶栏新增旗帜按钮，开启后点按即插旗，再点一次切回翻开。
- **原生震动**：使用 Capacitor Haptics，可在设置 → 增强里调为 关 / 轻 / 标准 / 强。
- **状态栏跟随主题**、**启动屏**、**游戏时屏幕常亮**（可关闭）。
- **分享战绩**：通关弹窗里可通过系统分享面板发送成绩（无分享面板时复制到剪贴板）。
- **备份导出 / 导入**：设置 → 增强 → 数据，换机或重装前可导出设置、战绩与成就（不含回放）。
- **成就扩充**到 24 个，**战绩页**新增「总览」：胜率、连胜、总用时、近 30 局用时柱图、各难度平均用时。
- 修复首页难度分段按钮按下时出现双线的显示问题。
- 构建流程：自动从 `package.json` 写入 versionName / versionCode，并缓存 Gradle 依赖。

## 上传到 GitHub 自动构建 APK

1. 在 GitHub 上新建一个仓库。
2. 将本压缩包解压后的**所有文件**（注意包含 `.github` 隐藏目录）推送到仓库的 `main` 或 `master` 分支。
3. 打开 GitHub 仓库顶部的 **Actions** 标签页，等待 **Build Android APK** 运行完成（也可以点击 **Run workflow** 手动触发）。
4. 构建完成后，点击该次运行记录，在页面底部的 **Artifacts** 区域下载 `minesweeper-debug-apk`，解压即可得到 `app-debug.apk`。

## 固定签名（可覆盖安装）

- 构建一律使用项目里的 `signing/minesweeper.keystore` 签名，每次构建签名相同，新 APK 可直接覆盖安装旧版并保留数据。
- 构建日志的「Show APK signing certificate」一步会打印证书 SHA256，应始终是：`4B:9F:B5:47:6B:D3:AB:F5:B4:99:55:61:1C:FA:E3:08:6F:66:C4:01:47:8A:3D:95:8A:60:51:08:B1:F0:23:6A`
- **请勿删除或重新生成 `signing/` 目录**，否则签名又会变化。
- 首次切换到固定签名时，旧版（随机签名）需要先卸载一次再安装；卸载前可在 设置 → 增强 → 导出备份 保存战绩。
- 密钥库随仓库公开，适合自用。若仓库是公开的并想用私有密钥，在仓库 Settings → Secrets and variables → Actions 添加 `KEYSTORE_BASE64`（密钥库文件的 base64）、`KEYSTORE_PASSWORD`、`KEY_ALIAS` 三个 Secret，工作流会自动改用它们（store 与 key 密码需相同）。
