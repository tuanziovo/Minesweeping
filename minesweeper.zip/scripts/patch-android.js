#!/usr/bin/env node
// 由 Capacitor 的 sync 钩子自动执行：给 android/app/build.gradle 写入版本号与固定签名。
// 不依赖 GitHub 工作流文件，只要 package.json 与 signing/ 在项目里就会生效；可重复执行。
const fs = require("fs"), path = require("path");
const root = process.env.CAPACITOR_ROOT_DIR || process.cwd();
const gradle = path.join(root, "android/app/build.gradle");
if (!fs.existsSync(gradle)) process.exit(0); // 平台还没添加，跳过

const MARK = "// ==== minesweeper-patch ====";
const pkg = JSON.parse(fs.readFileSync(path.join(root, "package.json"), "utf8"));
const [a, b, c] = String(pkg.version).split(".").map((n) => parseInt(n, 10) || 0);
const code = a * 10000 + b * 100 + c, name = pkg.version;

// 签名：优先环境变量（GitHub Secrets），否则用项目自带密钥库
let ks = path.join(root, "signing/minesweeper.keystore"), pass = "minesweeper", alias = "minesweeper";
if (process.env.KS_B64 && process.env.KS_PASS && process.env.KS_ALIAS) {
  ks = path.join(require("os").tmpdir(), "release.keystore");
  fs.writeFileSync(ks, Buffer.from(process.env.KS_B64, "base64"));
  pass = process.env.KS_PASS; alias = process.env.KS_ALIAS;
  console.log("[patch-android] 使用 Secrets 中的密钥签名");
}
const esc = (s) => String(s).replace(/\\/g, "/").replace(/"/g, '\\"');
const hasKs = fs.existsSync(ks);
if (!hasKs) console.warn("[patch-android] 警告：找不到密钥库 " + ks + "，本次不设置固定签名");

let src = fs.readFileSync(gradle, "utf8");
const i = src.indexOf(MARK);
if (i >= 0) src = src.slice(0, i).replace(/\s+$/, "") + "\n";
src += `\n${MARK}\nandroid {\n    defaultConfig {\n        versionCode ${code}\n        versionName "${esc(name)}"\n    }\n` +
  (hasKs ? `    signingConfigs {\n        debug {\n            storeFile file("${esc(ks)}")\n            storePassword "${esc(pass)}"\n            keyAlias "${esc(alias)}"\n            keyPassword "${esc(pass)}"\n        }\n    }\n` : "") + "}\n";
fs.writeFileSync(gradle, src);
console.log(`[patch-android] versionName ${name} (code ${code})${hasKs ? "，固定签名已配置" : ""}`);

// 震动权限（幂等）
const mf = path.join(root, "android/app/src/main/AndroidManifest.xml");
if (fs.existsSync(mf)) {
  let m = fs.readFileSync(mf, "utf8");
  if (!m.includes("android.permission.VIBRATE")) fs.writeFileSync(mf, m.replace("</manifest>", '    <uses-permission android:name="android.permission.VIBRATE" />\n</manifest>'));
}
