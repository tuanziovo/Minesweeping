"use strict";
const DIFFS = { easy: { rows: 9, cols: 9, mines: 10 }, medium: { rows: 16, cols: 16, mines: 40 }, hard: { rows: 16, cols: 30, mines: 99 }, custom: { rows: 12, cols: 16, mines: 20 }, screen: { rows: 16, cols: 16, mines: 40 } };
const ENUMS = { difficulty: ["easy", "medium", "hard", "custom", "screen"], mode: ["traditional", "noguess"], actionMode: ["normal", "swap"] };
const ARROWS = { ArrowUp: [-1, 0], ArrowDown: [1, 0], ArrowLeft: [0, -1], ArrowRight: [0, 1] };
const SETTINGS_KEY = "minesweeper_settings", META_KEY = "minesweeper_meta", THEME_KEY = "minesweeper_theme";
const SOLVER_LIMITS = { maxVars: 22, maxSolutions: 6e4 };
const PERSIST_BITS = ["kb-focus", "hint-flash"];
const TRANSIENT_BITS = [...PERSIST_BITS, "anim-flag", "anim-unflag", "anim-reveal"];
const IS_MOBILE = /Android|iPhone|iPad|iPod/i.test(navigator.userAgent) || navigator.maxTouchPoints > 0;
const WORKER_COUNT = Math.min(IS_MOBILE ? 2 : 4, Math.max(1, (navigator.hardwareConcurrency || 4) - 1));
const MAX_PIXELS = IS_MOBILE ? 4e6 : 12e6, OV_MAX_PIXELS = IS_MOBILE ? 2.5e6 : 7e6;

const $ = (id) => document.getElementById(id);
const grid2D = (r, c, v) => Array.from({ length: r }, () => Array(c).fill(v));
const clamp = (v, lo, hi) => Math.min(hi, Math.max(lo, v));
const isObj = (v) => v && typeof v === "object" && !Array.isArray(v);
const pad2 = (v) => String(v).padStart(2, "0");
const fmtSec = (s) => (s < 60 ? String(s) : `${Math.floor(s / 60)}:${pad2(s % 60)}`);
const fmtMs = (ms) => { const s = ms / 1e3; return s >= 60 ? `${Math.floor(s / 60)}:${(s % 60).toFixed(1).padStart(4, "0")}` : `${s.toFixed(1)} 秒`; };
const clampInt = (v, def, lo, hi) => { const n = parseInt(v, 10); return clamp(Number.isFinite(n) ? n : def, lo, hi); };
const validOpt = (k, v) => !!ENUMS[k]?.includes(v);
const clampDelay = (v, def = 350) => { const n = Math.round(Number(v)); return Number.isFinite(n) ? clamp(n, 100, 1e3) : def; };
const clampNgSec = (v, def = 6) => { const n = Number(String(v ?? "").trim()); return clamp(Number.isFinite(n) && n > 0 ? n : def, 0.1, 30); };
const parseJson = (s) => { try { const o = JSON.parse(s || "{}"); return isObj(o) ? o : {}; } catch { return {}; } };
const store = {
  get(k) { try { return localStorage.getItem(k); } catch { return null; } },
  set(k, v) { try { localStorage.setItem(k, v); return true; } catch { return false; } },
  remove(k) { try { localStorage.removeItem(k); } catch {} },
};
const segHtml = (items, cur, attr) =>
  `<div class="seg">${items.map(([k, t]) => `<button class="btn${cur === k ? " active" : ""}" aria-pressed="${cur === k}" data-${attr}="${k}"><span>${t}</span></button>`).join("")}</div>`;

const dom = {
  board: $("board"), area: $("game-area"), wrapper: $("board-wrapper"),
  mines: $("mine-count"), timerSeconds: $("timer-s"), timerCentis: $("timer-cs"), flags: $("flag-count"),
  modal: $("modal"), settings: $("settings-overlay"), toast: $("status-toast"), warning: $("warning-bar"),
  density: $("density-hint"), maxMinesHint: $("mines-max-hint"),
  undoTop: $("btn-undo-topbar"), undoModal: $("btn-undo-modal"),
  modalIcon: $("modal-icon"), modalIconCircle: $("modal-icon-circle"), modalTitle: $("modal-title"),
  modalBadge: $("modal-badge"), modalStats: $("modal-stats"), modalMessage: $("modal-message"), modalQuickStats: $("modal-quick-stats"),
};

const G = {
  difficulty: "medium", mode: "traditional", actionMode: "normal",
  rows: 16, cols: 16, mines: 40,
  board: [], revealed: [], flagged: [], questioned: [],
  flagCount: 0, revealedCount: 0, nonMineCount: 0,
  firstClick: true, placing: false, gameOver: false, hintBusy: false,
  timer: null, time: 0, timeMs: 0, timerStart: 0, gameId: 0, boardVersion: 0,
  undo: [], hinted: [], settlement: null,
  cheated: false, undoUsed: false, noguessFallback: false, hintsUsed: 0, bv3: 0, usefulClicks: 0,
  soundEnabled: true, questionMarkEnabled: false, noguessTimeSeconds: 6, longPressDelay: 350,
  keyboardRow: -1, keyboardCol: -1, replay: null,
};

const R = {
  cells: null, dirty: new Set(), animating: new Set(),
  canvas: null, ctx: null, geo: null, palette: null,
  paintFrame: 0, fullRepaint: false, repaintProgress: null, hoverCell: null,
  scale: 1, minScale: 0.5, maxScale: 4, offset: { x: 0, y: 0 }, cellSize: 30,
  pan: null, panArm: null, pinch: null, moved: false, longPress: false, dragging: false,
  pressCancelled: false, ignoreMouse: false, wasPinching: false,
  touch: null, currentCell: null, mouseCell: null, chord: null, snap: null,
  audio: null, confirmReset: null, settingsPaused: false, hiddenPaused: false, homePaused: false,
  panFrame: 0, darkManual: false, wave: null, waveToken: 0, rngSeed: null,
  timers: { save: null, modal: null, resize: null, toast: null, longPress: null, ignoreMouse: null },
};

// Viewport height sync for mobile virtual keyboard / URL bar
let lastVvh = "";
const syncVvh = () => {
  const h = (window.visualViewport?.height || innerHeight) + "px";
  if (h === lastVvh) return;
  lastVvh = h;
  for (const el of [dom.modal, dom.settings, dom.toast]) el.style.setProperty("--vvh", h);
};
syncVvh();
window.visualViewport?.addEventListener("resize", syncVvh);
window.visualViewport?.addEventListener("scroll", syncVvh);
addEventListener("resize", syncVvh);

// Timer
const timerNodes = { s: document.createTextNode("0"), cs: document.createTextNode("") };
const timerLast = { s: "0", cs: "" };
dom.timerSeconds.replaceChildren(timerNodes.s);
dom.timerCentis.replaceChildren(timerNodes.cs);

function renderTimer() {
  const s = fmtSec(G.time), cs = G.firstClick ? "" : "." + pad2(Math.floor((G.timeMs % 1e3) / 10));
  if (s !== timerLast.s) timerNodes.s.nodeValue = timerLast.s = s;
  if (cs !== timerLast.cs) timerNodes.cs.nodeValue = timerLast.cs = cs;
}
function setElapsed(ms) {
  G.timeMs = Math.min(ms, 9999e3);
  G.time = Math.min(9999, Math.floor(G.timeMs / 1e3));
}
function startTimer() {
  if (G.timer) return;
  setElapsed(G.timeMs > 0 ? G.timeMs : 1e3 * G.time);
  G.timerStart = performance.now() - G.timeMs;
  let lastPaint = 0;
  const tick = () => {
    setElapsed(performance.now() - G.timerStart);
    if (G.time >= 9999) stopTimer();
    const now = performance.now();
    if (now - lastPaint >= 50) { lastPaint = now; renderTimer(); }
    if (G.timer) G.timer = requestAnimationFrame(tick);
  };
  G.timer = requestAnimationFrame(tick);
  renderTimer();
}
function stopTimer() {
  cancelAnimationFrame(G.timer);
  G.timer = null;
  timerNodes.cs.nodeValue = timerLast.cs = "";
}
function updateCounters() {
  dom.mines.textContent = Math.max(0, G.mines - G.flagCount);
  dom.flags.textContent = G.flagCount;
  renderTimer();
}

// Board helpers
const idxOf = (r, c) => r * G.cols + c;
const cellAt = (r, c) => R.cells[idxOf(r, c)];
const inBounds = (r, c) => r >= 0 && r < G.rows && c >= 0 && c < G.cols;
const isNumbered = (r, c) => G.revealed[r]?.[c] && G.board[r][c] > 0;
const flagFirst = () => (G.actionMode === "swap") !== !!R.flagMode;
const primaryAct = () => (flagFirst() ? toggleFlag : revealCell);
const secondaryAct = () => (flagFirst() ? revealCell : toggleFlag);
const clearTimer = (name) => { clearTimeout(R.timers[name]); R.timers[name] = null; };
const getNeighbors = (r, c) => {
  const out = [];
  nbrs(r, c, G.rows, G.cols, (nr, nc) => out.push({ row: nr, col: nc }));
  return out;
};
function showToast(msg, ms = 0) {
  clearTimer("toast");
  dom.toast.textContent = msg;
  dom.toast.classList.add("show");
  if (ms) R.timers.toast = setTimeout(() => dom.toast.classList.remove("show"), ms);
}
function hideToast() { clearTimer("toast"); dom.toast.classList.remove("show"); }
const isUiBlocked = () =>
  ["INPUT", "TEXTAREA", "SELECT"].includes(document.activeElement?.tagName) ||
  dom.settings.classList.contains("show") || dom.modal.classList.contains("show") || $("sub").classList.contains("show");

// Settings
function syncLongPressUI(val = G.longPressDelay) {
  const ms = clampDelay(val);
  G.longPressDelay = ms;
  const inp = $("longpress-delay"), lbl = $("longpress-delay-value");
  if (inp) {
    inp.value = ms;
    const min = Number(inp.min) || 100, max = Number(inp.max) || 1e3;
    inp.style.setProperty("--range-fill", `${clamp(((ms - min) / (max - min)) * 100, 0, 100)}%`);
  }
  if (lbl) lbl.textContent = `${ms} ms`;
}
function setInvalid(el, bad) {
  if (!el) return;
  el.classList.toggle("invalid", bad);
  el.setCustomValidity(bad ? "请输入大于 0 的数字" : "");
}
function syncNgTimeUI(val = G.noguessTimeSeconds) {
  const inp = $("noguess-time-seconds"), sec = clampNgSec(val, G.noguessTimeSeconds || 6);
  inp.value = sec;
  G.noguessTimeSeconds = sec;
  setInvalid(inp, false);
}
function onNgTimeInput(inp, normalize = false) {
  const n = Number(inp.value.trim()), ok = Number.isFinite(n) && n >= 0.1 && n <= 30;
  G.noguessTimeSeconds = ok ? n : 6;
  setInvalid(inp, !ok);
  if (normalize) inp.value = G.noguessTimeSeconds;
  scheduleSave();
}
function sanitizeBoardCfg(cfg, def = DIFFS.medium) {
  cfg = isObj(cfg) ? cfg : def;
  const rows = clampInt(cfg.rows, def.rows, 5, 100), cols = clampInt(cfg.cols, def.cols, 5, 100);
  return { rows, cols, mines: clampInt(cfg.mines, def.mines, 1, Math.max(1, rows * cols - 9)) };
}
function saveSettings() {
  const special = G.difficulty === "camp" || G.difficulty === "daily";
  store.set(SETTINGS_KEY, JSON.stringify({
    difficulty: special ? window.MineHome?.base || "medium" : G.difficulty,
    mode: special ? window.MineHome?.baseMode || "traditional" : G.mode,
    actionMode: G.actionMode,
    dark: R.darkManual ? document.body.classList.contains("dark") : undefined,
    soundEnabled: G.soundEnabled,
    questionMarkEnabled: G.questionMarkEnabled,
    customRows: DIFFS.custom.rows, customCols: DIFFS.custom.cols, customMines: DIFFS.custom.mines,
    noguessTimeSeconds: G.noguessTimeSeconds, longPressDelay: G.longPressDelay,
  })) || showToast("设置未能保存（浏览器禁用了存储）", 2500);
}
function scheduleSave() { clearTimer("save"); R.timers.save = setTimeout(saveSettings, 250); }
function syncCustomInputs(cfg) {
  $("c-rows").value = cfg.rows;
  $("c-cols").value = cfg.cols;
  $("c-mines").value = cfg.mines;
  updateDensityHint();
}
function applyCustomInputs({ selectDifficulty = false, shouldSave = true } = {}) {
  const cfg = sanitizeBoardCfg({ rows: $("c-rows").value, cols: $("c-cols").value, mines: $("c-mines").value });
  Object.assign(DIFFS.custom, cfg);
  syncCustomInputs(cfg);
  if (selectDifficulty) setSetting("difficulty", "custom", false);
  if (shouldSave) scheduleSave();
  return cfg;
}
function syncThemeMeta() {
  const meta = document.querySelector("meta[name=theme-color]"), probe = document.body.appendChild(document.createElement("i"));
  probe.style.background = "var(--bg)";
  if (meta) meta.content = getComputedStyle(probe).backgroundColor;
  probe.remove();
}
function setDark(on) {
  document.body.classList.toggle("dark", on);
  invalidatePalette();
  $("toggle-dark").checked = on;
  syncThemeMeta();
}
function loadSettings() {
  const s = parseJson(store.get(SETTINGS_KEY));
  R.darkManual = s.dark !== undefined;
  setDark(s.dark !== undefined ? !!s.dark : matchMedia("(prefers-color-scheme: dark)").matches);
  G.soundEnabled = s.soundEnabled !== false;
  $("toggle-sound").checked = G.soundEnabled;
  G.questionMarkEnabled = !!s.questionMarkEnabled;
  $("toggle-question").checked = G.questionMarkEnabled;
  syncLongPressUI(clampDelay(s.longPressDelay));
  syncNgTimeUI(clampNgSec(s.noguessTimeSeconds, 6));
  syncCustomInputs(Object.assign(DIFFS.custom, sanitizeBoardCfg({ rows: s.customRows, cols: s.customCols, mines: s.customMines }, DIFFS.custom)));
  ["difficulty", "mode", "actionMode"].forEach((k) => setSetting(k, validOpt(k, s[k]) ? s[k] : G[k], false));
}
function resetAllSettings() {
  store.remove(SETTINGS_KEY);
  store.remove(THEME_KEY);
  Object.assign(themeState, { preset: "default", custom: null, amoled: false, nums: "classic" });
  applyThemeCss();
  R.darkManual = false;
  Object.assign(DIFFS.custom, { rows: 12, cols: 16, mines: 20 });
  setDark(matchMedia("(prefers-color-scheme: dark)").matches);
  G.soundEnabled = true; $("toggle-sound").checked = true;
  G.questionMarkEnabled = false; $("toggle-question").checked = false;
  syncLongPressUI(350);
  syncNgTimeUI(6);
  syncCustomInputs(DIFFS.custom);
  setSetting("difficulty", "medium", false);
  setSetting("mode", "traditional", false);
  setSetting("actionMode", "normal", false);
  scheduleSave();
  closeSettings(true);
  showToast("已重置所有设置", 1800);
}
function setSetting(key, val, save = true) {
  if (!validOpt(key, val)) return;
  G[key] = val;
  document.querySelectorAll(`[data-set="${key}"]`).forEach((el) => el.classList.toggle("active", el.dataset.val === val));
  if (key === "difficulty") $("custom-fields").classList.toggle("show", val === "custom");
  if (key === "mode") {
    const ng = val === "noguess";
    $("noguess-time-row").hidden = !ng;
    if (ng) syncNgTimeUI(G.noguessTimeSeconds);
  }
  if (save) scheduleSave();
}
function openSettings() {
  R.snap = {
    difficulty: G.difficulty, mode: G.mode,
    customParams: G.difficulty === "custom" ? `${DIFFS.custom.rows},${DIFFS.custom.cols},${DIFFS.custom.mines}` : "",
  };
  dom.settings.classList.add("show");
  R.settingsPaused = !!G.timer && !G.gameOver;
  if (R.settingsPaused) stopTimer();
}
function closeSettings(force) {
  dom.settings.classList.remove("show");
  let customChanged = false;
  if (G.difficulty === "custom") {
    const cfg = applyCustomInputs({ shouldSave: false });
    customChanged = R.snap?.difficulty === "custom" && R.snap?.customParams !== `${cfg.rows},${cfg.cols},${cfg.mines}`;
  }
  const changed = !!R.snap && (R.snap.difficulty !== G.difficulty || R.snap.mode !== G.mode);
  if (!force && (changed || customChanged) && !G.firstClick && !G.gameOver && !G.placing) {
    const now = Date.now();
    if (!(R.closeConfirm && now - R.closeConfirm < 2500)) {
      R.closeConfirm = now;
      dom.settings.classList.add("show");
      return showToast("更改会重开当前局，再关闭一次确认", 2200);
    }
    R.closeConfirm = 0;
  }
  R.snap = null;
  scheduleSave();
  if (changed || customChanged) newGame();
  if (R.settingsPaused) {
    R.settingsPaused = false;
    if (!G.timer && !G.gameOver && !G.firstClick && !G.placing) startTimer();
  }
  window.MineHome?.sync?.();
}

// Audio & haptics
function ensureAudio() {
  const AC = window.AudioContext || window.webkitAudioContext;
  if (!AC) return null;
  if (!R.audio || R.audio.state === "closed") {
    R.audio = new AC(); R.audioOut = null; R.noiseBuffer = null; R.voices = 0;
  }
  if (R.audio.state === "suspended") R.audio.resume().catch(() => {});
  return R.audio;
}
function audioOut(ac) {
  if (!R.audioOut) {
    const comp = ac.createDynamicsCompressor();
    comp.threshold.value = -14; comp.knee.value = 12; comp.ratio.value = 6; comp.attack.value = 0.003; comp.release.value = 0.12;
    const gain = ac.createGain();
    gain.gain.value = 0.9; gain.connect(comp); comp.connect(ac.destination);
    R.audioOut = gain;
  }
  return R.audioOut;
}
function noiseBuf(ac) {
  if (!R.noiseBuffer) {
    const len = Math.ceil(1.5 * ac.sampleRate), buf = ac.createBuffer(1, len, ac.sampleRate), ch = buf.getChannelData(0);
    for (let i = 0; i < len; i++) ch[i] = 2 * Math.random() - 1;
    R.noiseBuffer = buf;
  }
  return R.noiseBuffer;
}
function playVoice(ac, src, outNode, dur, vol, delay, attack, offset = 0) {
  const t = ac.currentTime + delay, g = ac.createGain();
  outNode.connect(g); g.connect(audioOut(ac));
  g.gain.setValueAtTime(1e-4, t);
  g.gain.linearRampToValueAtTime(vol, t + attack);
  g.gain.exponentialRampToValueAtTime(0.001, t + dur);
  R.voices = (R.voices || 0) + 1;
  src.onended = () => { R.voices = Math.max(0, R.voices - 1); };
  offset ? src.start(t, offset) : src.start(t);
  src.stop(t + dur + 0.02);
}
function tone({ type = "sine", frequency = 440, endFrequency = frequency, duration = 0.08, volume = 0.2, delay = 0, attack = 0.004 }) {
  if (!G.soundEnabled) return;
  try {
    const ac = ensureAudio();
    if (!ac || (R.voices || 0) >= 40) return;
    const osc = ac.createOscillator(), t = ac.currentTime + delay;
    osc.type = type;
    osc.frequency.setValueAtTime(frequency, t);
    if (endFrequency !== frequency) osc.frequency.exponentialRampToValueAtTime(endFrequency, t + duration);
    playVoice(ac, osc, osc, duration, volume, delay, attack);
  } catch {}
}
function noise({ duration = 0.1, volume = 0.3, filter = "lowpass", cutoff = 400, endCutoff = cutoff, q = 0.7, delay = 0 }) {
  if (!G.soundEnabled) return;
  try {
    const ac = ensureAudio();
    if (!ac || (R.voices || 0) >= 40) return;
    const src = ac.createBufferSource(), flt = ac.createBiquadFilter(), t = ac.currentTime + delay;
    src.buffer = noiseBuf(ac);
    flt.type = filter; flt.Q.value = q;
    flt.frequency.setValueAtTime(cutoff, t);
    if (endCutoff !== cutoff) flt.frequency.exponentialRampToValueAtTime(endCutoff, t + duration);
    src.connect(flt);
    playVoice(ac, src, flt, duration, volume, delay, 0.004, 0.5 * Math.random());
  } catch {}
}

const NOTE_SINGLE = [392, 440, 494, 523, 587, 659, 698, 784, 880];
const NOTE_CHORD = [523, 587, 659, 784, 880, 1047, 1175];
const SFX = {
  reveal: ({ count = 1, value = 0 } = {}) => {
    noise({ duration: 0.03, volume: 0.1, filter: "highpass", cutoff: 2500 });
    if (count <= 1) {
      const f = NOTE_SINGLE[clamp(value, 0, 8)] * (1 + 0.02 * (Math.random() - 0.5));
      tone({ type: "triangle", frequency: f, endFrequency: 0.96 * f, duration: 0.11, volume: 0.17 });
      tone({ frequency: 2 * f, duration: 0.06, volume: 0.05 });
      return;
    }
    const n = Math.min(7, 3 + Math.floor(Math.log2(count))), span = Math.min(0.6, 0.16 + 0.004 * count);
    for (let i = 0; i < n; i++) {
      const p = i / (n - 1);
      tone({ type: "triangle", frequency: NOTE_CHORD[i % NOTE_CHORD.length] * (i >= NOTE_CHORD.length ? 2 : 1), duration: 0.13, volume: 0.1 + 0.05 * p, delay: p * span });
    }
    noise({ duration: span + 0.1, volume: 0.07, filter: "bandpass", cutoff: 600, endCutoff: 3200, q: 1.2 });
  },
  flag: () => {
    noise({ duration: 0.03, volume: 0.1, cutoff: 900 });
    tone({ frequency: 440, endFrequency: 660, duration: 0.07, volume: 0.15 });
    tone({ type: "triangle", frequency: 880, duration: 0.05, volume: 0.08, delay: 0.05 });
  },
  unflag: () => tone({ frequency: 660, endFrequency: 400, duration: 0.08, volume: 0.12 }),
  undo: () => {
    tone({ type: "triangle", frequency: 500, endFrequency: 250, duration: 0.14, volume: 0.13 });
    noise({ duration: 0.12, volume: 0.05, filter: "bandpass", cutoff: 1500, endCutoff: 500, q: 1 });
  },
  question: () => {
    tone({ frequency: 784, endFrequency: 988, duration: 0.07, volume: 0.11 });
    tone({ frequency: 988, duration: 0.05, volume: 0.07, delay: 0.06 });
  },
  deny: () => [0, 0.11].forEach((d) => tone({ type: "square", frequency: 180, endFrequency: 140, duration: 0.1, volume: 0.07, delay: d })),
  hint: () => [1047, 1319, 1568, 2093].forEach((f, i) => tone({ frequency: f, duration: 0.12, volume: 0.07, delay: 0.06 + 0.05 * i })),
  newgame: () => {
    noise({ duration: 0.22, volume: 0.08, filter: "bandpass", cutoff: 300, endCutoff: 1800, q: 0.9 });
    tone({ frequency: 330, endFrequency: 494, duration: 0.12, volume: 0.07 });
  },
  explode: () => {
    noise({ duration: 0.55, volume: 0.35, cutoff: 1400, endCutoff: 80, q: 0.8 });
    tone({ frequency: 110, endFrequency: 32, duration: 0.5, volume: 0.22 });
    for (let i = 0; i < 6; i++) noise({ duration: 0.05, volume: 0.1, filter: "highpass", cutoff: 1800, delay: 0.05 + 0.07 * i + 0.03 * Math.random() });
  },
  win: () => {
    [[523, 0], [659, 0.1], [784, 0.2], [1047, 0.32], [784, 0.5], [1047, 0.62], [1319, 0.74]].forEach(([f, d], i, a) => {
      const last = i === a.length - 1;
      tone({ type: "triangle", frequency: f, duration: last ? 0.7 : 0.16, volume: 0.15, delay: d });
      tone({ frequency: 2 * f, duration: last ? 0.6 : 0.12, volume: 0.05, delay: d });
    });
    for (let i = 0; i < 6; i++) tone({ frequency: 2093 + 1500 * Math.random(), duration: 0.08, volume: 0.03, delay: 0.8 + 0.07 * i });
  },
  tap: () => tone({ type: "triangle", frequency: 620, endFrequency: 520, duration: 0.04, volume: 0.08 }),
  select: () => tone({ frequency: 520, endFrequency: 700, duration: 0.06, volume: 0.09 }),
  unlock: () => {
    tone({ type: "triangle", frequency: 784, duration: 0.12, volume: 0.12 });
    tone({ type: "triangle", frequency: 1175, duration: 0.24, volume: 0.12, delay: 0.1 });
    tone({ frequency: 2350, duration: 0.14, volume: 0.03, delay: 0.1 });
  },
};
const HAPTIC = { reveal: 8, flag: 25, unflag: 15, undo: 15, deny: [20, 40, 20], hint: [10, 30, 10], explode: [50, 50, 100], win: [30, 50, 30, 50, 100], unlock: [20, 40, 30] };
function playFeedback(name, opts) {
  try { if (G.soundEnabled) { if (!window.Native?.haptic?.(name, opts)) navigator.vibrate?.(name === "reveal" && opts?.count > 1 ? [12, 25, 12] : HAPTIC[name] || 10); } } catch {}
  SFX[name]?.(opts);
}

// Pan & Zoom
function boardPad(extra = 0) {
  const gap = clamp(parseFloat(getComputedStyle(document.documentElement).getPropertyValue("--board-gap")) || 2, 0, 8);
  const a = getComputedStyle(dom.area), w = getComputedStyle(dom.wrapper);
  return {
    gap,
    px: parseFloat(a.paddingLeft) + parseFloat(a.paddingRight) + parseFloat(w.paddingLeft) + parseFloat(w.paddingRight) + extra,
    py: parseFloat(a.paddingTop) + parseFloat(a.paddingBottom) + parseFloat(w.paddingTop) + parseFloat(w.paddingBottom) + extra,
  };
}
function scrollCellIntoView(cell, pad = 40) {
  if (!cell) return;
  const area = dom.area.getBoundingClientRect(), rc = cell.getBoundingClientRect();
  let dx = 0, dy = 0;
  if (rc.left < area.left + pad) dx = area.left + pad - rc.left;
  else if (rc.right > area.right - pad) dx = area.right - pad - rc.right;
  if (rc.top < area.top + pad) dy = area.top + pad - rc.top;
  else if (rc.bottom > area.bottom - pad) dy = area.bottom - pad - rc.bottom;
  if (dx || dy) { R.offset.x += dx; R.offset.y += dy; applyTransform(); }
}
function getDims() {
  if (!R.dims || performance.now() - R.dims.t > 300) {
    const rect = dom.area.getBoundingClientRect();
    R.dims = {
      t: performance.now(), aw: dom.area.clientWidth, ah: dom.area.clientHeight,
      ww: dom.wrapper.offsetWidth, wh: dom.wrapper.offsetHeight,
      cx: rect.left + rect.width / 2, cy: rect.top + rect.height / 2,
    };
  }
  return R.dims;
}
function boardCenter() { const d = getDims(); return { x: d.cx + R.offset.x, y: d.cy + R.offset.y }; }
function applyTransform() {
  const d = getDims(), sw = d.ww * R.scale, sh = d.wh * R.scale;
  const mx = Math.max(0, (d.aw + sw) / 2 - Math.min(64, sw / 2, d.aw / 2));
  const my = Math.max(0, (d.ah + sh) / 2 - Math.min(64, sh / 2, d.ah / 2));
  R.offset = { x: clamp(R.offset.x, -mx, mx), y: clamp(R.offset.y, -my, my) };
  dom.wrapper.style.transform = `translate3d(${R.offset.x}px,${R.offset.y}px,0) scale(${R.scale})`;
  ovApply();
  ovSchedule();
}
let settleTimer = null;
function settleZoom() {
  clearTimeout(settleTimer);
  settleTimer = setTimeout(() => {
    dom.wrapper.style.willChange = "auto";
    const g = R.geo;
    if (g) {
      const want = Math.min((window.devicePixelRatio || 1) * Math.max(1, R.scale), Math.sqrt(MAX_PIXELS / (g.width * g.height)));
      if (Math.abs(want / g.k - 1) > 0.2) sizeMainCanvas();
    }
    requestAnimationFrame(() => requestAnimationFrame(() => { dom.wrapper.style.willChange = ""; }));
  }, 180);
}
function resetView() { R.scale = 1; R.offset = { x: 0, y: 0 }; applyTransform(); settleZoom(); }
function schedulePan() { R.panFrame || (R.panFrame = requestAnimationFrame(() => { R.panFrame = 0; applyTransform(); })); }
function resetPan() { R.panArm = null; R.pan = null; R.moved = false; }
function startPan(x, y) { R.pan = { x, y, startOffsetX: R.offset.x, startOffsetY: R.offset.y }; R.moved = false; }

function layoutBoard(keepView) {
  R.dims = null;
  const { gap, px, py } = boardPad();
  const aw = Math.max(240, dom.area.clientWidth - px), ah = Math.max(240, dom.area.clientHeight - py);
  const cs = Math.floor(Math.min((aw - (G.cols - 1) * gap) / G.cols, (ah - (G.rows - 1) * gap) / G.rows));
  const mob = innerWidth < 640;
  R.cellSize = clamp(Number.isFinite(cs) ? cs : 30, mob ? 21 : 28, mob ? 46 : 56);
  dom.board.style.gap = `${gap}px`;
  sizeMainCanvas();
  keepView ? (applyTransform(), settleZoom()) : resetView();
}
function computeScreenPreset() {
  const { gap, px, py } = boardPad(2), minCell = innerWidth < 640 ? 32 : 36;
  const fit = (space) => clamp(Math.floor((space + gap) / (minCell + gap)), 5, 100);
  const cols = fit(dom.area.clientWidth - px), rows = fit(dom.area.clientHeight - py);
  const cells = rows * cols, ratio = 0.12 + 0.086 * clamp((cells - 81) / 399, 0, 1);
  DIFFS.screen = { rows, cols, mines: clamp(Math.round(cells * ratio), 1, cells - 9) };
}

function newGame() {
  recordSettlementIfNeeded();
  if (R.audio) playFeedback("newgame");
  hideToast(); stopWave(); abortWorkers(); abortHint();
  G.hintBusy = false; dom.warning.hidden = true; clearTimer("modal");
  if (G.difficulty === "screen") computeScreenPreset();
  R.cells?.forEach((c) => c.remove("kb-focus"));
  const cfg = sanitizeBoardCfg(DIFFS[G.difficulty] || DIFFS.medium);
  Object.assign(G, {
    rows: cfg.rows, cols: cfg.cols, mines: cfg.mines,
    board: grid2D(cfg.rows, cfg.cols, 0), revealed: grid2D(cfg.rows, cfg.cols, false),
    flagged: grid2D(cfg.rows, cfg.cols, false), questioned: grid2D(cfg.rows, cfg.cols, false),
    flagCount: 0, revealedCount: 0, nonMineCount: 0,
    firstClick: true, placing: false, gameOver: false,
    time: 0, timeMs: 0, timerStart: 0, undo: [], hinted: [], settlement: null,
    cheated: false, undoUsed: false, noguessFallback: false, hintsUsed: 0, bv3: 0, usefulClicks: 0,
    keyboardRow: -1, keyboardCol: -1, replay: null, gameId: G.gameId + 1,
  });
  R.settingsPaused = false;
  stopTimer(); resetPan(); clearTouchState(); layoutBoard(); buildCells(); updateCounters(); syncUndoButtons();
}

