"use strict";
// Board generation, 3BV, and Solver (run inside Worker or simulated fallback)
function inB(r, c, rows, cols) { return r >= 0 && r < rows && c >= 0 && c < cols; }
function nbrs(r, c, rows, cols, fn) { for (let dr = -1; dr <= 1; dr++) for (let dc = -1; dc <= 1; dc++) if ((dr || dc) && inB(r + dr, c + dc, rows, cols)) fn(r + dr, c + dc); }
function mulberry32(seed) {
  return () => {
    seed = (1831565813 + (seed |= 0)) | 0;
    let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
function genBoard(rows, cols, mines, sr, sc, rng = Math.random, fullShuffle = false) {
  const total = rows * cols, b = Array.from({ length: rows }, () => Array(cols).fill(0)), safe = new Set([sr * cols + sc]);
  nbrs(sr, sc, rows, cols, (r, c) => safe.add(r * cols + c));
  const pool = new Int32Array(total).map((_, i) => i), need = Math.min(mines, total - safe.size), picked = [];
  if (fullShuffle) {
    for (let i = total - 1; i > 0; i--) { const j = Math.floor(rng() * (i + 1)); [pool[i], pool[j]] = [pool[j], pool[i]]; }
    for (let i = 0; i < total && picked.length < need; i++) if (!safe.has(pool[i])) picked.push(pool[i]);
  } else {
    const avail = pool.filter((k) => !safe.has(k));
    for (let i = 0; i < need; i++) { const j = i + Math.floor(rng() * (avail.length - i)); [avail[i], avail[j]] = [avail[j], avail[i]]; picked.push(avail[i]); }
  }
  for (const k of picked) {
    const r = Math.floor(k / cols), c = k % cols;
    b[r][c] = -1;
    nbrs(r, c, rows, cols, (nr, nc) => { if (b[nr][nc] !== -1) b[nr][nc]++; });
  }
  return b;
}
function bv3(board, rows, cols) {
  const vis = Array.from({ length: rows }, () => Array(cols).fill(false));
  let count = 0;
  for (let r = 0; r < rows; r++) for (let c = 0; c < cols; c++) {
    if (board[r][c] !== 0 || vis[r][c]) continue;
    count++; vis[r][c] = true;
    const q = [[r, c]];
    for (let i = 0; i < q.length; i++) nbrs(q[i][0], q[i][1], rows, cols, (nr, nc) => {
      if (!vis[nr][nc] && board[nr][nc] !== -1) { vis[nr][nc] = true; if (board[nr][nc] === 0) q.push([nr, nc]); }
    });
  }
  for (let r = 0; r < rows; r++) for (let c = 0; c < cols; c++) if (!vis[r][c] && board[r][c] !== -1) count++;
  return count;
}
function workerMain(self) {
  let deadline = Infinity;
  function backtrack(vars, cIds, cons, maxSol) {
    const idxMap = new Map(); vars.forEach((v, i) => idxMap.set(v, i));
    const eqs = cIds.map((id) => ({ need: cons[id].need, vars: cons[id].variables.map((v) => idxMap.get(v)).filter((x) => x !== undefined) }));
    const n = vars.length, vToEq = Array.from({ length: n }, () => []);
    eqs.forEach((eq, ei) => eq.vars.forEach((v) => vToEq[v].push(ei)));
    const order = Array.from({ length: n }, (_, i) => i).sort((a, b) => vToEq[b].length - vToEq[a].length);
    const val = new Int8Array(n), sum = eqs.map(() => 0), rem = eqs.map((e) => e.vars.length), mineCounts = new Int32Array(n);
    let solutions = 0, incomplete = false, steps = 0;
    (function dfs(depth) {
      if (incomplete) return;
      if (!(++steps & 4095) && Date.now() > deadline) { incomplete = true; return; }
      if (depth === order.length) { solutions++; for (let i = 0; i < n; i++) mineCounts[i] += val[i]; if (solutions >= maxSol) incomplete = true; return; }
      const v = order[depth];
      for (let b = 0; b < 2; b++) {
        val[v] = b; let ok = true;
        for (const ei of vToEq[v]) { rem[ei]--; sum[ei] += b; if (sum[ei] > eqs[ei].need || sum[ei] + rem[ei] < eqs[ei].need) ok = false; }
        if (ok) dfs(depth + 1);
        for (const ei of vToEq[v]) { rem[ei]++; sum[ei] -= b; }
        if (incomplete) return;
      }
    })(0);
    return { invalid: solutions === 0 && !incomplete, incomplete, solutions, mineCounts };
  }
  function buildCons(board, rev, flg, rows, cols) {
    const k2i = new Map(), keys = [], constraints = [];
    const reg = (k) => { if (!k2i.has(k)) { k2i.set(k, keys.length); keys.push(k); } return k2i.get(k); };
    for (let r = 0; r < rows; r++) {
      if (!(r & 7) && Date.now() > deadline) return null;
      for (let c = 0; c < cols; c++) {
        if (!rev[r][c] || board[r][c] <= 0) continue;
        let f = 0; const unk = [];
        nbrs(r, c, rows, cols, (nr, nc) => { flg[nr][nc] ? f++ : !rev[nr][nc] && unk.push(nr * cols + nc); });
        const need = board[r][c] - f;
        if (need < 0 || need > unk.length) return null;
        if (unk.length) constraints.push({ need, variables: unk.map(reg) });
      }
    }
    return { keys, constraints };
  }
  function components(nVars, cons, fixed) {
    const v2c = Array.from({ length: nVars }, () => []);
    cons.forEach((c, ci) => c.variables.forEach((v) => v2c[v].push(ci)));
    const visV = new Uint8Array(nVars), visC = new Uint8Array(cons.length), out = [];
    for (let i = 0; i < nVars; i++) {
      if (visV[i] || fixed[i]) continue;
      const vars = [], cIds = [], qV = [i], qC = [];
      for (visV[i] = 1; qV.length || qC.length;) {
        while (qV.length) { const v = qV.pop(); vars.push(v); for (const ci of v2c[v]) if (!visC[ci]) { visC[ci] = 1; qC.push(ci); } }
        while (qC.length) { const ci = qC.pop(); cIds.push(ci); for (const v of cons[ci].variables) if (!visV[v] && !fixed[v]) { visV[v] = 1; qV.push(v); } }
      }
      out.push({ variables: vars, constraintIds: cIds });
    }
    return out;
  }
  function reduceSubsets(nVars, cons, fixed, safeSet, mineSet) {
    let nextId = 0;
    const eqs = cons.map((c) => ({ id: nextId++, need: c.need, variables: new Set(c.variables) }));
    const sig = (e) => e.need + "|" + [...e.variables].sort((a, b) => a - b).join(",");
    const seen = new Set(eqs.map(sig)), v2e = Array.from({ length: nVars }, () => new Set());
    eqs.forEach((e) => e.variables.forEach((v) => v2e[v].add(e)));
    const q = [], markS = (v) => { if (!fixed[v]) { fixed[v] = 1; safeSet.add(v); q.push(v); } };
    const markM = (v) => { if (!fixed[v]) { fixed[v] = 2; mineSet.add(v); q.push(v); } };
    const checkEq = (e) => {
      if (!e.variables.size) return;
      if (e.need === 0) { for (const v of e.variables) markS(v); e.variables.clear(); }
      else if (e.need === e.variables.size) { for (const v of e.variables) markM(v); e.variables.clear(); }
    };
    const drain = () => {
      while (q.length) {
        const v = q.pop(), isM = fixed[v] === 2;
        for (const e of [...v2e[v]]) if (e.variables.has(v)) { e.variables.delete(v); if (isM) e.need--; checkEq(e); }
        v2e[v].clear();
      }
    };
    eqs.forEach(checkEq); drain();
    for (let pass = 0; pass < 6; pass++) {
      let changed = false; const byVar = new Map(), pairs = new Set();
      for (const e of eqs) if (e.variables.size) for (const v of e.variables) { if (!byVar.has(v)) byVar.set(v, []); byVar.get(v).push(e); }
      for (const list of byVar.values()) for (let a = 0; a < list.length; a++) for (let b = 0; b < list.length; b++) {
        if (a === b) continue;
        const ea = list[a], eb = list[b];
        if (ea.variables.size >= eb.variables.size) continue;
        const pid = ea.id + ":" + eb.id;
        if (pairs.has(pid)) continue; pairs.add(pid);
        let sub = true; for (const v of ea.variables) if (!eb.variables.has(v)) { sub = false; break; }
        if (!sub) continue;
        const diff = []; for (const v of eb.variables) if (!ea.variables.has(v)) diff.push(v);
        const need = eb.need - ea.need;
        if (need < 0 || need > diff.length) continue;
        if (need === 0) { for (const v of diff) markS(v); changed = true; }
        else if (need === diff.length) { for (const v of diff) markM(v); changed = true; }
        else {
          const ne = { id: nextId++, need, variables: new Set(diff) }, sg = sig(ne);
          if (!seen.has(sg)) { seen.add(sg); eqs.push(ne); ne.variables.forEach((v) => v2e[v].add(ne)); changed = true; }
        }
      }
      drain();
      if (!changed) break;
    }
    return eqs.filter((e) => e.variables.size > 0).map((e) => ({ need: e.need, variables: [...e.variables] }));
  }
  const toRC = (k, cols) => [Math.floor(k / cols), k % cols];
  function analyze(board, rev, flg, rows, cols, maxVars, maxSol, withProbs, reduce) {
    const built = buildCons(board, rev, flg, rows, cols);
    if (!built) return { safe: [], mines: [], invalid: true, probs: [], frontierKeys: [] };
    const { keys } = built;
    if (!keys.length) return { safe: [], mines: [], invalid: false, probs: [], frontierKeys: [] };
    const fixed = new Uint8Array(keys.length), safe = new Set(), mines = new Set(), probs = new Map();
    const cons = withProbs || reduce ? reduceSubsets(keys.length, built.constraints, fixed, safe, mines) : built.constraints;
    const skipped = [];
    let timedOut = false;
    for (const comp of components(keys.length, cons, fixed)) {
      if (withProbs && !timedOut && Date.now() > deadline) timedOut = true;
      if (timedOut || comp.variables.length > maxVars) { if (withProbs) skipped.push(...comp.variables); continue; }
      const res = backtrack(comp.variables, comp.constraintIds, cons, maxSol);
      if (res.invalid) return { safe: [], mines: [], invalid: true, probs: [], frontierKeys: [] };
      if (res.incomplete && withProbs) skipped.push(...comp.variables);
      if (!res.incomplete) for (let i = 0; i < comp.variables.length; i++) {
        const vi = comp.variables[i];
        if (res.mineCounts[i] === 0) safe.add(vi);
        else if (res.mineCounts[i] === res.solutions) mines.add(vi);
        else if (withProbs) probs.set(keys[vi], res.mineCounts[i] / res.solutions);
      }
    }
    return {
      safe: [...safe].filter((i) => !mines.has(i)).map((i) => toRC(keys[i], cols)),
      mines: [...mines].map((i) => toRC(keys[i], cols)),
      invalid: false, probs: withProbs ? [...probs.entries()] : [], frontierKeys: keys, unsolved: skipped.map((v) => keys[v]),
    };
  }
  function isSolvable(board, rows, cols, mines, sr, sc, maxVars, maxSol) {
    const total = rows * cols, rev = Array.from({ length: rows }, () => Array(cols).fill(false)), flg = Array.from({ length: rows }, () => Array(cols).fill(false));
    let revCnt = 0, flgCnt = 0;
    const frontier = new Set();
    const addFront = (r, c) => nbrs(r, c, rows, cols, (nr, nc) => { if (rev[nr][nc] && board[nr][nc] > 0) frontier.add(nr * cols + nc); });
    const unkNbs = (r, c) => { const u = []; nbrs(r, c, rows, cols, (nr, nc) => { if (!rev[nr][nc] && !flg[nr][nc]) u.push([nr, nc]); }); return u; };
    const flgNbs = (r, c) => { let n = 0; nbrs(r, c, rows, cols, (nr, nc) => { if (flg[nr][nc]) n++; }); return n; };
    const openFlood = (r, c, opened) => {
      if (!inB(r, c, rows, cols) || rev[r][c] || flg[r][c]) return true;
      if (board[r][c] === -1) return false;
      rev[r][c] = true; revCnt++; if (opened) opened.push(r * cols + c);
      const q = [[r, c]];
      for (let i = 0; i < q.length; i++) {
        if (!(i & 255) && Date.now() > deadline) return false;
        const [cr, cc] = q[i];
        if (board[cr][cc] > 0) frontier.add(cr * cols + cc);
        addFront(cr, cc);
        if (board[cr][cc] === 0) {
          let bad = false;
          nbrs(cr, cc, rows, cols, (nr, nc) => {
            if (!bad && !rev[nr][nc] && !flg[nr][nc]) {
              if (board[nr][nc] === -1) bad = true;
              else { rev[nr][nc] = true; revCnt++; if (opened) opened.push(nr * cols + nc); q.push([nr, nc]); }
            }
          });
          if (bad) return false;
        }
      }
      return true;
    };
    if (!openFlood(sr, sc)) return false;
    const unflagged = new Set();
    for (let r = 0; r < rows; r++) { if (!(r & 7) && Date.now() > deadline) return false; for (let c = 0; c < cols; c++) if (!rev[r][c] && !flg[r][c]) unflagged.add(r * cols + c); }
    const doOpen = (r, c) => { const o = []; if (!openFlood(r, c, o)) return false; for (const k of o) unflagged.delete(k); return true; };
    const doFlag = (r, c) => { if (!inB(r, c, rows, cols) || rev[r][c] || flg[r][c]) return false; flg[r][c] = true; flgCnt++; addFront(r, c); unflagged.delete(r * cols + c); return true; };
    for (let iter = 0; iter < 4 * total; iter++) {
      if (!(iter & 7) && Date.now() > deadline) return false;
      if (revCnt >= total - mines) return true;
      let prog = false;
      const remM = mines - flgCnt, remU = unflagged.size;
      if (remM < 0 || remU < remM) return false;
      if (remM === 0) { for (const k of unflagged) { if (!doOpen(Math.floor(k / cols), k % cols)) return false; prog = true; } if (prog) continue; }
      if (remU && remM === remU) { for (const k of unflagged) prog = doFlag(Math.floor(k / cols), k % cols) || prog; if (prog) continue; }
      const snap = [...frontier]; frontier.clear();
      for (const k of snap) {
        const r = Math.floor(k / cols), c = k % cols;
        if (!rev[r][c] || board[r][c] <= 0) continue;
        const unk = unkNbs(r, c), need = board[r][c] - flgNbs(r, c);
        if (need < 0 || need > unk.length) return false;
        if (unk.length) {
          if (need === 0) { for (const [nr, nc] of unk) { if (!doOpen(nr, nc)) return false; prog = true; } }
          else if (need === unk.length) { for (const [nr, nc] of unk) prog = doFlag(nr, nc) || prog; }
        }
      }
      if (prog) continue;
      const res = analyze(board, rev, flg, rows, cols, maxVars, maxSol, false, true);
      if (res.invalid) return false;
      for (const [r, c] of res.mines) prog = doFlag(r, c) || prog;
      for (const [r, c] of res.safe) { if (!doOpen(r, c)) return false; prog = true; }
      if (!prog) return false;
    }
    return revCnt >= total - mines;
  }
  self.onmessage = (ev) => {
    const d = ev.data, now = Date.now();
    deadline = d.mode === "hint" ? now + 2500 : Number.isFinite(d.deadline) ? d.deadline : now + 5e3;
    if (d.mode === "hint") return self.postMessage({ id: d.id, result: analyze(d.board, d.revealed, d.flagged, d.rows, d.cols, d.maxVars, d.maxSolutions, true) });
    if (d.mode === "generate") {
      const step = () => {
        while (Date.now() < deadline) {
          if (self.dead) return;
          const b = genBoard(d.rows, d.cols, d.mines, d.startRow, d.startCol);
          if (isSolvable(b, d.rows, d.cols, d.mines, d.startRow, d.startCol, d.maxVars, d.maxSolutions)) {
            if (Date.now() < deadline) return self.postMessage({ id: d.id, result: { board: b, bv3: bv3(b, d.rows, d.cols) } });
            break;
          }
          if (self.coop) return void setTimeout(step, 0);
        }
        self.postMessage({ id: d.id, result: false });
      };
      return void step();
    }
    self.postMessage({ id: d.id, result: isSolvable(d.board, d.rows, d.cols, d.mines, d.startRow, d.startCol, d.maxVars, d.maxSolutions) });
  };
}

let workerBlobUrl = null;
function createSolverWorker() {
  if (window.Worker && window.Blob && window.URL && workerBlobUrl !== false) {
    try {
      if (!workerBlobUrl) workerBlobUrl = URL.createObjectURL(new Blob([
        `${[inB, nbrs, genBoard, bv3, workerMain].map(String).join("\n")}\n${workerMain.name}(self);`,
      ], { type: "text/javascript" }));
      return new Worker(workerBlobUrl);
    } catch { workerBlobUrl = false; }
  }
  const sim = {
    dead: false, onmessage: null, onerror: null,
    postMessage(d) { setTimeout(() => { if (!sim.dead) try { host.onmessage({ data: d }); } catch (e) { sim.onerror?.(e); } }, 0); },
    terminate() { sim.dead = true; },
  };
  const host = {
    coop: true, onmessage: null, get dead() { return sim.dead; },
    postMessage(r) { if (!sim.dead) setTimeout(() => sim.onmessage?.({ data: r }), 0); },
  };
  workerMain(host);
  return sim;
}

// Hint system
let hintWorker = null, hintSeq = 0, hintAbort = null;
function abortHint() { hintWorker?.terminate(); hintWorker = null; hintAbort?.(new Error("aborted")); }
function runHintSolver() {
  hintWorker || (hintWorker = createSolverWorker());
  const w = hintWorker, id = ++hintSeq;
  return new Promise((res, rej) => {
    const tm = setTimeout(abortHint, 5e3);
    const wrap = (fn) => (v) => { clearTimeout(tm); hintAbort = null; fn(v); };
    hintAbort = wrap(rej);
    w.onmessage = (e) => { if (e.data.id === id) wrap(res)(e.data.result); };
    w.onerror = wrap(rej);
    w.postMessage({ mode: "hint", id, board: G.board, revealed: G.revealed, flagged: G.flagged, rows: G.rows, cols: G.cols, ...SOLVER_LIMITS, maxVars: 40 });
  });
}
function pickLowestProb(probs, frontier, unsolved) {
  let unrev = 0;
  for (let r = 0; r < G.rows; r++) for (let c = 0; c < G.cols; c++) if (!G.revealed[r][c] && !G.flagged[r][c]) unrev++;
  if (!unrev) return null;
  const remM = clamp(G.mines - G.flagCount, 0, unrev);
  let best = null;
  probs.forEach((p, k) => { if (!best || p < best.prob) best = { row: Math.floor(k / G.cols), col: k % G.cols, prob: p }; });
  const fSet = frontier instanceof Set ? frontier : new Set(frontier || []), outside = unrev - fSet.size;
  if (outside > 0) {
    let sum = 0; probs.forEach((p) => { sum += p; });
    const op = clamp((remM - sum) / (outside + (unsolved?.length || 0)), 0, 1);
    if (!best || op < best.prob - 1e-9) {
      for (let r = 0; r < G.rows; r++) for (let c = 0; c < G.cols; c++)
        if (!G.revealed[r][c] && !G.flagged[r][c] && !fSet.has(r * G.cols + c)) return { row: r, col: c, prob: op };
    }
  }
  return best;
}
const flashHint = (r, c) => { cellAt(r, c)?.add("hint-flash"); playFeedback("hint"); };
async function requestHint() {
  if (G.firstClick) return showToast("先翻开一格再用提示", 1800);
  if (G.placing) return showToast("棋盘生成中", 1500);
  if (G.gameOver) return showToast("本局已结束", 1500);
  if (G.hintBusy) return;
  if (G.flagged.some((row, r) => row.some((f, c) => f && G.board[r][c] !== -1))) {
    G.cheated = true; G.hintsUsed++;
    return showToast("有旗子插错了，提示不可靠，已计为使用提示", 2400);
  }
  G.hintBusy = true;
  const gid = G.gameId, ver = G.boardVersion, btn = $("btn-hint");
  if (btn) btn.disabled = true;
  const done = () => { if (G.gameId === gid) G.hintBusy = false; if (btn && !G.hintBusy) btn.disabled = false; };
  let res;
  try { res = await runHintSolver(); }
  catch {
    done();
    if (G.gameId === gid) showToast("提示计算失败，请重试", 1800);
    return;
  }
  done();
  if (G.gameId !== gid || G.boardVersion !== ver || G.gameOver) return;
  if (res.invalid) return showToast("标记自相矛盾", 2400);
  if (res.safe.length) {
    const [r, c] = res.safe[Math.floor(Math.random() * res.safe.length)];
    G.cheated = true; G.hintsUsed++; pushUndo(); G.usefulClicks++;
    openCells([[r, c]], r, c); if (!G.gameOver) checkWin();
    flashHint(r, c);
    return showToast("已翻开一个安全格", 2200);
  }
  if (res.mines.length) {
    const [r, c] = res.mines[Math.floor(Math.random() * res.mines.length)];
    G.cheated = true; G.hintsUsed++; pushUndo();
    G.flagged[r][c] = true; G.flagCount++; G.questioned[r][c] = false;
    playFeedback("flag"); syncCell(r, c, "anim-flag"); updateCounters();
    captureReplayStep("提示标记", false, r, c); flashHint(r, c);
    return showToast("没有安全格，已标出一颗确定的雷", 2400);
  }
  const guess = pickLowestProb(new Map(res.probs), res.frontierKeys, res.unsolved);
  if (!guess) return showToast("当前推不出确定的格子", 1800);
  G.cheated = true; G.hintsUsed++; flashHint(guess.row, guess.col);
  showToast(`没有确定的格子，已高亮雷概率最低的格子（约 ${Math.round(100 * guess.prob)}%）`, 2800);
}

// Worker pool for no-guess generation
let pool = null, poolSeq = 0;
const poolCbs = new Array(WORKER_COUNT).fill(null), poolIds = new Array(WORKER_COUNT).fill(0);
function spawnPoolWorker(i) {
  const w = createSolverWorker();
  w.onmessage = (e) => { if (e.data.id === poolIds[i]) { const cb = poolCbs[i]; poolCbs[i] = null; poolIds[i] = 0; cb?.(e.data.result); } };
  w.onerror = () => { const cb = poolCbs[i]; poolCbs[i] = null; poolIds[i] = 0; if (pool?.[i] === w) { w.terminate(); pool[i] = null; } cb?.(false); };
  return w;
}
function abortWorkers() {
  for (let i = 0; i < poolCbs.length; i++) {
    const cb = poolCbs[i]; poolCbs[i] = null; poolIds[i] = 0;
    if (cb && pool?.[i]) { pool[i].terminate(); pool[i] = null; }
    cb?.(null);
  }
}
function raceGenerate(rows, cols, mines, sr, sc, deadline) {
  abortWorkers();
  pool || (pool = new Array(WORKER_COUNT).fill(null));
  for (let i = 0; i < WORKER_COUNT; i++) pool[i] || (pool[i] = spawnPoolWorker(i));
  return new Promise((resolve) => {
    let rem = pool.length, done = false;
    const finish = (v) => { if (!done) { done = true; resolve(v); } };
    pool.forEach((w, i) => {
      const id = ++poolSeq;
      poolIds[i] = id;
      poolCbs[i] = (res) => { if (!done) (res && Array.isArray(res.board) ? finish(res) : res === null ? finish(null) : --rem === 0 && finish(false)); };
      try { w.postMessage({ mode: "generate", id, rows, cols, mines, startRow: sr, startCol: sc, deadline, ...SOLVER_LIMITS }); }
      catch { const cb = poolCbs[i]; poolCbs[i] = null; poolIds[i] = 0; cb?.(false); }
    });
  });
}
async function generateFirstClickBoard(sr, sc, gid) {
  if (G.mode !== "noguess") return placeTraditionalBoard(sr, sc);
  const minSec = window.MineHome?.run?.key === "camp" ? 20 : 0;
  const ms = Math.round(1e3 * Math.max(clampNgSec(G.noguessTimeSeconds), minSec)), t0 = Date.now();
  const left = () => Math.max(0, ms - (Date.now() - t0));
  const tickToast = () => { if (G.gameId === gid) showToast(`生成无猜棋盘，剩余 ${Math.ceil(left() / 1e3)} 秒`, 0); };
  tickToast();
  const iv = setInterval(tickToast, 500);
  let tm = 0;
  try {
    const work = (async () => {
      while (left() > 0 && G.gameId === gid) {
        const res = await raceGenerate(G.rows, G.cols, G.mines, sr, sc, Date.now() + left());
        if (G.gameId !== gid) return null;
        if (res && Array.isArray(res.board)) return res;
        if (left() <= 0) return false;
        if (res === false) {
          await new Promise((r) => setTimeout(r, 50));
        }
      }
      return G.gameId !== gid && null;
    })();
    const timeout = new Promise((r) => { tm = setTimeout(() => { abortWorkers(); r(false); }, left()); });
    const res = await Promise.race([work, timeout]);
    clearTimeout(tm); tm = 0;
    if (G.gameId !== gid) return abortWorkers();
    if (!res) { abortWorkers(); throw new Error(left() <= 0 ? "超时" : "生成失败"); }
    G.board = res.board;
    G.mines = res.board.flat().filter((v) => v === -1).length;
    G.nonMineCount = G.rows * G.cols - G.mines;
    G.bv3 = res.bv3;
    abortWorkers();
    showToast("无猜棋盘已生成", 2e3);
  } finally { clearTimeout(tm); clearInterval(iv); }
}

