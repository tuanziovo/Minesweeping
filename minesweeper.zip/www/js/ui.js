"use strict";
// Settlement & End Modal
function ensureSettlement() { return G.settlement || (G.settlement = { cheated: G.cheated, undoUsed: G.undoUsed, recorded: false }); }
function recordSettlementIfNeeded() { const s = G.settlement; if (G.gameOver && s && !s.recorded) { s.recorded = true; window.MineHome?.onEnd?.(s.win); } }
function checkWin() { if (G.revealedCount >= G.nonMineCount) endGame(true); }
function endGame(win, boomR = -1, boomC = -1) {
  ensureSettlement().win = win;
  G.gameOver = true;
  if (G.timer) setElapsed(performance.now() - G.timerStart);
  stopTimer(); renderTimer();
  playFeedback(win ? "win" : "explode");
  if (win) {
    afterWave(() => {
      const flags = [];
      for (let r = 0; r < G.rows; r++) for (let c = 0; c < G.cols; c++)
        if (G.board[r][c] === -1 && !G.flagged[r][c]) { G.flagged[r][c] = true; G.flagCount++; G.questioned[r][c] = false; flags.push([r, c]); }
      updateCounters();
      captureReplayStep("胜利结算", true);
      runWave(flags, G.rows / 2, G.cols / 2, () => { updateCounters(); R.timers.modal = setTimeout(() => showEndModal(true), 250); }, { flagReveal: true });
    });
    return;
  }
  const hasBoom = boomR >= 0 && boomC >= 0, mines = [], wrong = [];
  for (let r = 0; r < G.rows; r++) for (let c = 0; c < G.cols; c++) {
    if (G.board[r][c] === -1 && !G.flagged[r][c]) {
      G.questioned[r][c] = false; G.revealed[r][c] = true;
      if (!hasBoom || r !== boomR || c !== boomC) mines.push([r, c]);
    } else if (G.board[r][c] !== -1 && G.flagged[r][c]) wrong.push([r, c]);
  }
  captureReplayStep("失败结算", true, boomR, boomC);
  wrong.forEach(([r, c]) => syncCell(r, c));
  if (hasBoom) { syncCell(boomR, boomC); cellAt(boomR, boomC)?.add("exploded", "anim-explode"); }
  updateCounters();
  runWave(mines, boomR, boomC, () => { updateCounters(); R.timers.modal = setTimeout(() => showEndModal(false), 120); }, { mineReveal: true });
}
function showEndModal(win) {
  const s = ensureSettlement();
  if (!s.recorded) { s.recorded = true; window.MineHome?.onEnd?.(win); }
  dom.modalIconCircle.className = "modal-icon-circle " + (win ? "icon-win" : "icon-loss");
  dom.modalIcon.innerHTML = win
    ? '<svg viewBox="0 0 56 56" width="48" height="48"><polyline points="13,28 23,38 43,18" stroke="currentColor" stroke-width="5.5" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg>'
    : '<svg viewBox="0 0 24 24" aria-hidden="true"><use href="#ic-mine"/></svg>';
  dom.modalTitle.textContent = win ? "通关" : "踩雷";
  dom.modalBadge.innerHTML = s.cheated ? '<span class="new-record-badge">本局使用了辅助</span>' : win && window.MineHome?.lastNew ? '<span class="new-record-badge">新纪录</span>' : "";
  const ms = G.timeMs || 1e3 * G.time;
  const qStat = (k, v) => `<div class="quick-stat"><span class="quick-stat-label">${k}</span><span class="quick-stat-value">${v}</span></div>`;
  const card = (k, v, u) => `<div class="modal-stat-card"><div class="modal-stat-label">${k}</div><div class="modal-stat-value">${v}<small class="modal-stat-unit"> ${u}</small></div></div>`;
  dom.modalQuickStats.innerHTML = qStat("3BV", G.bv3) + qStat("3BV/s", ms > 0 ? (G.bv3 / (ms / 1e3)).toFixed(2) : "0.00") + qStat("IOE", G.usefulClicks > 0 ? (G.bv3 / G.usefulClicks).toFixed(2) : "0.00") + qStat("提示", G.hintsUsed + "次");
  dom.modalStats.className = "modal-stats";
  const timeStr = fmtSec(Math.floor(ms / 1e3)) + '<span class="cs">.' + pad2(Math.floor((ms % 1e3) / 10)) + "</span>";
  dom.modalStats.innerHTML = `<div class="modal-stat-card" style="grid-column:1/-1"><div class="modal-stat-label">用时</div><div class="modal-stat-value">${timeStr}<small class="modal-stat-unit">${ms < 6e4 ? " 秒" : ""}</small></div></div>` + card("插旗", G.flagCount, "个") + card("有效点击", G.usefulClicks, "次");
  dom.modalMessage.textContent = s.cheated ? "本局使用了辅助，不计成绩" : "";
  dom.modal.classList.add("show");
}
function closeModal() { dom.modal.classList.remove("show"); }

// Pan & Pinch on game-area
function bindAreaGestures() {
  dom.area.addEventListener("mousedown", (e) => {
    if (e.button !== 0) return;
    if (hitCell(e.clientX, e.clientY) && !G.gameOver && !G.placing) {
      if (!R.ignoreMouse) {
        const wr = dom.wrapper.getBoundingClientRect(), ar = dom.area.getBoundingClientRect();
        if (wr.width > ar.width || wr.height > ar.height) R.panArm = { x: e.clientX, y: e.clientY };
      }
      return;
    }
    startPan(e.clientX, e.clientY);
  });
  document.addEventListener("mousemove", (e) => {
    if (!R.pan) {
      if (!R.panArm) return;
      if (!(e.buttons & 1)) { R.panArm = null; return; }
      if (Math.hypot(e.clientX - R.panArm.x, e.clientY - R.panArm.y) < 8) return;
      startPan(R.panArm.x, R.panArm.y); R.panArm = null;
    }
    const dx = e.clientX - R.pan.x, dy = e.clientY - R.pan.y;
    if (Math.abs(dx) > 5 || Math.abs(dy) > 5) R.moved = true;
    R.offset = { x: R.pan.startOffsetX + dx, y: R.pan.startOffsetY + dy };
    schedulePan();
  });
  document.addEventListener("mouseup", resetPan);
  dom.area.addEventListener("dblclick", (e) => { if (!hitCell(e.clientX, e.clientY)) resetView(); });
  dom.area.addEventListener("wheel", (e) => {
    e.preventDefault();
    const ns = clamp(R.scale * (e.deltaY < 0 ? 1.12 : 0.9), R.minScale, R.maxScale);
    if (ns === R.scale) return;
    const ctr = boardCenter(), k = 1 - ns / R.scale;
    R.offset = { x: R.offset.x + (e.clientX - ctr.x) * k, y: R.offset.y + (e.clientY - ctr.y) * k };
    R.scale = ns; applyTransform(); settleZoom();
  }, { passive: false });
  dom.area.addEventListener("touchstart", (e) => {
    if (e.touches.length === 2) {
      const [a, b] = e.touches;
      R.pinch = { distance: Math.max(1, Math.hypot(b.clientX - a.clientX, b.clientY - a.clientY)), scale: R.scale, centerX: (a.clientX + b.clientX) / 2, centerY: (a.clientY + b.clientY) / 2 };
      R.wasPinching = true; resetPan(); e.preventDefault();
    } else if (e.touches.length === 1 && (!hitCell(e.touches[0].clientX, e.touches[0].clientY) || G.gameOver || G.placing)) {
      startPan(e.touches[0].clientX, e.touches[0].clientY);
    }
  }, { passive: false });
  document.addEventListener("touchmove", (e) => {
    if (R.pinch && e.touches.length >= 2) {
      const [a, b] = e.touches, cx = (a.clientX + b.clientX) / 2, cy = (a.clientY + b.clientY) / 2;
      const ns = clamp((R.pinch.scale * Math.hypot(b.clientX - a.clientX, b.clientY - a.clientY)) / R.pinch.distance, R.minScale, R.maxScale);
      const ctr = boardCenter(), k = 1 - ns / R.scale;
      R.offset = { x: R.offset.x + (R.pinch.centerX - ctr.x) * k + (cx - R.pinch.centerX), y: R.offset.y + (R.pinch.centerY - ctr.y) * k + (cy - R.pinch.centerY) };
      R.scale = ns; R.pinch.centerX = cx; R.pinch.centerY = cy;
      applyTransform(); return void settleZoom();
    }
    if (!R.pan || e.touches.length !== 1) return;
    const dx = e.touches[0].clientX - R.pan.x, dy = e.touches[0].clientY - R.pan.y;
    if (Math.abs(dx) > 5 || Math.abs(dy) > 5) R.moved = true;
    R.offset = { x: R.pan.startOffsetX + dx, y: R.pan.startOffsetY + dy };
    applyTransform();
  }, { passive: true });
  document.addEventListener("touchend", (e) => { if (R.pinch && e.touches.length < 2) R.pinch = null; if (!e.touches.length) { R.wasPinching = false; resetPan(); } }, { passive: true });
  document.addEventListener("touchcancel", () => { R.pinch = null; resetPan(); }, { passive: true });
}

function updateDensityHint() {
  const r = parseInt($("c-rows").value, 10) || 0, c = parseInt($("c-cols").value, 10) || 0, m = parseInt($("c-mines").value, 10) || 0;
  const cells = Math.max(0, r * c), ratio = cells ? Math.max(0, m) / cells : 0, maxM = cells > 9 ? cells - 9 : 1;
  dom.maxMinesHint.textContent = cells > 9 ? `(最多 ${maxM})` : "";
  $("c-mines").max = maxM;
  dom.density.className = "density-hint"; dom.density.textContent = "";
  if (!cells) return;
  if (ratio > 0.5) { dom.density.classList.add("error"); dom.density.textContent = `雷密度 ${Math.round(100 * ratio)}%，过高`; }
  else if (cells <= 30 && m > 0.3 * cells) { dom.density.classList.add("warn"); dom.density.textContent = `格子较少（${cells}格），建议降低雷数`; }
}

function onKeyDown(e) {
  if (MineHome.open) {
    if (RP.on && $("sub").classList.contains("show") && !e.ctrlKey && !e.metaKey && !e.altKey) {
      const tag = e.target?.tagName;
      if (e.key === " " && tag !== "BUTTON" && tag !== "INPUT") { e.preventDefault(); rpToggle(); return; }
      if ((e.key === "ArrowLeft" || e.key === "ArrowRight") && tag !== "INPUT") { e.preventDefault(); rpSeek(RP.shown + (e.key === "ArrowLeft" ? -1 : 1), true); return; }
    }
    if (e.key === "Escape") {
      if ($("sub").classList.contains("show")) MineHome.pg === "replay" ? MineHome.exitReplay() : $("sub").classList.remove("show");
      else if (dom.settings.classList.contains("show")) closeSettings();
      else if (MineHome.canContinue() && G.difficulty === MineHome.diff0) MineHome.close();
    }
    return;
  }
  const inSettings = dom.settings.classList.contains("show"), k = e.key.toLowerCase(), plain = !e.ctrlKey && !e.metaKey;
  if (e.key === "Escape") return inSettings ? closeSettings() : closeModal();
  if ((e.ctrlKey || e.metaKey) && k === "z" && !e.shiftKey && !inSettings) { e.preventDefault(); return performUndo(); }
  if (k === "r" && plain && !inSettings) {
    if (!G.firstClick && !G.gameOver && !G.placing && !(R.rConfirm && Date.now() - R.rConfirm < 1800)) {
      R.rConfirm = Date.now(); return showToast("再按一次 R 确认重开", 1600);
    }
    R.rConfirm = 0; closeModal(); dom.settings.classList.remove("show"); R.snap = null; return newGame();
  }
  if (k === "h" && plain && !inSettings) { if (!isUiBlocked()) requestHint(); return; }
  if (isUiBlocked() || e.ctrlKey || e.metaKey || e.altKey || G.gameOver || G.placing ||
    ((e.key === " " || e.key === "Enter") && document.activeElement?.tagName === "BUTTON") ||
    (!(e.key in ARROWS) && ![" ", "Enter", "f", "F"].includes(e.key))) return;
  e.preventDefault();
  if (!inBounds(G.keyboardRow, G.keyboardCol)) { G.keyboardRow = Math.floor(G.rows / 2); G.keyboardCol = Math.floor(G.cols / 2); }
  if (e.key in ARROWS) {
    cellAt(G.keyboardRow, G.keyboardCol)?.remove("kb-focus");
    const [dr, dc] = ARROWS[e.key];
    G.keyboardRow = clamp(G.keyboardRow + dr, 0, G.rows - 1);
    G.keyboardCol = clamp(G.keyboardCol + dc, 0, G.cols - 1);
  } else if (e.key === " " || e.key === "Enter") isNumbered(G.keyboardRow, G.keyboardCol) ? chordReveal(G.keyboardRow, G.keyboardCol) : revealCell(G.keyboardRow, G.keyboardCol);
  else if (k === "f") toggleFlag(G.keyboardRow, G.keyboardCol);
  const cell = cellAt(G.keyboardRow, G.keyboardCol);
  if (cell) { cell.add("kb-focus"); scrollCellIntoView(cell, 40); }
}

function bindEvents() {
  const clicks = {
    "btn-newgame": () => {
      if (!G.firstClick && !G.gameOver && !G.placing && !(R.rConfirm && Date.now() - R.rConfirm < 1800)) { R.rConfirm = Date.now(); return showToast("再点一次重开确认", 1600); }
      R.rConfirm = 0; newGame();
    },
    "btn-replay": () => { closeModal(); newGame(); },
    "btn-close-modal": closeModal,
    "btn-settings": openSettings,
    "btn-close-settings": () => closeSettings(),
    "btn-close-warning": () => { dom.warning.hidden = true; layoutBoard(true); },
    "btn-undo-modal": performUndo,
    "btn-undo-topbar": performUndo,
    "btn-hint": requestHint,
    "btn-apply-custom": () => { applyCustomInputs({ selectDifficulty: true }); R.snap = null; dom.settings.classList.remove("show"); if (MineHome.open) { R.homePaused = false; MineHome.close(); } newGame(); },
    "btn-reset-settings"() {
      if (R.confirmReset) { clearTimeout(R.confirmReset); R.confirmReset = null; this.textContent = "重置所有设置"; return resetAllSettings(); }
      this.textContent = "再点一次确认重置";
      R.confirmReset = setTimeout(() => { R.confirmReset = null; this.textContent = "重置所有设置"; }, 3e3);
    },
  };
  for (const [id, fn] of Object.entries(clicks)) $(id)?.addEventListener("click", fn);
  $("toggle-dark").addEventListener("change", (e) => { R.darkManual = true; setDark(e.target.checked); scheduleSave(); });
  [["toggle-sound", "soundEnabled"], ["toggle-question", "questionMarkEnabled"]].forEach(([id, prop]) =>
    $(id).addEventListener("change", (e) => { G[prop] = e.target.checked; scheduleSave(); }));
  $("longpress-delay").addEventListener("input", (e) => { syncLongPressUI(e.target.value); scheduleSave(); });
  ["input", "blur"].forEach((ev) => $("noguess-time-seconds").addEventListener(ev, (e) => onNgTimeInput(e.target, ev === "blur")));
  ["c-rows", "c-cols", "c-mines"].forEach((id) => $(id).addEventListener("input", updateDensityHint));
  dom.settings.addEventListener("click", (e) => {
    const opt = e.target.closest("[data-set]");
    opt ? setSetting(opt.dataset.set, opt.dataset.val) : e.target === e.currentTarget && closeSettings();
  });
  dom.modal.addEventListener("click", (e) => { if (e.target === e.currentTarget) closeModal(); });
  document.addEventListener("keydown", onKeyDown);
  document.addEventListener("click", (e) => { if (e.detail) e.target.closest?.("button")?.blur(); });
  addEventListener("resize", () => { clearTimer("resize"); R.timers.resize = setTimeout(() => layoutBoard(true), 100); });
  addEventListener("pagehide", () => { if (R.timers.save) { clearTimer("save"); saveSettings(); } R.audio?.close(); });
  bindAreaGestures();
}
matchMedia("(prefers-color-scheme: dark)").addEventListener("change", (e) => { if (!R.darkManual) setDark(e.matches); });
document.addEventListener("visibilitychange", () => {
  if (document.hidden) { if (G.timer && !G.gameOver) { setElapsed(performance.now() - G.timerStart); stopTimer(); R.hiddenPaused = true; } }
  else if (R.hiddenPaused) {
    R.hiddenPaused = false;
    if (!G.timer && !G.gameOver && !G.firstClick && !G.placing && !R.settingsPaused && !R.homePaused && !dom.settings.classList.contains("show")) startTimer();
  }
});

