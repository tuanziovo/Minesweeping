"use strict";
// Input handling
function clearTouchState() {
  clearTimer("longPress"); clearChordHints(); R.currentCell?.remove("pressing");
  R.chord = R.mouseCell = R.currentCell = R.touch = null;
  R.pressCancelled = R.dragging = R.longPress = false;
}
function startPress(r, c, noLong) {
  const gid = G.gameId;
  R.longPress = R.dragging = R.pressCancelled = false; R.chord = null;
  if (isNumbered(r, c)) { showChordHints(r, c); R.chord = [r, c]; return; }
  clearTimer("longPress");
  if (!noLong) R.timers.longPress = setTimeout(() => {
    if (G.gameId === gid && !G.gameOver && !G.placing && !R.dragging && !R.moved) { R.longPress = true; R.currentCell?.remove("pressing"); secondaryAct()(r, c); }
  }, G.longPressDelay);
}
function cancelPress(hard = false) { clearTimer("longPress"); if (hard) R.pressCancelled = true; R.chord = null; clearChordHints(); }
function endPress(r, c) {
  clearTimer("longPress"); clearChordHints();
  if (R.pressCancelled) { R.pressCancelled = false; return; }
  if (inBounds(r, c)) {
    if ((G.keyboardRow !== r || G.keyboardCol !== c) && inBounds(G.keyboardRow, G.keyboardCol)) cellAt(G.keyboardRow, G.keyboardCol)?.remove("kb-focus");
    G.keyboardRow = r; G.keyboardCol = c;
  }
  if (R.chord) { R.chord = null; if (!R.moved) chordReveal(r, c); }
  else if (!R.longPress && !R.dragging && !R.moved) (G.firstClick ? revealCell : primaryAct())(r, c);
}
function showChordHints(r, c) {
  const nbs = getNeighbors(r, c);
  const cls = nbs.filter((n) => G.flagged[n.row][n.col]).length === G.board[r][c] ? "hint" : "hint-dim";
  for (const n of nbs) if (!G.revealed[n.row][n.col] && !G.flagged[n.row][n.col]) {
    const cell = cellAt(n.row, n.col);
    if (cell) { cell.add(cls); G.hinted.push(cell); }
  }
}
function clearChordHints() { G.hinted.forEach((c) => c.remove("hint", "hint-dim")); G.hinted = []; }
function chordReveal(r, c) {
  if (!isNumbered(r, c)) return;
  const nbs = getNeighbors(r, c);
  if (nbs.filter((n) => G.flagged[n.row][n.col]).length !== G.board[r][c]) return playFeedback("deny");
  const todo = nbs.filter((n) => !G.revealed[n.row][n.col] && !G.flagged[n.row][n.col]);
  if (todo.length) { pushUndo(); G.usefulClicks++; openCells(todo.map((n) => [n.row, n.col]), r, c); if (!G.gameOver) checkWin(); }
}

const canHover = matchMedia("(hover:hover)").matches, reducedMotion = matchMedia("(prefers-reduced-motion: reduce)");
function setHover(cell) {
  if (cell === R.hoverCell) return;
  const prev = R.hoverCell; R.hoverCell = cell;
  if (prev) { R.dirty.add(prev); schedulePaint(); }
  if (cell) { R.dirty.add(cell); schedulePaint(); }
}
dom.board.addEventListener("mousedown", (e) => {
  const cell = hitCell(e.clientX, e.clientY);
  if (!cell || G.gameOver || G.placing || R.ignoreMouse) return;
  recordReplayPointer(e.clientX, e.clientY);
  const [r, c] = [cell.row, cell.col]; R.mouseCell = [r, c];
  if (e.button === 1) { e.preventDefault(); return chordReveal(r, c); }
  if (e.button === 2) secondaryAct()(r, c);
  if (e.button === 0) startPress(r, c, true);
});
dom.board.addEventListener("mouseup", (e) => {
  if (e.button !== 0) { R.mouseCell = null; return; }
  if (!R.mouseCell || G.gameOver || R.ignoreMouse) return;
  const [r, c] = R.mouseCell; R.mouseCell = null; endPress(r, c);
});
dom.board.addEventListener("mousemove", (e) => {
  if (R.ignoreMouse) return;
  recordReplayPointer(e.clientX, e.clientY);
  const cell = hitCell(e.clientX, e.clientY);
  if (canHover) setHover(cell);
  if (R.mouseCell && (!cell || cell.row !== R.mouseCell[0] || cell.col !== R.mouseCell[1])) { R.mouseCell = null; cancelPress(true); }
});
dom.board.addEventListener("mouseleave", () => { setHover(null); if (R.mouseCell) { R.mouseCell = null; cancelPress(true); } });
dom.board.addEventListener("contextmenu", (e) => e.preventDefault());
dom.board.addEventListener("touchstart", (e) => {
  R.touch = null;
  if (G.gameOver || G.placing || R.pan) return;
  if (e.touches.length !== 1) { R.wasPinching = true; R.currentCell?.remove("pressing"); return cancelPress(true); }
  R.wasPinching = false;
  const t = e.touches[0], cell = hitCell(t.clientX, t.clientY);
  if (!cell) return;
  recordReplayPointer(t.clientX, t.clientY);
  R.touch = { x: t.clientX, y: t.clientY, row: cell.row, col: cell.col };
  R.currentCell = cell; cell.add("pressing");
  startPress(cell.row, cell.col);
  if (R.chord) cell.remove("pressing");
}, { passive: true });
dom.board.addEventListener("touchmove", (e) => {
  if (!R.touch || G.gameOver || G.placing || R.longPress || R.pan || R.moved) { clearTimer("longPress"); return R.currentCell?.remove("pressing"); }
  const t = e.touches[0];
  if (t) recordReplayPointer(t.clientX, t.clientY);
  if (t && (Math.abs(t.clientX - R.touch.x) > 15 || Math.abs(t.clientY - R.touch.y) > 15)) {
    R.dragging = true; R.currentCell?.remove("pressing"); R.currentCell = null; clearTimer("longPress");
    startPan(t.clientX, t.clientY); R.moved = true;
  }
}, { passive: true });
dom.board.addEventListener("touchend", () => {
  R.currentCell?.remove("pressing");
  R.ignoreMouse = true; clearTimer("ignoreMouse");
  R.timers.ignoreMouse = setTimeout(() => { R.ignoreMouse = false; }, 500);
  !R.touch || R.dragging || R.moved || R.wasPinching ? cancelPress() : endPress(R.touch.row, R.touch.col);
  R.touch = null;
});
dom.board.addEventListener("touchcancel", () => { R.currentCell?.remove("pressing"); R.touch = null; cancelPress(true); });

// Undo & Replay capture
const canUndo = () => !G.firstClick && !G.placing && G.undo.length > 0;
function snapState() {
  const { rows, cols } = G, n = rows * cols, rev = new Uint8Array(n), flg = new Uint8Array(n), qm = new Uint8Array(n);
  for (let r = 0; r < rows; r++) for (let c = 0; c < cols; c++) {
    const i = r * cols + c;
    rev[i] = G.revealed[r][c] ? 1 : 0; flg[i] = G.flagged[r][c] ? 1 : 0; qm[i] = G.questioned[r][c] ? 1 : 0;
  }
  return { revealed: rev, flagged: flg, questioned: qm };
}
function pushUndo() {
  if (G.firstClick) return;
  G.boardVersion++;
  const st = snapState();
  G.undo.push({ ...st, flagCount: G.flagCount, revealedCount: G.revealedCount, mines: G.mines, usefulClicks: G.usefulClicks, time: G.time, timeMs: G.timeMs, timerStart: G.timerStart, gameOver: G.gameOver });
  if (G.undo.length > 50) G.undo.shift();
  syncUndoButtons();
}
function performUndo() {
  if (!canUndo()) return;
  if (!G.undoUsed && !(Date.now() - (R.undoAsk || 0) < 3e3)) { R.undoAsk = Date.now(); return showToast("撤销后本局不计成绩，3 秒内再点一次确认", 2500); }
  flushWave(); clearTimer("modal");
  const u = G.undo.pop(), wasOver = G.gameOver;
  if (wasOver && !u.gameOver && G.settlement) G.settlement = null;
  G.cheated = G.undoUsed = true;
  const prev = wasOver ? null : snapState();
  Object.assign(G, { flagCount: u.flagCount, revealedCount: u.revealedCount, mines: u.mines, usefulClicks: u.usefulClicks ?? G.usefulClicks, time: u.time, timeMs: u.timeMs, timerStart: u.timerStart, gameOver: u.gameOver });
  G.boardVersion++;
  for (let r = 0; r < G.rows; r++) for (let c = 0; c < G.cols; c++) {
    const i = r * G.cols + c;
    G.revealed[r][c] = u.revealed[i] === 1; G.flagged[r][c] = u.flagged[i] === 1; G.questioned[r][c] = u.questioned[i] === 1;
  }
  if (wasOver && !u.gameOver) { closeModal(); stopTimer(); startTimer(); }
  else if (G.timer) G.timerStart = performance.now() - (u.timeMs || 1e3 * u.time);
  clearChordHints();
  if (prev) {
    for (let r = 0; r < G.rows; r++) for (let c = 0; c < G.cols; c++) {
      const i = r * G.cols + c;
      if (prev.revealed[i] !== u.revealed[i] || prev.flagged[i] !== u.flagged[i] || prev.questioned[i] !== u.questioned[i]) syncCell(r, c);
    }
  } else syncAllCells();
  updateCounters(); syncUndoButtons(); playFeedback("undo");
  captureReplayStep("撤销", false, G.keyboardRow, G.keyboardCol);
}
function syncUndoButtons() { const en = canUndo(); dom.undoTop.disabled = !en; dom.undoModal.disabled = !en; }

const replayElapsedMs = () => (G.timer ? Math.max(0, performance.now() - G.timerStart) : Math.max(0, G.timeMs || 1e3 * G.time || 0));
function pushReplayPosition(x, y, elapsed = replayElapsedMs(), snap = false) {
  const tr = G.replay?.track;
  if (!tr || !Number.isFinite(x) || !Number.isFinite(y) || (tr.length >= 8e3 && !snap)) return null;
  const last = tr[tr.length - 1];
  x = Number(x.toFixed(3)); y = Number(y.toFixed(3));
  const stamp = Math.round(elapsed);
  if (last && Math.hypot(x - last[1], y - last[2]) < 0.025) {
    if (snap) { last[0] = Math.max(last[0], stamp); last[1] = x; last[2] = y; }
    return last[0];
  }
  const t = Math.max(last ? last[0] + 1 : 0, stamp);
  tr.push([t, x, y]);
  return t;
}
function recordReplayPointer(cx, cy) {
  if (!G.replay || !R.geo) return;
  const cell = hitCell(cx, cy);
  if (cell) pushReplayPosition(cell.col + 0.5, cell.row + 0.5);
}
function startReplay() {
  if (!G.board.length) return;
  G.replay = {
    v: 1, r: G.rows, c: G.cols, n: G.mines,
    b: G.board.flat().map((v) => (v === -1 ? "m" : String(v))).join(""),
    steps: [{ t: 0, a: "开始", c: "" }], track: [], _last: new Uint8Array(G.rows * G.cols),
  };
}
function captureReplayStep(action = "操作", force = false, row = -1, col = -1) {
  const rp = G.replay;
  if (!rp || G.firstClick || !G.revealed.length) return;
  const st = new Uint8Array(rp.r * rp.c), diff = [];
  for (let r = 0, i = 0; r < rp.r; r++) for (let c = 0; c < rp.c; c++, i++) {
    st[i] = G.flagged[r][c] ? 2 : G.questioned[r][c] ? 3 : G.revealed[r][c] ? 1 : 0;
    if (st[i] !== rp._last[i]) diff.push(i.toString(36) + ":" + st[i]);
  }
  if (!diff.length && !force) return;
  const elapsed = replayElapsedMs(); let stepTime = Math.round(elapsed), pos = -1;
  if (Number.isInteger(row) && Number.isInteger(col) && inBounds(row, col)) {
    pos = row * rp.c + col;
    const ct = pushReplayPosition(col + 0.5, row + 0.5, elapsed, true);
    if (Number.isFinite(ct)) stepTime = Math.max(stepTime, ct);
  } else {
    const last = rp.track[rp.track.length - 1];
    if (last && last[1] >= 0 && last[2] >= 0) pos = Math.floor(last[2]) * rp.c + Math.floor(last[1]);
  }
  if (pos < 0 && diff.length) pos = parseInt(diff[0].split(":")[0], 36);
  rp.steps.push({ t: stepTime, a: action, c: diff.join(","), p: pos });
  rp._last = st;
  if (rp.steps.length > 3e3) rp.steps.length = 3e3;
}

// Gameplay actions
function toggleFlag(r, c) {
  if (G.firstClick || G.revealed[r][c] || G.placing) return;
  pushUndo();
  if (G.flagged[r][c] || G.questioned[r][c]) {
    if (G.flagged[r][c]) {
      G.flagged[r][c] = false; G.flagCount = Math.max(0, G.flagCount - 1);
      if (G.questionMarkEnabled) { G.questioned[r][c] = true; playFeedback("question"); } else playFeedback("unflag");
      syncCell(r, c, "anim-unflag");
    } else { G.questioned[r][c] = false; playFeedback("unflag"); syncCell(r, c); }
  } else {
    G.flagged[r][c] = true; G.flagCount++; playFeedback("flag"); syncCell(r, c, "anim-flag");
  }
  updateCounters();
  captureReplayStep("标记", true, r, c);
}
async function revealCell(r, c) {
  if (G.flagged[r][c] || G.revealed[r][c] || G.placing) return;
  const first = G.firstClick;
  if (first) {
    const gid = G.gameId;
    G.firstClick = false; G.placing = true;
    try {
      if (G.soundEnabled) try { ensureAudio(); } catch (e) { console.warn("Audio init failed", e); }
      await generateFirstClickBoard(r, c, gid);
    } catch (err) {
      if (G.gameId !== gid) return;
      abortWorkers(); hideToast();
      dom.warning.querySelector("span").textContent = `无猜生成${err?.message === "超时" ? "超时" : "失败"}，本局改为随机布雷，不计成绩。${err?.message === "超时" ? "可在设置中调长生成时限。" : ""}`;
      dom.warning.hidden = false; layoutBoard(true); G.noguessFallback = true; placeTraditionalBoard(r, c);
    } finally { if (G.gameId === gid) G.placing = false; }
    if (G.gameId !== gid) return;
    startReplay();
    dom.settings.classList.contains("show") ? (R.settingsPaused = true) : startTimer();
    updateCounters();
  }
  if (!first) pushUndo();
  G.usefulClicks++;
  openCells([[r, c]], r, c);
  if (!G.gameOver) checkWin();
}
function openCells(seeds, ox, oy) {
  const q = [], seen = new Set();
  const push = (r, c, d) => { const k = idxOf(r, c); if (!seen.has(k)) { seen.add(k); G.revealed[r][c] = true; G.questioned[r][c] = false; q.push([r, c, d]); } };
  for (const [r, c] of seeds) if (inBounds(r, c) && !G.revealed[r][c] && !G.flagged[r][c]) push(r, c, 0);
  for (let i = 0; i < q.length; i++) {
    const [r, c, d] = q[i];
    if (G.board[r][c] === -1) {
      for (const [rr, cc] of q) if (G.board[rr][cc] !== -1) syncCell(rr, cc);
      for (let j = i + 1; j < q.length; j++) if (G.board[q[j][0]][q[j][1]] !== -1) G.revealedCount++;
      endGame(false, r, c);
      return true;
    }
    G.revealedCount++;
    if (G.board[r][c] === 0) nbrs(r, c, G.rows, G.cols, (nr, nc) => { if (!G.revealed[nr][nc] && !G.flagged[nr][nc]) push(nr, nc, d + 1); });
  }
  if (q.length) playFeedback("reveal", { count: q.length, value: G.board[q[0][0]][q[0][1]] });
  runWave(q, ox, oy);
  captureReplayStep("翻开", true, ox, oy);
  return false;
}
function placeTraditionalBoard(sr, sc) {
  const { rows, cols } = G, seeded = R.rngSeed != null;
  G.board = genBoard(rows, cols, G.mines, sr, sc, seeded ? mulberry32(R.rngSeed) : Math.random, seeded);
  G.mines = G.board.flat().filter((v) => v === -1).length;
  G.nonMineCount = rows * cols - G.mines;
  G.bv3 = bv3(G.board, rows, cols);
}

