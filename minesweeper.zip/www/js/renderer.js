"use strict";
// Canvas & Shared Cell Renderer
const MASK = {
  flagged: 1, questioned: 2, revealed: 4, "mine-show": 8, exploded: 16, "wrong-flag": 32,
  hint: 64, "hint-dim": 128, "kb-focus": 256, pressing: 512, "hint-flash": 1024,
  "anim-reveal": 2048, "anim-mine-reveal": 4096, "anim-flag": 8192, "anim-unflag": 16384, "anim-explode": 32768,
};
const TIMED_ANIMS = [
  [MASK["anim-reveal"], 0.26, true], [MASK["anim-mine-reveal"], 0.12, true],
  [MASK["anim-flag"], 0.18, true], [MASK["anim-unflag"], 0.12, true],
  [MASK["hint-flash"], 1, true], [MASK["anim-explode"], 0.6, false],
];
const ANIM_MASK = TIMED_ANIMS.reduce((a, [b]) => a | b, 0);
const SPILL_MASK = ANIM_MASK | MASK.hint | MASK["hint-dim"] | MASK["kb-focus"] | MASK.pressing;
const FLAG_POLY = [[0.12, 0], [0.62, 0], [0.66, 0.12], [1, 0.12], [1, 0.64], [0.48, 0.64], [0.44, 0.52], [0.24, 0.52], [0.24, 1], [0.12, 1]];
const P_MINE_RAYS = new Path2D("M12 1.5v3M12 19.5v3M1.5 12h3M19.5 12h3M4.58 4.58l2.12 2.12M19.42 19.42l-2.12-2.12M19.42 4.58l-2.12 2.12M4.58 19.42l2.12-2.12");
const P_Q = new Path2D("M9 9a3 3 0 1 1 5.12 2.13C13.38 12 12 13 12 14");
const P_X = new Path2D("M18 6L6 18M6 6l12 12");

class Cell {
  constructor(r, c, cols) {
    this.row = r; this.col = c; this.idx = r * cols + c;
    this.mask = 0; this.num = 0; this.starts = null; this.spill = false;
  }
  contains(name) { return !!(this.mask & (MASK[name] || 0)); }
  add(...names) { for (const n of names) this.setBit(MASK[n], true); }
  remove(...names) { for (const n of names) this.setBit(MASK[n], false); }
  setBit(bit, on, animSet = R.animating, dirtySet = R.dirty, onDirty = schedulePaint) {
    if (!bit || on === !!(this.mask & bit)) return;
    this.mask = on ? this.mask | bit : this.mask & ~bit;
    if (on && bit & ANIM_MASK) this.startTimed(bit, animSet);
    else if (!on && this.starts) delete this.starts[bit];
    dirtySet.add(this);
    onDirty?.();
  }
  startTimed(bit, animSet = R.animating) {
    (this.starts || (this.starts = {}))[bit] = performance.now();
    animSet.add(this);
  }
  setState(mask, num) {
    if (mask === this.mask && num === this.num) return;
    const cleared = this.mask & ~mask, added = mask & ~this.mask & ANIM_MASK;
    this.mask = mask; this.num = num;
    if (cleared && this.starts) for (const [b] of TIMED_ANIMS) if (cleared & b) delete this.starts[b];
    for (const [b] of TIMED_ANIMS) if (added & b) this.startTimed(b);
    R.dirty.add(this); schedulePaint();
  }
  getBoundingClientRect() {
    const g = R.geo, ctr = boardCenter();
    const left = ctr.x - (g.width * R.scale) / 2 + this.col * g.step * R.scale;
    const top = ctr.y - (g.height * R.scale) / 2 + this.row * g.step * R.scale;
    const s = g.cs * R.scale;
    return { left, top, right: left + s, bottom: top + s, width: s, height: s };
  }
}

function invalidatePalette() { R.palette = null; R.fullRepaint = true; schedulePaint(); if (RP.on) rpLayout(); }
function readPalette() {
  const probe = document.createElement("div");
  probe.hidden = true;
  document.body.appendChild(probe);
  const css = (v, prop = "backgroundColor") => { probe.style[prop] = v; return getComputedStyle(probe)[prop]; };
  const numbers = [""];
  for (let i = 1; i <= 8; i++) numbers.push(css(`var(--n${i})`, "color"));
  const pal = {
    hidden: css("var(--hidden)"), hover: css("var(--hover)"), open: css("var(--open)"),
    flaggedBg: css("var(--pc)"), questionBg: css("var(--sc)"), mineBg: css("var(--mine-bg)"),
    mineFg: css("var(--mine-fg)", "color"), boom: css("var(--boom)"), wrong: css("var(--wrong)"),
    error: css("var(--err)"), warn: css("var(--warn)"), warnSoft: css("var(--warn-soft)"),
    accent: css("var(--accent)"), accentRing: css("color-mix(in srgb,var(--accent) 60%,transparent)"),
    outline: css("var(--out)"), flag: css("var(--flag)"), border: css("var(--cell-border)"),
    numbers, font: getComputedStyle(document.body).fontFamily,
  };
  probe.remove();
  return pal;
}
function calcGeo(rows, cols, cs, gap, dprScale, maxPx = MAX_PIXELS) {
  const width = cols * cs + (cols - 1) * gap, height = rows * cs + (rows - 1) * gap;
  const k = Math.min(dprScale, Math.sqrt(maxPx / (width * height)));
  return {
    cs, gap, width, height, step: cs + gap, k,
    pw: Math.max(1, Math.round(width * k)), ph: Math.max(1, Math.round(height * k)),
    radius: clamp(Math.round(0.22 * cs), 2, 10), fontPx: Math.max(5, Math.round(0.56 * cs)),
  };
}
function sizeMainCanvas() {
  if (!R.canvas) {
    R.canvas = document.createElement("canvas");
    R.canvas.setAttribute("role", "img");
    R.canvas.setAttribute("aria-label", "扫雷棋盘");
    dom.board.replaceChildren(R.canvas);
  }
  const cv = R.canvas, gap = parseFloat(dom.board.style.gap) || 0;
  const g = calcGeo(G.rows, G.cols, R.cellSize, gap, (window.devicePixelRatio || 1) * Math.max(1, R.scale));
  let copy = null;
  if (cv.style.width === g.width + "px" && cv.style.height === g.height + "px" && R.ctx && (cv.width !== g.pw || cv.height !== g.ph)) {
    copy = R.scratchCanvas || (R.scratchCanvas = document.createElement("canvas"));
    copy.width = cv.width; copy.height = cv.height;
    copy.getContext("2d").drawImage(cv, 0, 0);
  }
  if (cv.width !== g.pw || cv.height !== g.ph) { cv.width = g.pw; cv.height = g.ph; }
  cv.style.width = g.width + "px"; cv.style.height = g.height + "px";
  const ctx = (R.ctx = cv.getContext("2d"));
  if (copy) ctx.drawImage(copy, 0, 0, g.pw, g.ph);
  ctx.setTransform(g.pw / g.width, 0, 0, g.ph / g.height, 0, 0);
  R.geo = g; R.fullRepaint = true; R.keepBitmap = !!copy;
  schedulePaint();
}
function hitCell(clientX, clientY) {
  const g = R.geo;
  if (!g || !R.cells) return null;
  const ctr = boardCenter();
  const lx = (clientX - ctr.x) / R.scale + g.width / 2, ly = (clientY - ctr.y) / R.scale + g.height / 2;
  if (lx < 0 || ly < 0 || lx >= g.width || ly >= g.height) return null;
  const c = Math.floor(lx / g.step), r = Math.floor(ly / g.step);
  return lx - c * g.step >= g.cs || ly - r * g.step >= g.cs ? null : R.cells[r * G.cols + c] || null;
}
const keyframe = (t, pts) => {
  if (t >= 1) return pts[pts.length - 1][1];
  for (let i = 1; i < pts.length; i++) {
    const [x1, y1] = pts[i];
    if (t <= x1) { const [x0, y0] = pts[i - 1]; return y0 + (y1 - y0) * (1 - (1 - (t - x0) / (x1 - x0)) ** 3); }
  }
  return pts[pts.length - 1][1];
};
function roundRectPath(ctx, x, y, w, h, r) {
  ctx.beginPath();
  if (ctx.roundRect) ctx.roundRect(x, y, w, h, Math.max(0, r));
  else {
    const rr = Math.max(0, Math.min(r, w / 2, h / 2));
    ctx.moveTo(x + rr, y);
    ctx.arcTo(x + w, y, x + w, y + h, rr); ctx.arcTo(x + w, y + h, x, y + h, rr);
    ctx.arcTo(x, y + h, x, y, rr); ctx.arcTo(x, y, x + w, y, rr); ctx.closePath();
  }
}
const animAge = (c, bit, now) => { const t = c.starts?.[bit]; return t == null ? null : (now - t) / 1e3; };
function drawFlag(ctx, cx, cy, size, color, scale, rot, alpha) {
  ctx.save();
  if (alpha != null) ctx.globalAlpha *= alpha;
  ctx.translate(cx, cy); ctx.rotate((rot * Math.PI) / 180); ctx.scale(scale, scale);
  ctx.fillStyle = color; ctx.beginPath();
  FLAG_POLY.forEach(([px, py], i) => { const x = (px - 0.5) * size, y = (py - 0.5) * size; i ? ctx.lineTo(x, y) : ctx.moveTo(x, y); });
  ctx.closePath(); ctx.fill(); ctx.restore();
}
function drawIcon24(ctx, cx, cy, size, fn) {
  ctx.save(); ctx.translate(cx - size / 2, cy - size / 2); ctx.scale(size / 24, size / 24);
  ctx.lineCap = "round"; fn(ctx); ctx.restore();
}
function drawCellBase(ctx, cell, now, pal, g, hover = R.hoverCell) {
  const { cs, step, k, radius } = g, rawX = cell.col * step, rawY = cell.row * step;
  const x = Math.round(rawX * k) / k, y = Math.round(rawY * k) / k, pad = g.gap / 2;
  const cx0 = Math.floor((rawX - pad) * k) / k, cy0 = Math.floor((rawY - pad) * k) / k;
  const cw = Math.ceil((rawX + cs + pad) * k) / k - cx0, ch = Math.ceil((rawY + cs + pad) * k) / k - cy0;
  ctx.clearRect(cx0, cy0, cw, ch);
  ctx.save(); ctx.beginPath(); ctx.rect(cx0, cy0, cw, ch); ctx.clip();

  const m = cell.mask, rev = m & MASK.revealed, flg = m & MASK.flagged, prs = m & MASK.pressing, qm = m & MASK.questioned;
  let age, sc = 1, al = 1, fSc = 1, fRot = 0;
  if (m & MASK["anim-reveal"] && (age = animAge(cell, MASK["anim-reveal"], now)) !== null) {
    const p = age / 0.26; sc = keyframe(p, [[0, 0.62], [0.6, 1.06], [1, 1]]); al = keyframe(p, [[0, 0], [0.6, 1], [1, 1]]);
  }
  if (m & MASK["anim-mine-reveal"] && (age = animAge(cell, MASK["anim-mine-reveal"], now)) !== null)
    al = 0.45 + 0.55 * Math.min(1, age / 0.12);
  if (m & MASK["anim-unflag"] && (age = animAge(cell, MASK["anim-unflag"], now)) !== null) {
    const p = age / 0.12; sc = keyframe(p, [[0, 0.84], [0.55, 1.045], [1, 1]]); al = keyframe(p, [[0, 0.42], [1, 1]]);
  }
  if (m & MASK["anim-explode"] && (age = animAge(cell, MASK["anim-explode"], now)) !== null && age < 0.35)
    sc = keyframe(age / 0.35, [[0, 1], [0.35, 1.25], [0.7, 0.96], [1, 1]]);
  if (m & MASK["anim-flag"] && (age = animAge(cell, MASK["anim-flag"], now)) !== null) {
    const p = age / 0.18; fSc = keyframe(p, [[0, 0], [0.65, 1.18], [1, 1]]); fRot = keyframe(p, [[0, -35], [0.65, 7], [1, 0]]);
  }
  if (prs) sc *= 0.92;

  let bg = pal.hidden;
  if (hover === cell && !rev && !flg && !qm) bg = pal.hover;
  if (rev) bg = pal.open;
  if (flg) bg = pal.flaggedBg;
  if (qm) bg = pal.questionBg;
  if (m & MASK["mine-show"]) bg = pal.mineBg;
  if (m & MASK.exploded) bg = pal.boom;
  if (m & MASK["wrong-flag"]) bg = pal.wrong;
  if (prs) bg = pal.warnSoft;

  const midX = x + cs / 2, midY = y + cs / 2;
  ctx.save();
  ctx.globalAlpha = al * (m & MASK["hint-dim"] ? 0.72 : 1);
  const scaled = Math.abs(sc - 1) > 0.004;
  if (scaled) { ctx.translate(midX, midY); ctx.scale(sc, sc); ctx.translate(-midX, -midY); }
  if (!rev && !prs) { ctx.fillStyle = "rgba(0,0,0,.09)"; roundRectPath(ctx, x, y + 1, cs, cs, radius); ctx.fill(); }
  ctx.fillStyle = bg; roundRectPath(ctx, x, y, cs, cs, radius); ctx.fill();
  if (!rev) { ctx.strokeStyle = pal.border; ctx.lineWidth = 1; roundRectPath(ctx, x + 0.5, y + 0.5, cs - 1, cs - 1, radius - 0.5); ctx.stroke(); }

  if (flg) drawFlag(ctx, midX, midY, 0.6 * cs, pal.flag, fSc, fRot, m & MASK["wrong-flag"] ? 0.4 : null);
  if (m & MASK["wrong-flag"]) drawIcon24(ctx, midX, midY, 0.66 * cs, (c) => { c.strokeStyle = pal.error; c.lineWidth = 2.4; c.stroke(P_X); });
  else if (qm) {
    ctx.strokeStyle = pal.accent; ctx.lineWidth = 2.2;
    drawIcon24(ctx, midX, midY, 0.6 * cs, (c) => { c.stroke(P_Q); c.fillStyle = pal.accent; c.beginPath(); c.arc(12, 18, 1, 0, 2 * Math.PI); c.fill(); });
  } else if (m & MASK["mine-show"]) {
    const fg = m & MASK.exploded ? "#fff" : pal.mineFg;
    ctx.strokeStyle = fg; ctx.fillStyle = fg; ctx.lineWidth = 1.9;
    drawIcon24(ctx, midX, midY, 0.63 * cs, (c) => {
      c.stroke(P_MINE_RAYS); c.beginPath(); c.arc(12, 12, 5.8, 0, 2 * Math.PI); c.fill();
      c.fillStyle = "rgba(255,255,255,.35)"; c.beginPath(); c.ellipse(9.8, 9.8, 1.6, 1, (-35 * Math.PI) / 180, 0, 2 * Math.PI); c.fill();
    });
  } else if (rev && cell.num > 0) {
    if (scaled) { ctx.translate(midX, midY); ctx.scale(1 / sc, 1 / sc); ctx.translate(-midX, -midY); }
    ctx.fillStyle = pal.numbers[cell.num];
    ctx.font = `800 ${g.fontPx}px ${pal.font}`;
    ctx.textAlign = "center"; ctx.textBaseline = "middle";
    ctx.fillText(cell.num, midX, midY + 0.05 * g.fontPx);
  }
  ctx.restore(); ctx.restore();
  cell.spill = !!(m & SPILL_MASK);
}
function drawCellOverlay(ctx, cell, now, pal, g) {
  const { cs, step, radius, k } = g, m = cell.mask;
  const x = Math.round(cell.col * step * k) / k, y = Math.round(cell.row * step * k) / k;
  if (m & MASK.pressing) {
    ctx.save(); ctx.translate(x + cs / 2, y + cs / 2); ctx.scale(0.92, 0.92);
    ctx.strokeStyle = pal.warn; ctx.lineWidth = 2; roundRectPath(ctx, -cs / 2 - 1, -cs / 2 - 1, cs + 2, cs + 2, radius + 1); ctx.stroke(); ctx.restore();
  }
  if (m & MASK.hint) {
    ctx.strokeStyle = pal.accent; ctx.lineWidth = 2.5; roundRectPath(ctx, x - 1.25, y - 1.25, cs + 2.5, cs + 2.5, radius + 1.25); ctx.stroke();
  } else if (m & MASK["hint-dim"]) {
    ctx.save(); ctx.globalAlpha = 0.72; ctx.strokeStyle = pal.outline; ctx.lineWidth = 2; roundRectPath(ctx, x - 1, y - 1, cs + 2, cs + 2, radius + 1); ctx.stroke(); ctx.restore();
  }
  if (m & MASK["kb-focus"]) {
    ctx.strokeStyle = pal.accent; ctx.lineWidth = 3; roundRectPath(ctx, x + 0.5, y + 0.5, cs - 1, cs - 1, radius); ctx.stroke();
  }
  for (const [bit, dur, col] of [[MASK["hint-flash"], 1, pal.accentRing], [MASK["anim-explode"], 0.6, "rgba(179,38,30,.55)"]]) {
    const age = m & bit ? animAge(cell, bit, now) : null;
    if (age !== null && age < dur) {
      const p = age / dur, sc = keyframe(p, [[0, 1], [1, 2.2]]), sz = cs * sc;
      ctx.save(); ctx.globalAlpha = 1 - keyframe(p, [[0, 0], [1, 1]]);
      ctx.strokeStyle = col; ctx.lineWidth = 3;
      roundRectPath(ctx, x + cs / 2 - sz / 2 - 1.5, y + cs / 2 - sz / 2 - 1.5, sz + 3, sz + 3, radius * sc + 1.5);
      ctx.stroke(); ctx.restore();
    }
  }
}
function drawCells(ctx, g, cells, time, pal, hover = R.hoverCell) {
  for (const c of cells) drawCellBase(ctx, c, time, pal, g, hover);
  for (const c of cells) if (c.mask & SPILL_MASK) drawCellOverlay(ctx, c, time, pal, g);
}
function paintSlice(ctx, g, prog, time, pal, budget, hover = R.hoverCell) {
  const deadline = performance.now() + budget, { list } = prog;
  for (; prog.phase < 2; prog.phase++, prog.i = 0) {
    while (prog.i < list.length) {
      const c = list[prog.i++];
      if (prog.phase === 0) drawCellBase(ctx, c, time, pal, g, hover);
      else if (c.mask & SPILL_MASK) drawCellOverlay(ctx, c, time, pal, g);
      if (!(prog.i & 15) && performance.now() >= deadline) return false;
    }
  }
  return true;
}
function tickAnims(anims, dirty, now, onExpire) {
  for (const c of anims) {
    let live = false;
    for (const [bit, dur, clear] of TIMED_ANIMS) {
      if (!(c.mask & bit)) continue;
      const age = animAge(c, bit, now);
      if (age !== null) {
        if (age < dur) live = true;
        else if (clear) onExpire(c, bit);
        else c.starts[bit] = null;
      }
    }
    dirty.add(c);
    if (!live) anims.delete(c);
  }
}
function flushDirty(ctx, g, dirty, cells, rows, cols, time, pal, hover) {
  if (!dirty.size || !ctx) return null;
  const out = new Set();
  for (const c of dirty) {
    out.add(c);
    const sp = c.spill || (c.mask & SPILL_MASK);
    for (let dr = -1; dr <= 1; dr++) for (let dc = -1; dc <= 1; dc++) {
      const r = c.row + dr, cl = c.col + dc;
      if ((dr || dc) && r >= 0 && r < rows && cl >= 0 && cl < cols) {
        const nb = cells[r * cols + cl];
        if (sp || nb.spill || (nb.mask & SPILL_MASK)) out.add(nb);
      }
    }
  }
  const list = [...out].sort((a, b) => a.idx - b.idx);
  dirty.clear();
  drawCells(ctx, g, list, time, pal, hover);
  return list;
}

// Hi-res zoom overlay
const ovCovers = (v, r, s = 0) => r.x0 >= v.x0 - s && r.x1 <= v.x0 + v.w + s && r.y0 >= v.y0 - s && r.y1 <= v.y0 + v.h + s;
function ovNeed() {
  if (!R.geo || !R.cells || R.ov?.off) return 0;
  const want = Math.min(IS_MOBILE ? 6 : 12, (window.devicePixelRatio || 1) * R.scale);
  return R.geo.k < 0.9 * want ? want : 0;
}
function ovVisible() {
  const { width, height } = R.geo, { aw, ah } = getDims(), s = R.scale;
  const cx = width / 2 - R.offset.x / s, cy = height / 2 - R.offset.y / s;
  return { x0: Math.max(0, cx - aw / 2 / s), x1: Math.min(width, cx + aw / 2 / s), y0: Math.max(0, cy - ah / 2 / s), y1: Math.min(height, cy + ah / 2 / s) };
}
function ovFail(err) {
  const v = R.ov;
  if (v) { v.off = true; v.prog = null; v.ready = false; v.canvas?.remove(); }
  if (R.canvas) R.canvas.style.visibility = "visible";
  console.warn("hi-res overlay disabled", err);
}
function ovApply() {
  const v = R.ov;
  if (!v || v.off || !v.canvas) return;
  try {
    const show = v.ready && v.w > 0 && ovNeed() > 0 && v.k2 > 1.05 * R.geo.k && ovCovers(v, ovVisible(), 0.5);
    if (show === !!v.on) return;
    v.on = show;
    v.canvas.style.visibility = show ? "visible" : "hidden";
    R.canvas.style.visibility = show ? "hidden" : "visible";
  } catch (err) { ovFail(err); }
}
function ovInvalidate() { const v = R.ov; if (!v) return; v.ready = false; v.prog = null; v.w = 0; v.need = true; ovApply(); }
function ovSchedule(delay = 140) { if (!ovNeed()) return; const v = R.ov || (R.ov = {}); clearTimeout(v.timer); v.timer = setTimeout(ovCheck, delay); }
function ovCheck() {
  const v = R.ov;
  if (!v || v.off) return;
  const want = ovNeed();
  if (!want) {
    if (v.canvas && v.canvas.width > 1) { v.ready = false; v.prog = null; v.w = 0; v.canvas.width = v.canvas.height = 1; }
    return ovApply();
  }
  const vis = ovVisible();
  if (v.ready && v.w && ovCovers(v, vis) && Math.abs(want / v.k2 - 1) < 0.15) return;
  ovBuild(want, vis);
}
function ovBuild(want, vis) {
  const v = R.ov, g = R.geo, vw = vis.x1 - vis.x0, vh = vis.y1 - vis.y0;
  if (!v || !g || vw <= 0 || vh <= 0) return;
  try {
    let res = want, margin = Math.min(0.35, (Math.sqrt(OV_MAX_PIXELS / (vw * vh * res * res)) - 1) / 2);
    if (margin < 0.1) { margin = 0.1; res = Math.min(res, Math.sqrt(OV_MAX_PIXELS / (vw * vh * 1.44))); }
    if (res <= 1.05 * g.k) { v.ready = false; v.w = 0; return ovApply(); }
    const x0 = Math.max(0, Math.floor((vis.x0 - margin * vw) * res)) / res, y0 = Math.max(0, Math.floor((vis.y0 - margin * vh) * res)) / res;
    const pw = Math.max(1, Math.ceil((Math.min(g.width, vis.x1 + margin * vw) - x0) * res - 1e-6));
    const ph = Math.max(1, Math.ceil((Math.min(g.height, vis.y1 + margin * vh) - y0) * res - 1e-6));
    if (!v.canvas) {
      v.canvas = document.createElement("canvas");
      v.canvas.style.cssText = "position:absolute;left:0;top:0;pointer-events:none;visibility:hidden";
      dom.board.style.position = "relative"; dom.board.appendChild(v.canvas);
      v.ctx = v.canvas.getContext("2d");
    }
    if (v.canvas.width !== pw || v.canvas.height !== ph) { v.canvas.width = pw; v.canvas.height = ph; }
    Object.assign(v.canvas.style, { left: x0 + "px", top: y0 + "px", width: pw / res + "px", height: ph / res + "px" });
    v.ctx.setTransform(1, 0, 0, 1, 0, 0); v.ctx.clearRect(0, 0, pw, ph);
    v.ctx.setTransform(res, 0, 0, res, -x0 * res, -y0 * res);
    Object.assign(v, { x0, y0, w: pw / res, h: ph / res, k2: res, ready: false, geo: { ...g, k: res } });
    const step = g.step, r0 = Math.max(0, Math.floor(y0 / step) - 1), r1 = Math.min(G.rows - 1, Math.ceil((y0 + v.h) / step) + 1);
    const c0 = Math.max(0, Math.floor(x0 / step) - 1), c1 = Math.min(G.cols - 1, Math.ceil((x0 + v.w) / step) + 1), list = [];
    for (let r = r0; r <= r1; r++) for (let c = c0; c <= c1; c++) list.push(R.cells[r * G.cols + c]);
    v.rng = [r0, r1, c0, c1]; v.prog = { list, phase: 0, i: 0 };
    ovApply(); schedulePaint();
  } catch (err) { ovFail(err); }
}
function ovTail() {
  const v = R.ov || (R.ov = { need: true });
  if (v.need && !v.off) { v.need = false; ovCheck(); }
  if (!v.off && v.prog) {
    try {
      if (!paintSlice(v.ctx, v.geo, v.prog, performance.now(), R.palette, 5)) return schedulePaint();
      v.prog = null; v.ready = true; ovApply();
    } catch (err) { ovFail(err); }
  }
}
function ovDirty(list, time, pal) {
  const v = R.ov;
  if (!v || v.off || !v.ctx || !v.w || !list) return;
  try {
    const [r0, r1, c0, c1] = v.rng;
    drawCells(v.ctx, v.geo, list.filter((c) => c.row >= r0 && c.row <= r1 && c.col >= c0 && c.col <= c1), time, pal);
  } catch (err) { ovFail(err); }
}

function schedulePaint() { R.paintFrame || (R.paintFrame = requestAnimationFrame(paintMain)); }
function paintMain() {
  R.paintFrame = 0;
  const ctx = R.ctx, g = R.geo;
  if (!ctx || !g || !R.cells) return;
  const pal = R.palette || (R.palette = readPalette()), now = performance.now();
  tickAnims(R.animating, R.dirty, now, (c, bit) => c.setBit(bit, false));
  if (R.fullRepaint) {
    R.fullRepaint = false;
    if (!R.keepBitmap) ctx.clearRect(0, 0, g.width, g.height);
    R.keepBitmap = false; R.dirty.clear(); ovInvalidate();
    const visFn = visibleTester(), vis = [], rest = [];
    for (const c of R.cells) (visFn(c.row, c.col) ? vis : rest).push(c);
    R.repaintProgress = { phase: 0, i: 0, list: vis.concat(rest) };
  }
  const flush = () => ovDirty(flushDirty(ctx, g, R.dirty, R.cells, G.rows, G.cols, now, pal, R.hoverCell), now, pal);
  if (R.repaintProgress) {
    ovTail();
    if (R.dirty.size) flush();
    if (!paintSlice(ctx, g, R.repaintProgress, now, pal, 5)) return schedulePaint();
    R.repaintProgress = null;
  }
  flush(); ovTail();
  if (R.animating.size) schedulePaint();
}

function buildCells() {
  const { rows, cols } = G, n = rows * cols;
  if (R.cells?.length !== n || R.cells.cols !== cols) {
    R.cells = Array.from({ length: n }, (_, i) => new Cell(Math.floor(i / cols), i % cols, cols));
    R.cells.cols = cols;
  } else for (const c of R.cells) { c.mask = 0; c.num = 0; c.starts = null; c.spill = false; }
  R.animating.clear(); R.dirty.clear(); R.hoverCell = null;
  syncAllCells();
  R.fullRepaint = true; schedulePaint();
  dom.wrapper.style.animation = "none";
  if (n <= 1600) requestAnimationFrame(() => { dom.wrapper.style.animation = "board-in .18s var(--ease)"; });
}
function syncCell(r, c, anim = "") {
  const cell = R.cells[idxOf(r, c)];
  if (!cell) return;
  const v = G.board[r][c];
  let m = 0, num = 0;
  if (G.flagged[r][c]) m = MASK.flagged | (G.gameOver && v !== -1 ? MASK["wrong-flag"] : 0);
  else if (G.questioned[r][c]) m = MASK.questioned;
  else if (G.revealed[r][c]) { m = MASK.revealed; if (v === -1) m |= MASK["mine-show"]; else num = Math.max(0, v); }
  for (const bit of anim ? PERSIST_BITS : TRANSIENT_BITS) m |= cell.mask & MASK[bit];
  cell.setState(anim ? m | MASK[anim] : m, num);
}
function syncAllCells() { for (let r = 0; r < G.rows; r++) for (let c = 0; c < G.cols; c++) syncCell(r, c); }
function visibleTester() {
  const area = dom.area.getBoundingClientRect(), brd = dom.board.getBoundingClientRect();
  const step = (R.cellSize + (parseFloat(dom.board.style.gap) || 0)) * R.scale;
  return (r, c) => {
    const x = brd.left + c * step, y = brd.top + r * step;
    return x + step >= area.left && x <= area.right && y + step >= area.top && y <= area.bottom;
  };
}

// Wave reveal
const waveDur = (len, maxD, isEnd) =>
  isEnd ? Math.max(150, Math.ceil(len / 40) * (1e3 / 60)) : Math.min(1600, Math.max(280, 240 + 16 * maxD, 240 + 0.11 * len));
function stopWave() {
  R.waveToken++;
  const w = R.wave; R.wave = null;
  if (w) { if (w.frame) cancelAnimationFrame(w.frame); for (const c of w.cells) c.remove(w.anim); }
}
function flushWave() {
  const w = R.wave;
  if (!w) return;
  stopWave();
  while (w.index < w.items.length) { const it = w.items[w.index++]; syncCell(it.row, it.col); }
}
function afterWave(cb) { R.wave ? R.wave.onDone.push(cb) : cb(); }
function runWave(coords, ox, oy, onDone, opts = {}) {
  flushWave();
  const isEnd = !!opts.mineReveal || !!opts.flagReveal;
  if (!coords.length) return void onDone?.();
  const tok = R.waveToken;
  const items = coords.map(([r, c, d], i) => ({ row: r, col: c, depth: d ?? Math.hypot(r - ox, c - oy), angle: Math.atan2(r - ox, c - oy), order: i, visible: false }))
    .sort((a, b) => a.depth - b.depth || a.angle - b.angle || a.order - b.order);
  const len = items.length, maxD = items[len - 1].depth;
  let anim = isEnd ? (opts.flagReveal ? "anim-flag" : "anim-mine-reveal") : "anim-reveal";
  const visFn = visibleTester(); let vc = 0;
  for (const it of items) { it.visible = visFn(it.row, it.col); if (it.visible && ++vc > 450 && !isEnd) it.visible = false; }
  if (reducedMotion.matches) anim = null;
  const dur = waveDur(len, maxD, isEnd), t0 = performance.now(), minBatch = Math.max(12, Math.ceil(len / 90)), maxBatch = Math.max(minBatch, Math.ceil((len / Math.max(1, dur / (1e3 / 60))) * 1.5));
  let budget = 7, prev = t0;
  const w = { items, index: 0, cells: [], frame: null, anim, onDone: [] };
  R.wave = w;
  const finish = () => { R.wave = null; for (const c of w.cells) c.remove(w.anim); onDone?.(); for (const cb of w.onDone) cb(); };
  const step = (now) => {
    if (tok !== R.waveToken) return;
    budget = now - prev > 24 ? Math.max(3, 0.7 * budget) : Math.min(7, budget + 0.5); prev = now;
    const p = Math.min(1, Math.max(0, (now - t0) / dur));
    let lim = isEnd ? Math.min(Math.ceil(p * len), w.index + 40) : p >= 1 ? Math.min(len, w.index + maxBatch) : (() => {
      const dLim = p * maxD; let i = w.index;
      while (i < len && items[i].depth <= dLim) i++;
      return Math.min(Math.max(i, w.index === 0 ? 1 : 0), w.index + maxBatch);
    })();
    const endMs = performance.now() + budget;
    for (let cnt = 0; w.index < lim && (cnt < minBatch || performance.now() < endMs); cnt++) {
      const it = items[w.index++];
      if (anim && it.visible) { syncCell(it.row, it.col, anim); w.cells.push(cellAt(it.row, it.col)); }
      else syncCell(it.row, it.col);
    }
    if (w.index < len) w.frame = requestAnimationFrame(step);
    else {
      w.frame = null;
      if (anim) setTimeout(() => { if (tok === R.waveToken) finish(); }, isEnd ? (opts.flagReveal ? 180 : 120) : 270);
      else finish();
    }
  };
  w.frame = requestAnimationFrame(step);
}

