"use strict";
// Replay Viewer (shares Cell, tickAnims, flushDirty, calcGeo, drawCells, waveDur)
const RP = {
  on: false, rp: null, rows: 0, cols: 0, n: 0, board: "",
  cells: null, state: null, ctx: null, geo: null, dirty: new Set(), anims: new Set(), pend: [],
  shown: -1, target: 0, animNav: false, resetReplay: false, timeline: [], track: [],
  finalT: 0, playhead: 0, playing: false, wall: 0, frame: 0, pulse: null, cur: null, els: null, lbShown: -2, lbPlay: false,
  scale: 1, ox: 0, oy: 0, pan: null, pinch: null,
};
function rpApplyCell(i, v, anim) {
  const c = RP.cells[i], prev = RP.state[i];
  if (prev !== v) {
    const b = RP.board[i]; RP.state[i] = v;
    c.setBit(MASK.flagged, v === 2, RP.anims, RP.dirty, null);
    c.setBit(MASK.questioned, v === 3, RP.anims, RP.dirty, null);
    c.setBit(MASK.revealed, v === 1, RP.anims, RP.dirty, null);
    c.setBit(MASK["mine-show"], v === 1 && b === "m", RP.anims, RP.dirty, null);
    c.num = v === 1 && b >= "1" && b <= "8" ? +b : 0;
    if (!v && c.mask & MASK["wrong-flag"]) c.setBit(MASK["wrong-flag"], false, RP.anims, RP.dirty, null);
  }
  if (!anim) return;
  const bit = v === 1 ? MASK["anim-reveal"] : v === 2 ? MASK["anim-flag"] : prev === 2 ? MASK["anim-unflag"] : 0;
  c.setBit(bit, true, RP.anims, RP.dirty, null);
}
function rpVisCells() {
  const g = RP.geo;
  if (!g || !RP.els?.scroll) return null;
  const v = rpOvVisible(), st = g.step;
  return { c0: Math.floor(v.x0 / st) - 1, c1: Math.floor(v.x1 / st) + 1, r0: Math.floor(v.y0 / st) - 1, r1: Math.floor(v.y1 / st) + 1 };
}
function rpApply(step, anim) {
  if (!step.c) return;
  if (reducedMotion.matches) anim = false;
  const fail = step.a === "失败结算", win = step.a === "胜利结算", items = [];
  for (const tok of step.c.split(",")) {
    const ci = tok.indexOf(":");
    if (ci < 1) continue;
    const i = parseInt(tok.slice(0, ci), 36), v = +tok.slice(ci + 1);
    if (Number.isInteger(i) && i >= 0 && i < RP.n && v >= 0 && v <= 3) items.push({ i, v, d: 0 });
  }
  if (!items.length) return;
  const now = performance.now();
  if (anim && items.length > 1 && step.a === "翻开") {
    // 空格连锁展开：按距点击点的远近排队，逐圈播放展开动画
    const p = Number.isInteger(step.p) && step.p >= 0 ? step.p : 0, cr = (p / RP.cols) | 0, cc = p % RP.cols;
    let maxD = 0;
    for (const it of items) maxD = Math.max(maxD, (it.d = Math.hypot(((it.i / RP.cols) | 0) - cr, (it.i % RP.cols) - cc)));
    items.sort((x, y) => x.d - y.d);
    const dur = waveDur(items.length, maxD, false);
    for (const it of items) {
      const dl = maxD > 0 ? (it.d / maxD) * dur : 0;
      dl > 4 ? RP.pend.push({ i: it.i, v: it.v, at: now + dl }) : rpApplyCell(it.i, it.v, true);
    }
  } else for (const it of items) rpApplyCell(it.i, it.v, anim && !win && !fail);
  if (fail) {
    for (let i = 0; i < RP.n; i++) if (RP.state[i] === 2 && RP.board[i] !== "m") RP.cells[i].setBit(MASK["wrong-flag"], true, RP.anims, RP.dirty, null);
    const boom = Number.isInteger(step.p) && step.p >= 0 && step.p < RP.n ? step.p : -1;
    if (boom >= 0 && RP.state[boom] === 1) RP.cells[boom].setBit(MASK.exploded, true, RP.anims, RP.dirty, null);
  }
  if (anim && (step.a === "翻开" || step.a === "标记") && Number.isInteger(step.p) && step.p >= 0 && step.p < RP.n) RP.pulse = { p: step.p, t0: now };
}
function rpShowTo(idx) {
  const steps = RP.rp.steps;
  idx = clamp(idx | 0, 0, steps.length - 1);
  if (idx < RP.shown) {
    RP.state.fill(0);
    RP.cells.forEach((c) => { c.mask = 0; c.num = 0; c.starts = null; c.spill = false; RP.dirty.add(c); });
    RP.anims.clear(); RP.pend.length = 0; RP.shown = -1; RP.resetReplay = true;
  }
  const anim = RP.animNav && !RP.resetReplay;
  for (let i = RP.shown + 1; i <= idx; i++) rpApply(steps[i] || {}, anim);
  RP.resetReplay = false; RP.shown = idx;
}
const rpBisect = (arr, t, getT) => {
  let lo = 0, hi = arr.length;
  while (lo < hi) { const m = (lo + hi) >> 1; getT(arr[m]) <= t ? (lo = m + 1) : (hi = m); }
  return lo;
};
function rpCursorPos(time) {
  const tr = RP.track;
  if (!tr.length || time < tr[0][0]) return null;
  const lo = rpBisect(tr, time, (p) => p[0]), a = tr[lo - 1];
  let x = a[1], y = a[2];
  if (lo < tr.length) {
    const b = tr[lo], gap = Math.max(1, b[0] - a[0]);
    const dur = gap > 220 ? Math.min(190, Math.max(85, Math.hypot(b[1] - a[1], b[2] - a[2]) * 42)) : gap, st = b[0] - dur;
    if (time > st) { const t = clamp((time - st) / dur, 0, 1), e = t * t * (3 - 2 * t); x += (b[1] - x) * e; y += (b[2] - y) * e; }
  }
  return [x, y];
}
function rpDirtyAt(x, y) {
  const c0 = Math.floor(x), r0 = Math.floor(y);
  for (let dr = -1; dr <= 1; dr++) for (let dc = -1; dc <= 1; dc++) {
    const r = r0 + dr, c = c0 + dc;
    if (r >= 0 && r < RP.rows && c >= 0 && c < RP.cols) RP.dirty.add(RP.cells[r * RP.cols + c]);
  }
}
function rpCursorFx(now, pos, ctx = RP.ctx) {
  const g = RP.geo, sq = Math.max(1, Math.sqrt(RP.scale)), r0 = Math.max(4.5, 0.28 * g.cs) / sq, lw = 2 / sq;
  ctx.save();
  if (RP.pulse) {
    const e = (now - RP.pulse.t0) / 240, px = (RP.pulse.p % RP.cols) * g.step + g.cs / 2, py = ((RP.pulse.p / RP.cols) | 0) * g.step + g.cs / 2;
    ctx.strokeStyle = `rgba(255,255,255,${(0.55 * (1 - e)).toFixed(3)})`; ctx.lineWidth = lw;
    ctx.beginPath(); ctx.arc(px, py, r0 * (1 + 1.1 * e), 0, 2 * Math.PI); ctx.stroke();
  }
  if (pos) {
    const cx = pos[0] * g.step - g.gap / 2, cy = pos[1] * g.step - g.gap / 2;
    ctx.fillStyle = "rgba(0,0,0,.18)"; ctx.beginPath(); ctx.arc(cx, cy, r0 + 2, 0, 2 * Math.PI); ctx.fill();
    ctx.fillStyle = "#fff"; ctx.beginPath(); ctx.arc(cx, cy, r0, 0, 2 * Math.PI); ctx.fill();
    ctx.lineWidth = lw; ctx.strokeStyle = "rgba(40,35,48,.55)"; ctx.stroke();
  }
  ctx.restore();
}
function rpFrame() {
  RP.frame = 0;
  if (!RP.on) return;
  const now = performance.now();
  if (RP.playing) { RP.playhead = Math.min(RP.finalT, RP.playhead + (now - RP.wall) * (RP.speed || 1)); RP.wall = now; }
  if (RP.pend.length) {
    const keep = [];
    for (const it of RP.pend) it.at <= now ? rpApplyCell(it.i, it.v, true) : keep.push(it);
    RP.pend = keep;
  }
  tickAnims(RP.anims, RP.dirty, now, (c, bit) => c.setBit(bit, false, RP.anims, RP.dirty, null));
  if (RP.playing) {
    const idx = clamp(rpBisect(RP.timeline, RP.playhead, (t) => t) - 1, 0, RP.timeline.length - 1);
    if (idx !== RP.target) { RP.target = idx; RP.animNav = true; }
  }
  if (RP.shown !== RP.target) rpShowTo(RP.target);
  if (RP.playing && RP.playhead >= RP.finalT && !RP.pend.length && !RP.anims.size) RP.playing = false;
  const pos = rpCursorPos(RP.playhead);
  if (!pos !== !RP.cur || (pos && RP.cur && (pos[0] !== RP.cur[0] || pos[1] !== RP.cur[1]))) {
    if (RP.cur) rpDirtyAt(RP.cur[0], RP.cur[1]);
    if (pos) rpDirtyAt(pos[0], pos[1]);
  }
  RP.cur = pos;
  if (RP.pulse) {
    const p = RP.pulse;
    (now - p.t0) / 240 >= 1 ? (RP.pulse = null) : rpDirtyAt((p.p % RP.cols) + 0.5, ((p.p / RP.cols) | 0) + 0.5);
  }
  const painted = RP.dirty.size > 0;
  const pal = R.palette || (R.palette = readPalette());
  let src = RP.dirty;
  if (src.size > 400) {
    src = new Set();
    const vc = rpVisCells();
    if (vc) for (const c of RP.dirty) if (c.col >= vc.c0 && c.col <= vc.c1 && c.row >= vc.r0 && c.row <= vc.r1) { RP.dirty.delete(c); src.add(c); if (src.size >= 400) break; }
    if (src.size < 400) for (const c of RP.dirty) { RP.dirty.delete(c); src.add(c); if (src.size >= 400) break; }
  }
  const dl = flushDirty(RP.ctx, RP.geo, src, RP.cells, RP.rows, RP.cols, now, pal, null);
  if (painted) rpCursorFx(now, pos);
  const ov = RP.ov;
  if (ov?.ready && dl) {
    const st = RP.geo.step, sub = dl.filter((c) => (c.col + 1) * st > ov.x0 && c.col * st < ov.x1 && (c.row + 1) * st > ov.y0 && c.row * st < ov.y1);
    if (sub.length) { drawCells(ov.ctx, RP.geo, sub, now, pal, null); if (painted) rpCursorFx(now, pos, ov.ctx); }
  }
  if (RP.shown !== RP.lbShown || RP.playing !== RP.lbPlay) {
    const e = RP.els, st = RP.rp.steps[RP.shown] || {}, max = RP.rp.steps.length - 1;
    RP.lbShown = RP.shown; RP.lbPlay = RP.playing;
    e.step.textContent = `${RP.shown} / ${max} 步 · ${st.a || "操作"}`;
    e.range.value = String(RP.shown);
    e.range.style.setProperty("--range-fill", `${max > 0 ? (RP.shown / max) * 100 : 0}%`);
    e.prev.disabled = RP.shown <= 0; e.next.disabled = RP.shown >= max;
    e.playTx.textContent = RP.playing ? "暂停" : "播放";
    e.playIc.setAttribute("d", RP.playing ? "M6 19h4V5H6v14zm8-14v14h4V5h-4z" : "M8 5v14l11-7z");
    e.time.textContent = fmtMs(RP.playing ? RP.playhead : RP.timeline[RP.shown] || 0);
    let fl = 0; for (let k = 0; k < RP.n; k++) if (RP.state[k] === 2) fl++;
    e.flags.textContent = String(fl); e.mines.textContent = String(RP.mineTotal - fl);
  }
  if (RP.playing) RP.els.time.textContent = fmtMs(RP.playhead);
  if (RP.playing || RP.anims.size || RP.pend.length || RP.pulse || RP.dirty.size) RP.frame = requestAnimationFrame(rpFrame);
}
const rpSchedule = () => { RP.frame || (RP.frame = requestAnimationFrame(rpFrame)); };
const rpSeek = (idx, anim) => { RP.playing = false; idx = clamp(idx | 0, 0, RP.rp.steps.length - 1); RP.playhead = RP.timeline[idx] || 0; RP.target = idx; RP.animNav = !!anim; rpSchedule(); };
function rpToggle(force) {
  const go = typeof force === "boolean" ? force : !RP.playing;
  if (!go) { RP.playing = false; return rpSchedule(); }
  if (RP.shown >= RP.rp.steps.length - 1) { RP.playhead = RP.timeline[0] || 0; RP.target = 0; RP.animNav = false; }
  RP.playing = true; RP.wall = performance.now(); rpSchedule();
}
const rpCssZoom = () => {
  const sc = RP.els?.scroll;
  return sc && sc.offsetWidth ? sc.getBoundingClientRect().width / sc.offsetWidth : 1;
};
function rpCenter() {
  const r = RP.els.scroll.getBoundingClientRect(), z = rpCssZoom();
  return { x: r.left + r.width / 2 + RP.ox * z, y: r.top + r.height / 2 + RP.oy * z, z };
}
function rpApplyTransform() {
  const sc = RP.els?.scroll, g = RP.geo;
  if (!sc || !g) return;
  const aw = sc.clientWidth, ah = sc.clientHeight, sw = g.width * RP.scale, sh = g.height * RP.scale;
  const mx = Math.max(0, (aw + sw) / 2 - Math.min(64, sw / 2, aw / 2));
  const my = Math.max(0, (ah + sh) / 2 - Math.min(64, sh / 2, ah / 2));
  RP.ox = clamp(RP.ox, -mx, mx); RP.oy = clamp(RP.oy, -my, my);
  RP.els.wrap.style.transform = `translate3d(${RP.ox}px,${RP.oy}px,0) scale(${RP.scale})`;
  rpOvApply(); rpOvSchedule();
  if (RP.els.reset) RP.els.reset.disabled = Math.abs(RP.scale - 1) <= 0.03 && Math.hypot(RP.ox, RP.oy) <= 4;
}
let rpOvT = 0;
const rpOvWant = () => Math.min(IS_MOBILE ? 6 : 12, (window.devicePixelRatio || 1) * RP.scale);
function rpOvVisible() {
  const g = RP.geo, sc = RP.els.scroll, k = RP.scale;
  const cx = g.width / 2 - RP.ox / k, cy = g.height / 2 - RP.oy / k, hw = sc.clientWidth / 2 / k, hh = sc.clientHeight / 2 / k;
  return { x0: Math.max(0, cx - hw), x1: Math.min(g.width, cx + hw), y0: Math.max(0, cy - hh), y1: Math.min(g.height, cy + hh) };
}
const rpOvCovers = (v, r, e = 0.5) => r.x0 >= v.x0 - e && r.x1 <= v.x1 + e && r.y0 >= v.y0 - e && r.y1 <= v.y1 + e;
function rpOvApply() {
  const v = RP.ov, g = RP.geo;
  if (!v || !v.canvas || !g || !RP.els) return;
  const show = !!(v.ready && rpOvWant() > 1.05 * g.k && v.res > 1.05 * g.k && rpOvCovers(v, rpOvVisible()));
  if (show === !!v.on) return;
  v.on = show; v.canvas.style.visibility = show ? "visible" : "hidden"; RP.els.canvas.style.visibility = show ? "hidden" : "visible";
}
function rpOvSchedule() { clearTimeout(rpOvT); rpOvT = setTimeout(rpOvCheck, 140); }
function rpOvCheck() {
  const g = RP.geo; if (!RP.on || !g || !RP.els) return;
  const v = RP.ov || (RP.ov = { on: false, ready: false }), want = rpOvWant();
  if (want <= 1.05 * g.k) { if (v.canvas && v.ready) { v.ready = false; v.canvas.width = v.canvas.height = 1; } return rpOvApply(); }
  const vis = rpOvVisible();
  if (v.ready && rpOvCovers(v, vis, 0) && Math.abs(want / v.res - 1) < 0.15) return rpOvApply();
  const vw = vis.x1 - vis.x0, vh = vis.y1 - vis.y0, margin = 0.2;
  if (vw <= 0 || vh <= 0) return;
  const res = Math.min(want, Math.sqrt(OV_MAX_PIXELS / (vw * vh * (1 + 2 * margin) ** 2)));
  if (res <= 1.05 * g.k || (vw / g.step) * (vh / g.step) * (1 + 2 * margin) ** 2 > 2500) { v.ready = false; return rpOvApply(); }
  const x0 = Math.max(0, Math.floor((vis.x0 - margin * vw) * res)) / res, y0 = Math.max(0, Math.floor((vis.y0 - margin * vh) * res)) / res;
  const pw = Math.max(1, Math.ceil((Math.min(g.width, vis.x1 + margin * vw) - x0) * res - 1e-6));
  const ph = Math.max(1, Math.ceil((Math.min(g.height, vis.y1 + margin * vh) - y0) * res - 1e-6));
  try {
    if (!v.canvas) {
      v.canvas = document.createElement("canvas");
      v.canvas.style.cssText = "position:absolute;pointer-events:none;visibility:hidden";
      RP.els.wrap.appendChild(v.canvas); v.ctx = v.canvas.getContext("2d");
    }
    if (v.canvas.width !== pw || v.canvas.height !== ph) { v.canvas.width = pw; v.canvas.height = ph; }
    const cv = RP.els.canvas;
    Object.assign(v.canvas.style, { left: cv.offsetLeft + x0 + "px", top: cv.offsetTop + y0 + "px", width: pw / res + "px", height: ph / res + "px" });
    const ctx = v.ctx; ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.clearRect(0, 0, pw, ph); ctx.setTransform(res, 0, 0, res, -x0 * res, -y0 * res);
    const c0 = Math.floor(x0 / g.step), c1 = Math.min(RP.cols - 1, Math.floor((x0 + pw / res) / g.step)), r0 = Math.floor(y0 / g.step), r1 = Math.min(RP.rows - 1, Math.floor((y0 + ph / res) / g.step)), list = [];
    for (let r = r0; r <= r1; r++) for (let c = c0; c <= c1; c++) list.push(RP.cells[r * RP.cols + c]);
    drawCells(ctx, g, list, performance.now(), R.palette || (R.palette = readPalette()), null);
    Object.assign(v, { x0, y0, x1: x0 + pw / res, y1: y0 + ph / res, res, ready: true });
    rpOvApply();
  } catch (err) { v.ready = false; console.warn("replay hi-res overlay failed", err); }
}
function rpResetView() { RP.scale = 1; RP.ox = 0; RP.oy = 0; rpApplyTransform(); }
function rpLayout(keepView = false) {
  if (!RP.on || !RP.els?.scroll.isConnected) return;
  const sc = RP.els.scroll, gap = clamp(parseFloat(getComputedStyle(document.documentElement).getPropertyValue("--board-gap")) || 2, 0, 8);
  const pd = (el, a, b) => (parseFloat(getComputedStyle(el)[a]) || 0) + (parseFloat(getComputedStyle(el)[b]) || 0);
  const aw = Math.max(120, sc.clientWidth - pd(sc, "paddingLeft", "paddingRight") - pd(RP.els.wrap, "paddingLeft", "paddingRight") - 2);
  const ah = Math.max(120, sc.clientHeight - pd(sc, "paddingTop", "paddingBottom") - pd(RP.els.wrap, "paddingTop", "paddingBottom") - 2);
  const cs = clamp(Math.floor(Math.min((aw - (RP.cols - 1) * gap) / RP.cols, (ah - (RP.rows - 1) * gap) / RP.rows)), 8, 36);
  const g = calcGeo(RP.rows, RP.cols, cs, gap, (window.devicePixelRatio || 1), MAX_PIXELS), cv = RP.els.canvas;
  cv.width = g.pw; cv.height = g.ph; cv.style.width = g.width + "px"; cv.style.height = g.height + "px";
  if (RP.ov) { const o = RP.ov; o.ready = false; o.on = false; if (o.canvas) { o.canvas.width = o.canvas.height = 1; o.canvas.style.visibility = "hidden"; } cv.style.visibility = "visible"; }
  RP.ctx = cv.getContext("2d"); RP.ctx.setTransform(g.pw / g.width, 0, 0, g.ph / g.height, 0, 0); RP.geo = g;
  RP.cells.forEach((c) => RP.dirty.add(c));
  keepView ? rpApplyTransform() : rpResetView();
  rpSchedule();
}
function rpBindGestures(sc) {
  const endPan = () => { RP.pan = null; sc.classList.remove("grabbing"); };
  sc.addEventListener("mousedown", (e) => {
    if (e.button !== 0) return;
    RP.pan = { x: e.clientX, y: e.clientY, ox: RP.ox, oy: RP.oy };
    sc.classList.add("grabbing");
  });
  sc.addEventListener("mousemove", (e) => {
    if (!RP.pan) return;
    if (!(e.buttons & 1)) return endPan();
    const z = rpCssZoom();
    RP.ox = RP.pan.ox + (e.clientX - RP.pan.x) / z; RP.oy = RP.pan.oy + (e.clientY - RP.pan.y) / z;
    rpApplyTransform();
  });
  sc.addEventListener("mouseup", endPan);
  sc.addEventListener("mouseleave", endPan);
  sc.addEventListener("dblclick", rpResetView);
  sc.addEventListener("wheel", (e) => {
    e.preventDefault();
    const ns = clamp(RP.scale * (e.deltaY < 0 ? 1.14 : 0.88), 0.5, 5);
    if (ns === RP.scale) return;
    const ctr = rpCenter(), k = (1 - ns / RP.scale) / ctr.z;
    RP.ox += (e.clientX - ctr.x) * k; RP.oy += (e.clientY - ctr.y) * k;
    RP.scale = ns; rpApplyTransform(); 
  }, { passive: false });
  sc.addEventListener("touchstart", (e) => {
    if (e.touches.length === 2) {
      const [a, b] = e.touches;
      RP.pinch = { d: Math.max(1, Math.hypot(b.clientX - a.clientX, b.clientY - a.clientY)), s: RP.scale, cx: (a.clientX + b.clientX) / 2, cy: (a.clientY + b.clientY) / 2 };
      RP.pan = null; e.stopPropagation(); e.preventDefault();
    } else if (e.touches.length === 1) {
      const t = e.touches[0];
      if (t.clientX > 22) e.stopPropagation();
      RP.pan = { x: t.clientX, y: t.clientY, ox: RP.ox, oy: RP.oy };
    }
  }, { passive: false });
  sc.addEventListener("touchmove", (e) => {
    if (RP.pinch && e.touches.length >= 2) {
      const [a, b] = e.touches, cx = (a.clientX + b.clientX) / 2, cy = (a.clientY + b.clientY) / 2;
      const ns = clamp((RP.pinch.s * Math.hypot(b.clientX - a.clientX, b.clientY - a.clientY)) / RP.pinch.d, 0.5, 5);
      const ctr = rpCenter(), k = (1 - ns / RP.scale) / ctr.z;
      RP.ox += (RP.pinch.cx - ctr.x) * k + (cx - RP.pinch.cx) / ctr.z;
      RP.oy += (RP.pinch.cy - ctr.y) * k + (cy - RP.pinch.cy) / ctr.z;
      RP.scale = ns; RP.pinch.cx = cx; RP.pinch.cy = cy;
      rpApplyTransform(); e.stopPropagation(); e.preventDefault();
    } else if (RP.pan && e.touches.length === 1) {
      const t = e.touches[0], z = rpCssZoom();
      RP.ox = RP.pan.ox + (t.clientX - RP.pan.x) / z; RP.oy = RP.pan.oy + (t.clientY - RP.pan.y) / z;
      rpApplyTransform(); e.stopPropagation();
    }
  }, { passive: false });
  sc.addEventListener("touchend", (e) => { if (RP.pinch && e.touches.length < 2) RP.pinch = null; if (!e.touches.length) RP.pan = null; }, { passive: true });
  sc.addEventListener("touchcancel", () => { RP.pinch = null; RP.pan = null; }, { passive: true });
}
function rpOpen(entry) {
  const rp = entry?.rp;
  if (!rp || rp.v !== 1 || !Number.isInteger(entry.r) || !Number.isInteger(entry.c) || entry.r < 1 || entry.r > 100 || entry.c < 1 || entry.c > 100 ||
    typeof rp.b !== "string" || rp.b.length !== entry.r * entry.c || !/^[0-8m]+$/.test(rp.b) || !Array.isArray(rp.steps) || !rp.steps.length || rp.steps.length > 3e3)
    return showToast("这条战绩没有可用的回放数据", 1800);
  rpClose();
  const rows = entry.r, cols = entry.c, tl = []; let prev = -1;
  for (const st of rp.steps) {
    let t = Number(st?.t);
    if (!Number.isFinite(t) || t < 0) t = prev < 0 ? 0 : prev + 180;
    tl.push(prev >= 0 && t <= prev ? prev + 90 : t); prev = tl[tl.length - 1];
  }
  const track = [];
  if (Array.isArray(rp.track)) for (const p of rp.track) {
    if (!Array.isArray(p) || p.length < 3) continue;
    const [t, x, y] = p.map(Number);
    if (Number.isFinite(t) && Number.isFinite(x) && Number.isFinite(y))
      track.push([Math.max(track.length ? track[track.length - 1][0] + 1 : 0, Math.max(0, t)), clamp(Math.floor(x), 0, cols - 1) + 0.5, clamp(Math.floor(y), 0, rows - 1) + 0.5]);
  }
  if (!track.length) rp.steps.forEach((st, i) => {
    let cell = Number.isInteger(st?.p) ? st.p : -1;
    if (cell < 0 || cell >= rows * cols) { const first = (st?.c || "").split(",")[0]; if (first) cell = parseInt(first.split(":")[0], 36); }
    if (Number.isInteger(cell) && cell >= 0 && cell < rows * cols) track.push([tl[i], (cell % cols) + 0.5, ((cell / cols) | 0) + 0.5]);
  });
  Object.assign(RP, {
    on: true, rp, rows, cols, n: rows * cols, board: rp.b,
    cells: Array.from({ length: rows * cols }, (_, i) => new Cell((i / cols) | 0, i % cols, cols)),
    state: new Uint8Array(rows * cols), shown: -1, target: 0, animNav: false, resetReplay: false,
    timeline: tl, finalT: tl[tl.length - 1] || 0, track, playhead: 0, playing: false, pulse: null, cur: null, lbShown: -2, lbPlay: false,
    scale: 1, ox: 0, oy: 0, pan: null, pinch: null, speed: 1, ov: null,
  });
  MineHome.pg = "replay"; $("sub-title").textContent = "对局回放";
  const body = $("sub-body");
  body.innerHTML = `<div class="rp-panel"><div id="rp-bar"><button class="btn icon-btn" id="rp-back" title="返回"><svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M20 11H7.83l5.59-5.59L12 4l-8 8 8 8 1.41-1.41L7.83 13H20v-2z"/></svg></button><div id="rp-stats"><div class="stat-item" title="剩余雷数"><div class="stat-row"><svg width="13" height="13" viewBox="0 0 24 24" style="color:var(--boom)" aria-hidden="true"><use href="#ic-mine"/></svg><span class="stat-value" id="rp-mines">0</span></div><div class="stat-label">雷</div></div><div class="stat-item stat-item-timer" title="用时"><div class="stat-row"><svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/></svg><span class="stat-value" id="rp-time-label">${fmtMs(0)}</span></div><div class="stat-label">用时</div></div><div class="stat-item" title="已插旗"><div class="stat-row"><svg width="12" height="12" viewBox="0 0 24 24" fill="#f59e0b" aria-hidden="true"><path d="M5 21V4h9l.4 2H20v10h-7l-.4-2H7v7H5z"/></svg><span class="stat-value" id="rp-flags">0</span></div><div class="stat-label">旗</div></div></div><button class="btn icon-btn" id="rp-reset" title="重置视角"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M15 3h6v6M9 21H3v-6M21 3l-7 7M3 21l7-7"/></svg></button></div><div class="rp-board-scroll"><div id="rp-wrap"><canvas id="rp-canvas" role="img" aria-label="对局回放棋盘"></canvas></div></div><div class="rp-dock"><div class="rp-step"><span id="rp-step-label">准备回放</span></div><input class="range-input rp-range" id="rp-range" type="range" min="0" max="${rp.steps.length - 1}" value="0" aria-label="回放进度"><div class="rp-controls"><button class="btn icon-btn" id="rp-prev" title="上一步"><svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M6 6h2v12H6zm3.5 6 8.5 6V6z"/></svg></button><button class="btn btn-primary" id="rp-play"><svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path id="rp-play-ic" d="M8 5v14l11-7z"/></svg><span id="rp-play-tx">播放</span></button><button class="btn icon-btn" id="rp-next" title="下一步"><svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="m6 18 8.5-6L6 6v12zM16 6v12h2V6h-2z"/></svg></button><button class="btn" id="rp-speed" title="播放速度">1×</button></div></div></div>`;
  $("sub").classList.add("rp-mode");
  const q = (id) => body.querySelector("#" + id);
  RP.els = { canvas: q("rp-canvas"), wrap: q("rp-wrap"), reset: q("rp-reset"), scroll: body.querySelector(".rp-board-scroll"), step: q("rp-step-label"), time: q("rp-time-label"), mines: q("rp-mines"), flags: q("rp-flags"), back: q("rp-back"), range: q("rp-range"), prev: q("rp-prev"), next: q("rp-next"), play: q("rp-play"), playTx: q("rp-play-tx"), playIc: q("rp-play-ic") };
  RP.els.speed = body.querySelector("#rp-speed");
  RP.els.speed.addEventListener("click", () => { const sp = [1, 2, 4, 0.5]; RP.speed = sp[(sp.indexOf(RP.speed) + 1) % sp.length]; RP.els.speed.textContent = RP.speed + "×"; });
  RP.els.back.addEventListener("click", () => $("sub-back").click());
  RP.mineTotal = rp.b.split("m").length - 1;
  RP.els.prev.addEventListener("click", () => rpSeek(RP.shown - 1, true));
  RP.els.next.addEventListener("click", () => rpSeek(RP.shown + 1, true));
  RP.els.play.addEventListener("click", () => rpToggle());
  RP.els.range.addEventListener("input", (ev) => rpSeek(Number(ev.target.value), false));
  RP.els.reset.addEventListener("click", rpResetView);
  rpBindGestures(RP.els.scroll);
  rpLayout();
}
function rpClose() {
  clearTimeout(rpOvT);
  $("sub").classList.remove("rp-mode");
  if (RP.frame) { cancelAnimationFrame(RP.frame); RP.frame = 0; }
  
  Object.assign(RP, { ov: null, on: false, rp: null, cells: null, state: null, playing: false, pulse: null, cur: null, els: null, lbShown: -2, lbPlay: false, pan: null, pinch: null });
  RP.dirty.clear(); RP.anims.clear(); RP.pend.length = 0;
}
let rpRz = 0;
addEventListener("resize", () => { if (RP.on) { clearTimeout(rpRz); rpRz = setTimeout(() => rpLayout(true), 120); } });

