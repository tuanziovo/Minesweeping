"use strict";
// Meta, Achievements, Campaign, Daily, Stats
const meta = Object.assign({ played: 0, wins: 0, ng: 0, clean: 0, best: {}, bestNg: {}, mp: { t: [0, 0], n: [0, 0] }, hist: [], daily: {}, camp: 0, ach: {} }, parseJson(store.get(META_KEY)));
for (const k of ["played", "wins", "ng", "clean", "camp"]) if (!Number.isFinite(meta[k])) meta[k] = 0;
for (const k of ["best", "bestNg", "daily", "ach"]) if (!isObj(meta[k])) meta[k] = {};
if (!isObj(meta.mp)) meta.mp = {};
for (const k of ["t", "n"]) if (!Array.isArray(meta.mp[k]) || meta.mp[k].length !== 2 || !meta.mp[k].every(Number.isFinite)) meta.mp[k] = [0, 0];
meta.hist = (Array.isArray(meta.hist) ? meta.hist : []).filter((e) => isObj(e) && Number.isFinite(e.t)).slice(0, 200);
delete meta.lessons;
meta.camp = clamp(Math.floor(meta.camp), 0, 8);
for (const k of ["best", "bestNg", "daily"]) for (const j in meta[k]) if (!Number.isFinite(meta[k][j])) delete meta[k][j];
const saveMeta = () => {
  if (store.set(META_KEY, JSON.stringify(meta))) return true;
  for (let i = meta.hist.length - 1; i >= 0; i--) {
    if (!meta.hist[i].rp) continue;
    delete meta.hist[i].rp;
    if (store.set(META_KEY, JSON.stringify(meta))) return true;
  }
  return false;
};
const todayStr = () => { const d = new Date(); return `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}`; };
const maxDailyStreak = () => {
  let best = 0, cur = 0;
  Object.keys(meta.daily).sort().map((d) => Date.parse(d) / 864e5).forEach((v, i, a) => { cur = i && v - a[i - 1] === 1 ? cur + 1 : 1; best = Math.max(best, cur); });
  return best;
};
const CAMPAIGN = [[8, 8, 8, 0], [9, 9, 12, 0], [12, 12, 22, 0], [14, 14, 34, 1], [16, 16, 45, 0], [16, 20, 58, 1], [16, 30, 85, 0], [20, 30, 115, 1]];
const ACHS = [
  ["首胜", "赢得第一局", (m) => m.wins >= 1],
  ["十胜", "累计获胜 10 局", (m) => m.wins >= 10, (m) => m.wins, 10],
  ["五十局", "累计对局 50 局", (m) => m.played >= 50, (m) => m.played, 50],
  ["快手", "简单难度 30 秒内通关", (m) => Math.min(m.best.easy ?? 1e9, m.bestNg.easy ?? 1e9) <= 3e4],
  ["困难通关", "通关一次困难难度", (m) => m.best.hard != null || m.bestNg.hard != null],
  ["无猜通关", "赢得一局无猜模式", (m) => m.ng >= 1],
  ["不求助", "不用撤销和提示通关中等", (m) => m.clean >= 1],
  ["连续三天", "每日挑战连续完成 3 天", () => maxDailyStreak() >= 3, maxDailyStreak, 3],
  ["战役过半", "通过战役前 4 关", (m) => m.camp >= 4, (m) => m.camp, 4],
  ["战役通关", "通过战役全部 8 关", (m) => m.camp >= 8, (m) => m.camp, 8],
];

// Home & Subpages
const MineHome = (window.MineHome = {
  open: true, modes: [], el: $("home"), run: null,
  canContinue: () => !G.firstClick && !G.gameOver && !G.placing,
  register(m) { this.modes.push(m); this.render(); },
  render() {
    const box = $("home-modes"); box.textContent = "";
    this.modes.forEach((m) => {
      const b = document.createElement("button");
      b.className = "mode-card";
      b.innerHTML = `<span class="mc-icon"><svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="${m.icon}"/></svg></span><span class="mc-text"><b></b></span>`;
      b.querySelector("b").textContent = m.title;
      b.addEventListener("click", () => { if (!this.busy) { this.busy = true; setTimeout(() => { this.busy = false; this.launch(m); }, 140); } });
      box.appendChild(b);
    });
    this.sync();
  },
  sync() {
    if (this.run && G.difficulty !== this.run.key) { this.run = null; R.rngSeed = null; }
    $("home-continue").hidden = !this.open || !this.canContinue() || G.difficulty !== this.diff0;
    $("btn-home-settings").style.display = this.open ? "none" : "flex";
    const cfg = DIFFS[G.difficulty];
    $("home-hint").textContent = G.difficulty === "screen" ? "按屏幕尺寸自适应" : cfg ? `${cfg.rows}×${cfg.cols} · ${cfg.mines} 雷` : "";
  },
  show() {
    recordSettlementIfNeeded();
    if (this.open) return;
    this.open = true; R.homePaused = !!G.timer && !G.gameOver; if (R.homePaused) stopTimer();
    dom.settings.classList.remove("show"); closeModal(); this.diff0 = G.difficulty; clearTimer("modal");
    this.render(); this.el.classList.add("show");
  },
  close() {
    this.open = false; this.el.classList.remove("show"); this.sync();
    if (R.homePaused) { R.homePaused = false; if (!G.timer && !G.gameOver && !G.firstClick && !G.placing) startTimer(); }
  },
  launch(m) {
    if (m.action) return m.action();
    this.endRun();
    if (m.mode) setSetting("mode", m.mode);
    R.homePaused = false; R.snap = null; this.close(); newGame();
  },
  endRun() {
    recordSettlementIfNeeded();
    if (G.difficulty === "camp" || G.difficulty === "daily") { setSetting("difficulty", this.base || "medium", false); setSetting("mode", this.baseMode || "traditional", false); }
    this.run = null; R.rngSeed = null;
  },
  begin(run, cfg, mode) {
    recordSettlementIfNeeded();
    if (G.difficulty !== "camp" && G.difficulty !== "daily") { this.base = G.difficulty; this.baseMode = G.mode; }
    DIFFS[run.key] = cfg; G.difficulty = run.key; setSetting("mode", mode);
    this.run = run; R.rngSeed = run.seed ?? null; R.snap = null; R.homePaused = false;
    $("sub").classList.remove("show"); this.close(); newGame();
  },
  daily() {
    const date = todayStr(), seed = [...date].reduce((h, ch) => Math.imul(h ^ ch.charCodeAt(0), 16777619) >>> 0, 2166136261);
    this.begin({ key: "daily", date, seed }, { rows: 16, cols: 16, mines: 40 }, "traditional");
    const best = meta.daily[date];
    showToast(best ? `今日最佳 ${(best / 1e3).toFixed(1)} 秒` : "今日棋盘", 2200);
  },
  level(lv) {
    const [r, c, m, ng] = CAMPAIGN[lv];
    this.begin({ key: "camp", level: lv }, { rows: r, cols: c, mines: m }, ng ? "noguess" : "traditional");
    showToast(`第 ${lv + 1} 关`, 1500);
  },
  onEnd(win) {
    this.lastNew = false;
    if (this.countedGame !== G.gameId) {
      this.countedGame = G.gameId; meta.played++;
      const m = G.mode === "noguess" && !G.noguessFallback ? "n" : "t", mp = meta.mp[m];
      mp[0]++; if (win && !G.cheated && !G.noguessFallback) mp[1]++;
      this.countedEntry = {
        t: Date.now(), d: G.difficulty, m, w: win ? 1 : 0, ms: Math.round(G.timeMs || 1e3 * G.time || 0),
        r: G.rows, c: G.cols, n: G.mines, x: G.cheated ? 1 : 0, f: G.noguessFallback ? 1 : 0,
        rp: G.replay ? { v: 1, b: G.replay.b, track: G.replay.track, steps: G.replay.steps } : null,
      };
      meta.hist.unshift(this.countedEntry);
      if (meta.hist.length > 200) meta.hist.length = 200;
      let kept = 0; for (const it of meta.hist) if (it.rp && ++kept > 20) delete it.rp;
    } else if (win && this.countedEntry && !this.countedEntry.w && meta.hist.includes(this.countedEntry)) {
      const e = this.countedEntry;
      e.w = 1; e.x = 1; e.ms = Math.round(G.timeMs || 1e3 * G.time || 0);
      if (G.replay) e.rp = { v: 1, b: G.replay.b, track: G.replay.track, steps: G.replay.steps };
      let kept = 0; for (const it of meta.hist) if (it.rp && ++kept > 20) delete it.rp;
    }
    if (win && !G.cheated) {
      const ms = G.timeMs || 1e3 * G.time, d = G.difficulty;
      if (!G.noguessFallback) meta.wins++;
      if (G.mode === "noguess" && !G.noguessFallback) meta.ng++;
      if (["easy", "medium", "hard"].includes(d) && !G.noguessFallback) {
        const bs = G.mode === "noguess" ? meta.bestNg : meta.best;
        this.lastNew = ms < (bs[d] ?? 1e9); bs[d] = Math.min(bs[d] ?? 1e9, ms);
      }
      if (d === "medium" && !G.undoUsed && !G.hintsUsed) meta.clean++;
      const run = this.run;
      if (run && run.key === d && !(G.noguessFallback && d === "daily")) {
        if (d === "daily") meta.daily[run.date] = Math.min(meta.daily[run.date] ?? 1e9, ms);
        else if (run.level === meta.camp && (CAMPAIGN[run.level][3] ? G.mode === "noguess" && !G.noguessFallback : G.mode === "traditional")) {
          meta.camp++;
          showToast(run.level < CAMPAIGN.length - 1 ? `第 ${run.level + 1} 关通过，下一关已解锁` : "战役已全部通过", 2200);
        }
      }
    }
    const unlocked = ACHS.filter((a) => !meta.ach[a[0]] && a[2](meta));
    unlocked.forEach((a) => (meta.ach[a[0]] = Date.now()));
    saveMeta();
    if (unlocked.length) { playFeedback("unlock"); showToast("解锁成就：" + unlocked.map((a) => a[0]).join("、"), 2600); }
  },
  page(pg) {
    $("sub").classList.remove("rp-mode");
    if (this.pg === "replay") rpClose();
    if (pg === "stats") { this.sv = "stat"; this.hf = "all"; }
    this.pg = pg;
    $("sub-title").textContent = { ach: "成就", camp: "战役闯关", theme: "主题", stats: "战绩" }[pg];
    this.paint(); $("sub").classList.add("show");
  },
  paintStats() {
    const dn = { easy: "简单", medium: "中等", hard: "困难", custom: "自定义", screen: "适应屏幕", daily: "每日挑战", camp: "战役" }, mn = { t: "传统", n: "无猜" };
    const view = this.sv || "stat", flt = this.hf || "all";
    let h = segHtml([["stat", "统计"], ["hist", "历史"]], view, "sv");
    if (view === "stat") {
      const card = (t, [p, w], bs) => `<div class="st-card"><h4>${t}</h4><div class="st-sub">${p} 局 · 赢 ${w} 局 · 胜率 ${p ? Math.round((100 * w) / p) : 0}%</div><div class="st-best">${["easy", "medium", "hard"].map((k) => `<div><small>${dn[k]}最佳</small><b>${bs[k] != null ? fmtMs(bs[k]) : "—"}</b></div>`).join("")}</div></div>`;
      h += card("传统模式", meta.mp.t, meta.best) + card("无猜模式", meta.mp.n, meta.bestNg);
    } else {
      const list = meta.hist.map((e, i) => [e, i]).filter(([e]) => flt === "all" || e.m === flt).slice(0, 100);
      h += segHtml([["all", "全部"], ["t", "传统"], ["n", "无猜"]], flt, "hf");
      h += list.length ? list.map(([e, i]) => {
        const d = new Date(e.t), sz = e.d === "custom" ? ` ${e.r}×${e.c}` : "", tag = (e.x ? " · 辅助" : "") + (e.f ? " · 回退" : "");
        return `<div class="hs-row"><div class="hs-badge${e.w ? "" : " lose"}">${e.w ? "胜" : "负"}</div><div class="hs-tx"><span>${dn[e.d] || e.d}${sz} · ${mn[e.m] || ""}</span><small>${d.getMonth() + 1}/${d.getDate()} ${pad2(d.getHours())}:${pad2(d.getMinutes())}${tag}</small></div><div class="hs-time">${fmtMs(e.ms)}</div>${e.rp ? `<button class="btn icon-btn hs-play" data-rp="${i}" title="观看回放"><svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M8 5v14l11-7z"/></svg></button>` : ""}</div>`;
      }).join("") : '<p class="sub-sum">还没有记录</p>';
      if (meta.hist.length) h += '<button class="btn" data-clr>清空历史</button>';
    }
    const body = $("sub-body"); body.innerHTML = h;
    body.querySelectorAll("[data-sv]").forEach((el) => el.addEventListener("click", () => { this.sv = el.dataset.sv; this.paintStats(); }));
    body.querySelectorAll("[data-hf]").forEach((el) => el.addEventListener("click", () => { this.hf = el.dataset.hf; this.paintStats(); }));
    body.querySelectorAll("[data-rp]").forEach((el) => el.addEventListener("click", () => rpOpen(meta.hist[Number(el.dataset.rp)])));
    body.querySelector("[data-clr]")?.addEventListener("click", (ev) => {
      const b = ev.currentTarget;
      if (b.dataset.arm) { meta.hist = []; saveMeta(); return this.paintStats(); }
      b.dataset.arm = "1"; b.textContent = "再点一次确认清空";
      setTimeout(() => { if (b.isConnected) { delete b.dataset.arm; b.textContent = "清空历史"; } }, 2500);
    });
  },
  openReplay: rpOpen,
  exitReplay() { rpClose(); this.pg = "stats"; this.sv = "hist"; $("sub-title").textContent = "战绩"; this.paintStats(); },
  paint() {
    const body = $("sub-body");
    if (this.pg === "stats") return this.paintStats();
    if (this.pg === "theme") return renderThemePage(body);
    if (this.pg === "ach") {
      const unlocked = ACHS.filter((a) => meta.ach[a[0]]).length;
      body.innerHTML = `<p class="sub-sum">已解锁 ${unlocked} / ${ACHS.length}，共 ${meta.played} 局，赢 ${meta.wins} 局</p>` + ACHS.map((a) => {
        const ok = !!meta.ach[a[0]], cur = a[3] ? a[3](meta) : 0;
        const bar = !ok && a[3] ? `<div class="bar"><i style="width:${Math.min(100, (100 * cur) / a[4])}%"></i></div><small>${Math.min(cur, a[4])}/${a[4]}</small>` : "";
        const ic = ok ? '<use href="#ic-cup"/>' : '<path d="M18 8h-1V6c0-2.76-2.24-5-5-5S7 3.24 7 6v2H6c-1.1 0-2 .9-2 2v10c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V10c0-1.1-.9-2-2-2zm-6 9c-1.1 0-2-.9-2-2s.9-2 2-2 2 .9 2 2-.9 2-2 2zm3.1-9H8.9V6c0-1.71 1.39-3.1 3.1-3.1 1.71 0 3.1 1.39 3.1 3.1v2z"/>';
        return `<div class="ach${ok ? "" : " off"}"><div class="ach-ic"><svg width="22" height="22" viewBox="0 0 24 24" fill="currentColor">${ic}</svg></div><div class="ach-tx"><b>${a[0]}</b><small>${a[1]}</small>${bar}</div></div>`;
      }).join("");
    } else if (this.pg === "camp") {
      body.innerHTML = `<p class="sub-sum">已通过 ${meta.camp} / ${CAMPAIGN.length} 关，用了提示的对局不计入</p><div class="lv-grid">` +
        CAMPAIGN.map((lv, i) => `<button class="lv${i < meta.camp ? " done" : i === meta.camp ? " cur" : ""}" data-lv="${i}"${i > meta.camp ? " disabled" : ""}>${i + 1}<small>${lv[0]}×${lv[1]}${lv[3] ? " 无猜" : ""}</small></button>`).join("") + "</div>";
      body.querySelectorAll("[data-lv]").forEach((b) => b.addEventListener("click", () => this.level(+b.dataset.lv)));
    }
  },
});

document.addEventListener("pointerdown", (e) => {
  const btn = e.target.closest?.("#home button:not(:disabled), #sub button:not(:disabled)");
  if (btn) SFX[btn.closest(".seg") ? "select" : "tap"]?.();
}, { passive: true });
[
  { id: "classic", icon: "M3 3h8v8H3V3zm10 0h8v8h-8V3zM3 13h8v8H3v-8zm10 0h8v8h-8v-8z", title: "经典模式", mode: "traditional" },
  { id: "noguess", icon: "M9 21c0 .55.45 1 1 1h4c.55 0 1-.45 1-1v-1H9v1zm3-19C8.14 2 5 5.14 5 9c0 2.38 1.19 4.47 3 5.74V17c0 .55.45 1 1 1h6c.55 0 1-.45 1-1v-2.26c1.81-1.27 3-3.36 3-5.74 0-3.86-3.14-7-7-7z", title: "无猜模式", mode: "noguess" },
  { id: "custom", icon: "M20 2H4c-1.1 0-2 .9-2 2v16c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zM8 20H4v-4h4v4zm0-6H4v-4h4v4zm0-6H4V4h4v4zm6 12h-4v-4h4v4zm0-6h-4v-4h4v4zm0-6h-4V4h4v4zm6 12h-4v-4h4v4zm0-6h-4v-4h4v4zm0-6h-4V4h4v4z", title: "自定义棋盘", action: () => { setSetting("difficulty", "custom"); MineHome.sync(); openSettings(); } },
  { id: "daily", icon: "M19 3h-1V1h-2v2H8V1H6v2H5c-1.11 0-1.99.9-1.99 2L3 19c0 1.1.89 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm0 16H5V8h14v11z", title: "每日挑战", action: () => MineHome.daily() },
  { id: "campaign", icon: "M14.4 6 14 4H5v17h2v-7h5.6l.4 2h7V6z", title: "战役闯关", action: () => MineHome.page("camp") },
].forEach((m) => MineHome.register(m));

$("home-continue").hidden = true;
$("home-continue").addEventListener("click", () => MineHome.close());
$("home-settings").addEventListener("click", openSettings);
$("home-ach").addEventListener("click", () => MineHome.page("ach"));
$("home-stats").addEventListener("click", () => MineHome.page("stats"));
$("sub-back").addEventListener("click", () => (MineHome.pg === "replay" ? MineHome.exitReplay() : $("sub").classList.remove("show")));
$("home-theme").addEventListener("click", () => MineHome.page("theme"));
$("open-theme").addEventListener("click", () => { closeSettings(true); MineHome.page("theme"); });
$("btn-home-settings").addEventListener("click", () => { closeSettings(true); MineHome.show(); });
$("btn-home-modal").addEventListener("click", () => MineHome.show());
$("home").querySelectorAll("[data-set=difficulty]").forEach((b) => b.addEventListener("click", () => { setSetting("difficulty", b.dataset.val); MineHome.sync(); }));

// Theme Engine
const PRESETS = [["default", "经典紫", null], ["ocean", "海洋蓝", "#1E88E5"], ["forest", "森林绿", "#2E7D32"], ["sakura", "樱花粉", "#D81B60"], ["sunset", "日落橙", "#EF6C00"], ["mint", "薄荷青", "#00897B"], ["indigo", "靛蓝", "#3949AB"], ["coffee", "咖啡棕", "#6D4C41"], ["ruby", "宝石红", "#C62828"], ["slate", "石墨灰", "#607D8B"], ["lime", "青柠", "#689F38"], ["sky", "天空", "#039BE5"]];
const NUM_PALS = {
  cb: [["#0072B2", "#007A5A", "#D55E00", "#8E3B8E", "#B07A00", "#00829B", "#333333", "#6B6B6B"], ["#56B4E9", "#4CD1A0", "#FF9A57", "#E0A3D0", "#F0C24B", "#6FD6E8", "#E0E0E0", "#B0B0B0"]],
  hc: [["#0000FF", "#007000", "#E00000", "#800080", "#800000", "#007070", "#000000", "#404040"], ["#8AB4FF", "#66FF66", "#FF8080", "#E080FF", "#FFB366", "#66FFFF", "#FFFFFF", "#C0C0C0"]],
};
const AMOLED_CSS = "body.dark{--bg:#000;--sfdim:#000;--s0:#000;--s1:#0c0c0c;--s2:#111;--s3:#171717;--s4:#1e1e1e;--sfbri:#2a2a2a}";
const themeState = Object.assign({ preset: "default", custom: null, amoled: false, nums: "classic" }, parseJson(store.get(THEME_KEY)));
if (typeof themeState.preset !== "string") themeState.preset = "default";
if (!/^#[0-9a-fA-F]{6}$/.test(themeState.custom)) themeState.custom = null;
themeState.amoled = !!themeState.amoled;
if (!["classic", "cb", "hc"].includes(themeState.nums)) themeState.nums = "classic";
const themeStyleEl = document.head.appendChild(document.createElement("style"));
const saveTheme = () => store.set(THEME_KEY, JSON.stringify(themeState));
const hexToHs = (hex) => {
  const [r, g, b] = [1, 3, 5].map((i) => parseInt(hex.slice(i, i + 2), 16) / 255);
  const max = Math.max(r, g, b), d = max - Math.min(r, g, b), l = (max + Math.min(r, g, b)) / 2;
  const h = d === 0 ? 0 : max === r ? ((g - b) / d) % 6 : max === g ? (b - r) / d + 2 : (r - g) / d + 4;
  return [Math.round((60 * h + 360) % 360), d ? (d / (1 - Math.abs(2 * l - 1))) * 100 : 0];
};
const hslToRgb = (h, s, l) => {
  l /= 100; const a = (s / 100) * Math.min(l, 1 - l);
  return [0, 8, 4].map((n) => { const k = (n + h / 30) % 12; return 255 * (l - a * Math.max(-1, Math.min(k - 3, 9 - k, 1))); });
};
const hslToHex = (h, s, l) => "#" + hslToRgb(h, s, l).map((v) => Math.round(v).toString(16).padStart(2, "0")).join("");
const contrastRatio = (a, b) => {
  const lum = (rgb) => rgb.map((v) => ((v /= 255) <= 0.03928 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4)).reduce((s, v, i) => s + v * [0.2126, 0.7152, 0.0722][i], 0);
  const [hi, lo] = [lum(a), lum(b)].sort((x, y) => y - x);
  return (hi + 0.05) / (lo + 0.05);
};
function buildThemeTokens(hex, dark) {
  const [h, rawS] = hexToHs(hex), s = clamp(rawS, 25, 85), bgS = clamp(rawS / 2, 6, 33), pS = dark ? Math.min(s + 15, 90) : s;
  const targetRgb = dark ? hslToRgb(h, 60, 20) : [255, 255, 255];
  let pL = dark ? 82 : 40;
  while (contrastRatio(hslToRgb(h, pS, pL), targetRgb) < 4.5 && pL > 18 && pL < 94) pL += dark ? 1 : -1;
  const rows = dark
    ? [["p", pS, pL], ["onp", 60, 20], ["pc", 40, 35], ["pfv", 40, 35], ["sc", 15, 29], ["onsc", 40, 91], ["bg", bgS / 2, 8], ["onbg", 15, 90], ["sfdim", bgS / 2, 8], ["sfbri", 6, 23], ["onv", 10, 80], ["s0", bgS / 2, 6], ["s1", bgS / 3, 12], ["s2", bgS / 3, 14], ["s3", bgS / 3, 17], ["s4", bgS / 3, 22], ["out", 6, 58], ["outv", 8, 29]]
    : [["p", pS, pL], ["pc", Math.min(s, 80), 90], ["pfv", s, Math.min(30, pL - 8)], ["sc", bgS + 2, 90], ["onsc", 30, 12], ["bg", bgS, 93], ["onbg", 15, 19], ["sfdim", bgS, 85], ["sfbri", bgS + 5, 95], ["onv", 12, 35], ["s0", bgS + 8, 97], ["s1", bgS, 91], ["s2", bgS, 89], ["s3", bgS, 86], ["s4", bgS, 82], ["out", 6, 47], ["outv", 10, 80]];
  const out = {};
  rows.forEach(([k, ss, ll]) => (out[k] = `hsl(${h} ${Math.round(ss)}% ${ll}%)`));
  out.tc = dark ? `hsl(${h + 50} 25% 29%)` : `hsl(${h + 50} 60% 91%)`;
  if (!dark) out.onp = "#fff";
  out.accentHover = dark ? `hsl(${h} ${Math.round(pS)}% ${Math.max(pL - 8, 18)}%)` : `hsl(${h} ${Math.round(s)}% ${Math.min(30, pL - 8)}%)`;
  return out;
}
const activeHex = () => themeState.custom || PRESETS.find((p) => p[0] === themeState.preset)?.[2] || null;
const themeRule = (sel, tk) => `${sel}{${Object.entries(tk).filter(([k]) => k !== "accentHover").map(([k, v]) => `--${k}:${v}`).join(";")};--accent-hover:${tk.accentHover}}`;
function applyThemeCss(refresh = true) {
  const hex = activeHex();
  let css = hex ? themeRule(":root", buildThemeTokens(hex, false)) + themeRule("body.dark", buildThemeTokens(hex, true)) : "";
  if (themeState.amoled) css += AMOLED_CSS;
  const np = NUM_PALS[themeState.nums];
  if (np) {
    const vars = (arr) => arr.map((v, i) => `--n${i + 1}:${v}`).join(";");
    css += `:root{${vars(np[0])}}body.dark{${vars(np[1])}}`;
  }
  themeStyleEl.textContent = css;
  if (refresh) { invalidatePalette(); syncThemeMeta(); }
}
function renderThemePage(body) {
  const mode = R.darkManual ? (document.body.classList.contains("dark") ? "dark" : "light") : "auto";
  const demo = [["1", "2", "F"], ["?", "3", "?"], ["?", "?", "?"]];
  const flagSvg = '<svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M14.4 6 14 4H5v17h2v-7h5.6l.4 2h7V6z"/></svg>';
  const preview = `<div class="dg" style="grid-template-columns:repeat(3,34px)">${demo.flat().map((v) => v === "?" ? '<span class="c u"></span>' : v === "F" ? `<span class="c" style="color:var(--flag)">${flagSvg}</span>` : `<span class="c" style="color:var(--n${v})">${v}</span>`).join("")}</div>`;
  body.innerHTML = `<div class="th-preview">${preview}</div>
    <div class="th-label">外观</div>${segHtml([["auto", "跟随系统"], ["light", "浅色"], ["dark", "深色"]], mode, "mode")}
    <div class="th-label">配色预设</div><div class="th-grid">${PRESETS.map((p) => {
      const tk = buildThemeTokens(p[2] || "#6750A4", document.body.classList.contains("dark"));
      return `<button class="th-card${themeState.custom || themeState.preset !== p[0] ? "" : " active"}" data-preset="${p[0]}" style="--sw1:${tk.bg};--sw2:${tk.p}"><i class="th-sw"></i>${p[1]}</button>`;
    }).join("")}</div>
    <div class="th-label">自定义主色</div><div class="th-row"><input type="color" id="th-color" value="${activeHex() || "#6750A4"}"><button class="btn" id="th-rand">随机一个</button><span class="th-hint" id="th-hint">${themeState.custom ? `自定义 ${themeState.custom.toUpperCase()}` : "选个颜色，整套界面会跟着变"}</span></div>
    <div class="th-label">深色模式</div><div class="toggle-row"><label for="th-amoled">纯黑背景（OLED 更省电）</label><label class="toggle-switch"><input type="checkbox" id="th-amoled"${themeState.amoled ? " checked" : ""}><span class="toggle-track"></span></label></div>
    <div class="th-label">数字配色</div>${segHtml([["classic", "经典"], ["cb", "色盲友好"], ["hc", "高对比"]], themeState.nums, "nums")}
    <button class="btn" id="th-reset" style="margin-top:20px;width:100%">恢复默认主题</button>`;
  const patch = (p) => { Object.assign(themeState, p); applyThemeCss(); saveTheme(); renderThemePage(body); };
  body.querySelectorAll("[data-mode]").forEach((b) => b.addEventListener("click", () => {
    const m = b.dataset.mode; R.darkManual = m !== "auto";
    setDark(m === "auto" ? matchMedia("(prefers-color-scheme: dark)").matches : m === "dark");
    scheduleSave(); renderThemePage(body);
  }));
  body.querySelectorAll("[data-preset]").forEach((b) => b.addEventListener("click", () => {
    patch({ preset: b.dataset.preset, custom: null });
    showToast(`已切换为「${PRESETS.find((p) => p[0] === b.dataset.preset)[1]}」`, 1200);
  }));
  body.querySelectorAll("[data-nums]").forEach((b) => b.addEventListener("click", () => patch({ nums: b.dataset.nums })));
  body.querySelector("#th-amoled").addEventListener("change", (e) => patch({ amoled: e.target.checked }));
  body.querySelector("#th-rand").addEventListener("click", () => patch({ custom: hslToHex(Math.floor(360 * Math.random()), 55 + 30 * Math.random(), 45) }));
  body.querySelector("#th-reset").addEventListener("click", () => patch({ preset: "default", custom: null, amoled: false, nums: "classic" }));
  const col = body.querySelector("#th-color");
  col.addEventListener("input", () => {
    themeState.custom = col.value; applyThemeCss(); saveTheme();
    body.querySelector("#th-hint").textContent = `自定义 ${col.value.toUpperCase()}`;
    body.querySelectorAll(".th-card.active").forEach((c) => c.classList.remove("active"));
  });
  col.addEventListener("change", () => renderThemePage(body));
}

// Back navigation, edge-swipe back, focus & inert management, fullscreen
(() => {
  const homeEl = $("home"), subEl = $("sub"), setEl = dom.settings, modEl = dom.modal;
  const isOpen = (el) => !!el && el.classList.contains("show");
  const backDlg = document.createElement("div");
  backDlg.className = "overlay"; backDlg.id = "back-confirm"; backDlg.style.zIndex = "120";
  backDlg.innerHTML = '<div style="background:var(--s3,var(--bg));color:var(--fg);border-radius:24px;padding:24px;width:min(320px,86vw);box-shadow:0 8px 32px #0005;display:flex;flex-direction:column;gap:16px"><div style="font-size:18px;font-weight:600">返回主页吗？</div><div style="font-size:14px;opacity:.75">当前对局会保留。</div><div style="display:flex;gap:10px;justify-content:flex-end"><button class="btn" id="back-no">否</button><button class="btn btn-primary" id="back-yes">是</button></div></div>';
  document.body.appendChild(backDlg);
  $("back-no").addEventListener("click", () => backDlg.classList.remove("show"));
  $("back-yes").addEventListener("click", () => { backDlg.classList.remove("show"); MineHome.show(); });

  const overlays = [homeEl, subEl, setEl, modEl, backDlg];
  const bgEls = ["top-bar", "warning-bar", "game-area"].map($);
  const depth = () => (isOpen(homeEl) ? 0 : 1) + isOpen(subEl) + isOpen(setEl) + isOpen(modEl) + isOpen(backDlg);
  const stepBack = () =>
    isOpen(backDlg) ? (backDlg.classList.remove("show"), true)
    : isOpen(subEl) ? ($("sub-back").click(), true)
    : isOpen(setEl) ? ($("btn-close-settings").click(), true)
    : isOpen(modEl) ? ($("btn-close-modal").click(), true)
    : !isOpen(homeEl) && (MineHome.canContinue() ? (backDlg.classList.add("show"), "ask") : (MineHome.show(), true));

  let histD = 0, ignorePop = false, queued = false;
  try { history.replaceState({ mineDepth: 0 }, ""); } catch {}
  const syncHist = () => {
    queued = false;
    if (ignorePop || top !== self) return;
    const d = depth();
    try {
      if (d > histD) { for (let i = histD + 1; i <= d; i++) history.pushState({ mineDepth: i }, ""); histD = d; }
      else if (d < histD) { ignorePop = true; const delta = histD - d; histD = d; history.go(-delta); }
    } catch { ignorePop = false; }
  };
  const queueHist = () => { if (!queued) { queued = true; queueMicrotask(syncHist); } };
  addEventListener("keydown", (e) => { if (e.key === "Escape" && isOpen(backDlg)) { e.stopImmediatePropagation(); backDlg.classList.remove("show"); } }, true);
    const capApp = window.Capacitor?.Plugins?.App;
    if (capApp?.addListener) {
      capApp.addListener("backButton", () => {
        if (!stepBack()) capApp.exitApp?.();
      });
    }
  addEventListener("popstate", (e) => {
    if (ignorePop) { ignorePop = false; histD = Math.min(histD, e.state?.mineDepth ?? 0); return queueHist(); }
    const target = e.state?.mineDepth ?? 0;
    for (let i = 0; i < 8 && depth() > target; i++) { const r = stepBack(); if (!r || r === "ask") break; }
    const cur = depth();
    try {
      if (cur > target) for (let i = target + 1; i <= cur; i++) history.pushState({ mineDepth: i }, "");
      else history.replaceState({ mineDepth: cur }, "");
    } catch {}
    histD = cur; queueHist();
  });

  // Edge swipe back
  let sw = null;
  const endSwipe = (animate) => {
    if (!sw) return;
    const p = sw.panel;
    if (p) {
      p.style.transition = animate ? "transform .2s ease, opacity .2s ease" : "";
      p.style.transform = p.style.opacity = "";
      if (animate) setTimeout(() => { p.style.transition = ""; }, 220);
    }
    sw = null;
  };
  addEventListener("touchstart", (e) => {
    if (e.touches.length !== 1 || isOpen(backDlg) || depth() === (isOpen(homeEl) ? 0 : 1)) return;
    const t = e.touches[0];
    if (t.clientX > 22) return;
    const panel = isOpen(subEl) ? subEl.querySelector(".sub-panel") : isOpen(setEl) ? setEl.firstElementChild : isOpen(modEl) ? modEl.querySelector(".modal-content") : null;
    if (panel) sw = { x: t.clientX, y: t.clientY, dx: 0, panel, active: false, t0: Date.now() };
  }, { passive: true });
  addEventListener("touchmove", (e) => {
    if (!sw) return;
    const t = e.touches[0], dx = t.clientX - sw.x, dy = t.clientY - sw.y;
    if (!sw.active) { if (Math.abs(dy) > Math.abs(dx) && Math.abs(dy) > 10) { sw = null; return; } if (dx <= 8) return; sw.active = true; }
    sw.dx = Math.max(0, dx);
    sw.panel.style.transition = "none";
    sw.panel.style.transform = `translateX(${0.6 * sw.dx}px) scale(${1 - Math.min(sw.dx, 300) / 3e3})`;
    sw.panel.style.opacity = String(1 - Math.min(sw.dx, 300) / 700);
    if (e.cancelable) e.preventDefault();
  }, { passive: false });
  addEventListener("touchend", () => {
    if (!sw) return;
    const fast = sw.dx / Math.max(1, Date.now() - sw.t0) > 0.6, trigger = sw.active && (sw.dx > 90 || (fast && sw.dx > 40));
    endSwipe(!trigger);
    if (trigger) try { history.back(); } catch { stepBack(); }
  }, { passive: true });
  addEventListener("touchcancel", () => endSwipe(true), { passive: true });

  // Accessibility: aria-label from title, inert background, focus restore
  const labelBtns = () => document.querySelectorAll("button[title]:not([aria-label])").forEach((b) => b.setAttribute("aria-label", b.title));
  const lastFocus = new WeakMap(), wasShown = new WeakMap();
  const syncOverlay = (el) => {
    const on = isOpen(el);
    if (on === !!wasShown.get(el)) return;
    wasShown.set(el, on);
    if (on) {
      lastFocus.set(el, document.activeElement);
      setTimeout(() => {
        if (!isOpen(el) || el.contains(document.activeElement)) return;
        const target = el === backDlg ? $("back-yes") : [...el.querySelectorAll("button,[href],input,select,[tabindex]")].find((x) => !x.disabled && !x.hidden && x.tabIndex >= 0 && x.offsetParent !== null);
        target?.focus({ preventScroll: true });
      }, el === backDlg ? 60 : 80);
    } else {
      const prev = lastFocus.get(el); lastFocus.delete(el);
      if (prev?.isConnected && !overlays.some(isOpen)) setTimeout(() => prev.focus({ preventScroll: true }), 0);
    }
  };
  const syncInert = () => { const any = overlays.some(isOpen); bgEls.forEach((el) => { if (el) el.inert = any; }); overlays.forEach(syncOverlay); };
  labelBtns(); syncInert();
  const labelObs = new MutationObserver(labelBtns), classObs = new MutationObserver(() => { queueHist(); syncInert(); });
  overlays.forEach((el) => { labelObs.observe(el, { childList: true, subtree: true }); classObs.observe(el, { attributes: true, attributeFilter: ["class"] }); });
})();

// Fullscreen toggle (setting + Shift+F)
(() => {
  const doc = document, root = doc.documentElement, req = root.requestFullscreen || root.webkitRequestFullscreen, ex = doc.exitFullscreen || doc.webkitExitFullscreen;
  const inp = $("toggle-fullscreen");
  if (!inp) return;
  if (!req || !ex || window.Capacitor?.isNativePlatform?.()) { const row = inp.closest(".toggle-row"); if (row) row.hidden = true; return; }
  const isFs = () => !!(doc.fullscreenElement || doc.webkitFullscreenElement);
  const sync = () => { const on = isFs(); inp.checked = on; inp.setAttribute("aria-checked", String(on)); inp.setAttribute("aria-label", on ? "退出全屏" : "进入全屏"); };
  const toggle = () => { try { const r = isFs() ? ex.call(doc) : req.call(root); if (r?.then) r.then(sync, sync); } catch { sync(); } };
  inp.addEventListener("change", toggle);
  doc.addEventListener("fullscreenchange", sync); doc.addEventListener("webkitfullscreenchange", sync);
  addEventListener("keydown", (e) => {
    if (!e.shiftKey || e.ctrlKey || e.metaKey || e.altKey || e.key.toLowerCase() !== "f") return;
    if (e.target && /^(INPUT|TEXTAREA|SELECT)$/.test(e.target.tagName)) return;
    e.preventDefault(); e.stopImmediatePropagation(); toggle();
  }, true);
  sync();
})();

// Init
applyThemeCss(false);
loadSettings();
bindEvents();
newGame();
MineHome.diff0 = G.difficulty;
MineHome.render();
syncThemeMeta();
