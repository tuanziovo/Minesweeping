"use strict";
// 原生桥接层：在 Capacitor APK 内使用原生能力，在浏览器里自动降级，不影响网页预览。
const Native = (window.Native = (() => {
  const cap = window.Capacitor;
  const isNative = !!cap?.isNativePlatform?.();
  // 没有打包器时，Capacitor.Plugins.X 不会自动出现，必须显式 registerPlugin（原生端按名字绑定）。
  const cache = {};
  const plug = (name) => {
    if (!isNative) return undefined;
    if (name in cache) return cache[name];
    try { cache[name] = cap.Plugins?.[name] || cap.registerPlugin?.(name); } catch { cache[name] = undefined; }
    return cache[name];
  };
  const P = new Proxy({}, { get: (_, name) => plug(String(name)) });
  const ext = () => window.Ext?.cfg || {};

  // ---- 震动：用原生 Haptics，比 navigator.vibrate 细腻且不依赖权限 ----
  const IMPACT = { reveal: "LIGHT", flag: "MEDIUM", unflag: "LIGHT", undo: "LIGHT", hint: "LIGHT", deny: "HEAVY" };
  const NOTIFY = { win: "SUCCESS", explode: "ERROR", unlock: "SUCCESS" };
  const SCALE = { light: 0.6, normal: 1, strong: 1.6 };
  function haptic(name, opts) {
    const lv = ext().haptic || "normal";
    if (lv === "off") return true; // 已处理（静默）
    const H = P.Haptics;
    if (!isNative || !H) return false; // 交给 navigator.vibrate
    try {
      if (NOTIFY[name]) H.notification({ type: NOTIFY[name] });
      else if (name === "reveal" && opts?.count > 1) H.vibrate({ duration: Math.round(30 * SCALE[lv]) });
      else if (IMPACT[name]) {
        let style = IMPACT[name];
        if (lv === "light" && style !== "LIGHT") style = style === "HEAVY" ? "MEDIUM" : "LIGHT";
        if (lv === "strong" && style !== "HEAVY") style = style === "LIGHT" ? "MEDIUM" : "HEAVY";
        H.impact({ style });
      } else H.impact({ style: "LIGHT" });
    } catch {}
    return true;
  }

  // ---- 状态栏：跟随主题色 / 深浅色 ----
  function syncStatusBar() {
    const S = P.StatusBar;
    if (!isNative || !S) return;
    const color = document.querySelector('meta[name="theme-color"]')?.content || "#F2E7F0";
    const dark = document.body.classList.contains("dark");
    try {
      S.setStyle({ style: dark ? "DARK" : "LIGHT" });
      S.setBackgroundColor({ color });
    } catch {}
  }

  // ---- 屏幕常亮：优先 Wake Lock API ----
  let lock = null;
  async function wake(on) {
    try {
      if (!on) { await lock?.release(); lock = null; return; }
      if (lock || !navigator.wakeLock || document.hidden) return;
      lock = await navigator.wakeLock.request("screen");
      lock.addEventListener("release", () => { lock = null; });
    } catch { lock = null; }
  }

  // ---- 分享 / 复制 ----
  async function share(text, title = "扫雷") {
    try {
      if (P.Share && isNative) { await P.Share.share({ title, text, dialogTitle: "分享战绩" }); return "share"; }
      if (navigator.share) { await navigator.share({ title, text }); return "share"; }
    } catch (e) { if (e?.name === "AbortError") return "cancel"; }
    return (await copy(text)) ? "copy" : "fail";
  }
  async function copy(text) {
    try { if (P.Clipboard && isNative) { await P.Clipboard.write({ string: text }); return true; } } catch {}
    try { await navigator.clipboard.writeText(text); return true; } catch {}
    try {
      const ta = Object.assign(document.createElement("textarea"), { value: text });
      ta.style.cssText = "position:fixed;opacity:0"; document.body.appendChild(ta); ta.select();
      const ok = document.execCommand("copy"); ta.remove(); return ok;
    } catch { return false; }
  }

  function init() {
    // 主题色变化 -> 状态栏
    const meta = document.querySelector('meta[name="theme-color"]');
    if (meta) new MutationObserver(syncStatusBar).observe(meta, { attributes: true, attributeFilter: ["content"] });
    new MutationObserver(syncStatusBar).observe(document.body, { attributes: true, attributeFilter: ["class"] });
    syncStatusBar();
    // 启动屏：首帧绘制后再收起，避免白屏闪烁
    requestAnimationFrame(() => setTimeout(() => { try { P.SplashScreen?.hide?.({ fadeOutDuration: 200 }); } catch {} }, 60));
    // 常亮：回到前台重新申请
    // 常亮只在对局计时进行时保持，回到主页/结算后释放，省电
    let held = false;
    const sync = () => { const want = ext().keepAwake !== false && (typeof G !== "undefined" && !!G.timer) && !document.hidden; if (want !== held) { held = want; wake(want); } };
    setInterval(sync, 1000);
    document.addEventListener("visibilitychange", () => { if (document.hidden) { held = false; wake(false); } else sync(); });
  }

  return { isNative, haptic, share, copy, wake, init, syncStatusBar };
})());
