"use strict";
// 增强功能：独立设置、旗帜模式按钮、断点续玩、分享战绩、数据导出/导入
const EXT_KEY = "minesweeper_ext", RESUME_KEY = "minesweeper_resume";

const Ext = (window.Ext = {
  cfg: Object.assign({ haptic: "normal", keepAwake: true, autoResume: true }, parseJson(store.get(EXT_KEY))),
  save() { store.set(EXT_KEY, JSON.stringify(this.cfg)); },
});
if (!["off", "light", "normal", "strong"].includes(Ext.cfg.haptic)) Ext.cfg.haptic = "normal";
Ext.cfg.keepAwake = Ext.cfg.keepAwake !== false;
Ext.cfg.autoResume = Ext.cfg.autoResume !== false;

const DIFF_NAME = { easy: "简单", medium: "中等", hard: "困难", custom: "自定义", screen: "适应屏幕", daily: "每日挑战", camp: "战役" };

// ---------- 1. 旗帜模式按钮（触屏常用：切换后点按即插旗） ----------
(function flagModeButton() {
  const bar = $("top-bar-actions"), undo = $("btn-undo-topbar");
  if (!bar) return;
  const b = document.createElement("button");
  b.className = "btn icon-btn"; b.id = "btn-flagmode"; b.title = "旗帜模式"; b.setAttribute("aria-pressed", "false");
  b.innerHTML = '<svg width="15" height="15" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M5 21V4h9l.4 2H20v10h-7l-.4-2H7v7H5z"/></svg>';
  b.addEventListener("click", () => {
    R.flagMode = !R.flagMode;
    b.classList.toggle("on", R.flagMode); b.setAttribute("aria-pressed", String(R.flagMode));
    showToast(R.flagMode ? "旗帜模式：点按插旗" : "已切回翻开模式", 1000);
    playFeedback(R.flagMode ? "flag" : "unflag");
  });
  bar.insertBefore(b, undo || bar.firstChild);
})();

// ---------- 2. 设置面板「增强」分区 ----------
(function settingsSection() {
  const anchor = $("btn-reset-settings")?.closest(".settings-section");
  if (!anchor) return;
  const sec = document.createElement("section");
  sec.className = "settings-section"; sec.id = "ext-section";
  const tg = (id, label) => `<div class="toggle-row"><label for="${id}">${label}</label><label class="toggle-switch"><input type="checkbox" id="${id}"><span class="toggle-track"></span></label></div>`;
  sec.innerHTML =
    '<div class="settings-label">增强</div>' +
    '<div class="data-tip" style="padding:0 18px 6px">震动强度</div>' +
    '<div class="settings-buttons segmented" id="ext-haptic">' +
    [["off", "关"], ["light", "轻"], ["normal", "标准"], ["strong", "强"]].map(([v, t]) => `<button class="btn" data-hv="${v}">${t}</button>`).join("") +
    "</div>" +
    '<div class="setting-list">' + tg("toggle-awake", "游戏时保持屏幕常亮") + tg("toggle-resume", "自动保存并恢复未完成的对局") + "</div>" +
    '<div class="settings-label">数据</div>' +
    '<div style="display:flex;gap:8px;padding:0 16px 14px"><button class="btn" id="btn-export" style="flex:1;justify-content:center">导出备份</button><button class="btn" id="btn-import" style="flex:1;justify-content:center">导入备份</button></div>';
  anchor.parentNode.insertBefore(sec, anchor);

  const syncHaptic = () => sec.querySelectorAll("[data-hv]").forEach((x) => x.classList.toggle("active", x.dataset.hv === Ext.cfg.haptic));
  syncHaptic();
  sec.querySelectorAll("[data-hv]").forEach((x) => x.addEventListener("click", () => {
    Ext.cfg.haptic = x.dataset.hv; Ext.save(); syncHaptic();
    const was = G.soundEnabled; G.soundEnabled = true; playFeedback("flag"); G.soundEnabled = was; // 试震一下
  }));
  const awake = $("toggle-awake"), res = $("toggle-resume");
  awake.checked = Ext.cfg.keepAwake; res.checked = Ext.cfg.autoResume;
  awake.addEventListener("change", () => { Ext.cfg.keepAwake = awake.checked; Ext.save(); Native.wake(awake.checked); });
  res.addEventListener("change", () => { Ext.cfg.autoResume = res.checked; Ext.save(); if (!res.checked) store.remove(RESUME_KEY); });
  $("btn-export").addEventListener("click", () => openDataDialog("export"));
  $("btn-import").addEventListener("click", () => openDataDialog("import"));
})();

// ---------- 3. 断点续玩 ----------
const Resume = {
  kinds: ["easy", "medium", "hard", "custom", "screen"],
  sig: "",
  snapshot() {
    if (G.firstClick || G.gameOver || G.placing || !this.kinds.includes(G.difficulty)) return null;
    const elapsed = G.timer ? performance.now() - G.timerStart : G.timeMs;
    return {
      v: 1, d: G.difficulty, mode: G.mode, rows: G.rows, cols: G.cols, mines: G.mines,
      board: G.board, revealed: G.revealed, flagged: G.flagged, questioned: G.questioned, ms: Math.round(elapsed),
      hintsUsed: G.hintsUsed, undoUsed: G.undoUsed, cheated: G.cheated, fallback: G.noguessFallback, bv3: G.bv3, uc: G.usefulClicks, t: Date.now(),
    };
  },
  write(force) {
    if (!Ext.cfg.autoResume || Ext.importing) return;
    const sig = `${G.gameId}:${G.revealedCount}:${G.flagCount}:${G.gameOver}:${G.firstClick}`;
    if (!force && sig === this.sig) return;
    this.sig = sig;
    const s = this.snapshot();
    if (s) store.set(RESUME_KEY, JSON.stringify(s)); else store.remove(RESUME_KEY);
  },
  valid(s) {
    if (!isObj(s) || s.v !== 1 || !this.kinds.includes(s.d) || !["traditional", "noguess"].includes(s.mode)) return false;
    const { rows, cols, mines } = s;
    if (![rows, cols, mines].every(Number.isInteger) || rows < 2 || cols < 2 || rows > 100 || cols > 100 || mines < 1 || mines >= rows * cols) return false;
    const ok = (g, f) => Array.isArray(g) && g.length === rows && g.every((r) => Array.isArray(r) && r.length === cols && r.every(f));
    return ok(s.board, (v) => Number.isInteger(v) && v >= -1 && v <= 8) && ok(s.revealed, (v) => typeof v === "boolean") &&
      ok(s.flagged, (v) => typeof v === "boolean") && ok(s.questioned, (v) => typeof v === "boolean") && Number.isFinite(s.ms) && s.ms >= 0;
  },
  restore() {
    if (!Ext.cfg.autoResume) return false;
    const s = parseJson(store.get(RESUME_KEY));
    if (!this.valid(s)) { store.remove(RESUME_KEY); return false; }
    // 必须至少翻开一格，且棋盘上真的有 mines 个雷
    let mineN = 0, rev = 0, flg = 0;
    for (let r = 0; r < s.rows; r++) for (let c = 0; c < s.cols; c++) { if (s.board[r][c] === -1) mineN++; if (s.revealed[r][c]) rev++; if (s.flagged[r][c]) flg++; }
    if (mineN !== s.mines || !rev || rev >= s.rows * s.cols - s.mines) { store.remove(RESUME_KEY); return false; }
    setSetting("difficulty", s.d, false); setSetting("mode", s.mode, false);
    newGame();
    Object.assign(G, {
      rows: s.rows, cols: s.cols, mines: s.mines, board: s.board, revealed: s.revealed, flagged: s.flagged, questioned: s.questioned,
      revealedCount: rev, flagCount: flg, nonMineCount: s.rows * s.cols - s.mines, firstClick: false, placing: false, gameOver: false,
      hintsUsed: s.hintsUsed | 0, undoUsed: !!s.undoUsed, cheated: !!s.cheated, noguessFallback: !!s.fallback, bv3: s.bv3 | 0, usefulClicks: s.uc | 0,
    });
    setElapsed(s.ms);
    layoutBoard(); buildCells(); updateCounters(); syncUndoButtons();
    MineHome.diff0 = G.difficulty; R.homePaused = true; MineHome.sync();
    return true;
  },
};
window.Resume = Resume;

if (Resume.restore()) showToast("已恢复上次未完成的对局", 2200);
Resume.write(true);
setInterval(() => Resume.write(false), 1500);
document.addEventListener("visibilitychange", () => { if (document.hidden) Resume.write(true); });
addEventListener("pagehide", () => Resume.write(true));

// ---------- 4. 结算弹窗：分享战绩 ----------
(function shareButton() {
  const box = document.querySelector("#modal .modal-actions-section"), modal = $("modal");
  if (!box) return;
  const b = document.createElement("button");
  b.className = "btn"; b.id = "btn-share"; b.hidden = true; b.textContent = "分享战绩";
  box.insertBefore(b, $("btn-home-modal"));
  new MutationObserver(() => { if (modal.classList.contains("show")) b.hidden = !G.settlement?.win; }).observe(modal, { attributes: true, attributeFilter: ["class"] });
  b.addEventListener("click", async () => {
    const t = G.timeMs || G.time * 1e3, sec = Math.max(0.001, t / 1e3);
    const size = G.difficulty === "custom" || G.difficulty === "screen" ? `${G.rows}×${G.cols}/${G.mines}雷` : DIFF_NAME[G.difficulty] || "";
    const text = `💣 我在扫雷「${size}${G.mode === "noguess" ? "·无猜" : ""}」用时 ${fmtMs(t)} 通关！` +
      (G.bv3 ? ` 3BV ${G.bv3}，效率 ${(G.bv3 / sec).toFixed(2)} 3BV/s。` : "") + (G.cheated ? "（使用了辅助）" : "") + " 来挑战我吧！";
    const r = await Native.share(text);
    if (r === "copy") showToast("战绩已复制到剪贴板", 1600); else if (r === "fail") showToast("分享失败", 1600);
  });
})();

// ---------- 5. 数据导出 / 导入 ----------
function buildBackup() {
  const meta = parseJson(store.get(META_KEY));
  if (Array.isArray(meta.hist)) meta.hist.forEach((e) => { if (e && e.rp) delete e.rp; }); // 回放体积大，不进备份
  return JSON.stringify({ app: "minesweeper", v: 1, t: Date.now(), settings: parseJson(store.get(SETTINGS_KEY)), meta, theme: parseJson(store.get(THEME_KEY)), ext: Ext.cfg });
}
function openDataDialog(kind) {
  document.getElementById("data-dialog")?.remove();
  const d = document.createElement("div");
  d.className = "overlay show"; d.id = "data-dialog";
  d.innerHTML = `<div class="data-panel"><h3>${kind === "export" ? "导出备份" : "导入备份"}</h3>
    <p class="data-tip">${kind === "export" ? "复制或分享下面的文本，换机或重装后可在「导入备份」里粘贴恢复（不含回放）。" : "粘贴之前导出的备份文本。导入会覆盖当前的设置、战绩与成就。"}</p>
    <textarea id="data-text" spellcheck="false" ${kind === "export" ? "readonly" : 'placeholder="在此粘贴备份文本"'}></textarea>
    <div class="data-actions"><button class="btn" id="data-close">关闭</button><button class="btn btn-primary" id="data-go">${kind === "export" ? "复制 / 分享" : "导入并重启"}</button></div></div>`;
  document.body.appendChild(d);
  const ta = d.querySelector("#data-text");
  if (kind === "export") ta.value = buildBackup();
  d.querySelector("#data-close").onclick = () => d.remove();
  d.querySelector("#data-go").onclick = async () => {
    if (kind === "export") {
      const r = await Native.share(ta.value, "扫雷备份");
      if (r === "copy") showToast("备份已复制到剪贴板", 1800);
      return;
    }
    const o = parseJson(ta.value.trim());
    if (o.app !== "minesweeper" || o.v !== 1 || !isObj(o.meta)) return showToast("不是有效的备份文本", 2000);
    const btn = d.querySelector("#data-go");
    if (!btn.dataset.arm) { btn.dataset.arm = "1"; btn.textContent = "再点一次确认覆盖"; return; }
    Ext.importing = true; clearTimer("save");
    store.set(META_KEY, JSON.stringify(o.meta));
    if (isObj(o.settings)) store.set(SETTINGS_KEY, JSON.stringify(o.settings));
    if (isObj(o.theme)) store.set(THEME_KEY, JSON.stringify(o.theme));
    if (isObj(o.ext)) store.set(EXT_KEY, JSON.stringify(o.ext));
    store.remove(RESUME_KEY);
    showToast("导入成功，正在重启…", 1200);
    setTimeout(() => location.reload(), 700);
  };
  if (kind === "export") ta.focus({ preventScroll: true });
}

Native.init();
